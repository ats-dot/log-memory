package com.pencatat.memori

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings

// Menyalakan layanan Aksesibilitas sendiri lewat Settings.Secure.
// Izin WRITE_SECURE_SETTINGS diberikan otomatis lewat Shizuku (pm grant), jadi tidak perlu ADB dari PC.
// Android mematikan layanan setiap aplikasi di-force stop, jadi siapkan() dipanggil tiap tombol Mulai ditekan.
object AutoAccess {

    const val PERM = "android.permission.WRITE_SECURE_SETTINGS"

    fun granted(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    fun command(ctx: Context): String = "adb shell pm grant ${ctx.packageName} $PERM"

    // Beri izin lewat Shizuku. true = izin sudah ada setelah pemanggilan.
    fun grantViaShizuku(ctx: Context, log: (String) -> Unit): Boolean {
        if (granted(ctx)) return true
        if (!ShizukuHelper.isRunning()) {
            log("Shizuku belum jalan, izin aksesibilitas otomatis belum bisa diberikan")
            return false
        }
        if (!ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
            log("Menunggu izin Shizuku untuk aplikasi ini")
            return false
        }
        return try {
            val r = ShizukuHelper.run(arrayOf("sh", "-c", "pm grant ${ctx.packageName} $PERM"))
            if (r.first != 0) log("pm grant gagal: ${r.third.take(160)}")
            granted(ctx)
        } catch (e: Throwable) {
            log("pm grant error: ${e.message}")
            false
        }
    }

    fun isServiceEnabled(ctx: Context): Boolean {
        val cn = ComponentName(ctx, AutoService::class.java)
        val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val en = Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        val ada = cur.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
        return ada && en
    }

    // true = pengaturan diubah barusan
    fun ensure(ctx: Context): Boolean {
        if (!granted(ctx)) return false
        return try {
            val cn = ComponentName(ctx, AutoService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            val cr = ctx.contentResolver
            val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val parts = cur.split(':').filter { it.isNotBlank() }
            val listed = parts.any { it.equals(full, true) || it.equals(short, true) }
            val enabled = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
            if (listed && enabled) return false
            if (!listed) {
                val nv = if (parts.isEmpty()) full else parts.joinToString(":") + ":" + full
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, nv)
            }
            if (!enabled) Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Throwable) {
            false
        }
    }

    // Dipanggil dari thread latar. Memberi izin (Shizuku), menyalakan layanan, lalu menunggu tersambung.
    fun siapkan(ctx: Context, maxMs: Long, log: (String) -> Unit): Boolean {
        if (AutoService.inst != null) return true
        grantViaShizuku(ctx, log)
        if (!granted(ctx)) {
            log("Aksesibilitas belum aktif dan izin otomatis belum ada. Nyalakan manual di Pengaturan > Aksesibilitas.")
            return false
        }
        val diubah = ensure(ctx)
        if (diubah) log("Aksesibilitas dinyalakan otomatis")
        val t0 = SystemClock.uptimeMillis()
        while (SystemClock.uptimeMillis() - t0 < maxMs) {
            if (AutoService.inst != null) {
                log("Aksesibilitas tersambung ${SystemClock.uptimeMillis() - t0} ms setelah dinyalakan")
                return true
            }
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                return false
            }
        }
        log("Aksesibilitas belum tersambung setelah ${maxMs / 1000} detik")
        return AutoService.inst != null
    }
}
