package com.pencatat.memori

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast

// Layanan latar: menjaga perekaman tetap jalan saat game ada di depan,
// dan menampilkan notifikasi dengan tombol tanda.
class LayananPerekam : Service() {

    companion object {
        const val KANAL = "perekam"
        const val ID = 41
    }

    private val h = Handler(Looper.getMainLooper())

    private val segar = object : Runnable {
        override fun run() {
            if (Perekam.berjalan) {
                try {
                    getSystemService(NotificationManager::class.java).notify(ID, bangun())
                } catch (e: Throwable) {
                }
                h.postDelayed(this, 2000)
            } else {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        buatKanal()
        startForeground(ID, bangun())
        Perekam.mulai(applicationContext)
        h.removeCallbacks(segar)
        h.postDelayed(segar, 2000)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(segar)
        Perekam.berhenti()
        super.onDestroy()
    }

    private fun buatKanal() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(KANAL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(KANAL, "Perekaman", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun aksiTanda(kode: Int, judul: String, label: String): Notification.Action {
        val i = Intent(this, PenerimaTanda::class.java)
        i.putExtra("label", label)
        val pi = PendingIntent.getBroadcast(
            this, kode, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), judul, pi).build()
    }

    private fun bangun(): Notification {
        val b = Notification.Builder(this, KANAL)
        b.setSmallIcon(R.drawable.ic_notif)
        if (Perekam.mode == 1) {
            b.setContentTitle("Mencari " + Perekam.durasi())
            b.setContentText(Perekam.cariSampel.toString() + " sampel · " + Perekam.cariBerubah + " alamat berubah")
        } else {
            b.setContentTitle("Merekam " + Perekam.durasi())
            b.setContentText(Perekam.jumlah.toString() + " perubahan · " + Perekam.rataMs.toInt() + " ms per putaran")
        }
        b.setOngoing(true)
        b.setOnlyAlertOnce(true)
        val buka = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.setContentIntent(buka)
        b.addAction(aksiTanda(1, "Tower BISA dihit", "Tower BISA dihit sekarang"))
        b.addAction(aksiTanda(2, "Mulai lag", "Mulai lag / macet"))
        val lain = Intent(this, MarkerActivity::class.java)
        lain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        lain.putExtra("ringkas", true)
        val pi = PendingIntent.getActivity(
            this, 3, lain, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Tanda lain…", pi).build())
        return b.build()
    }
}

class PenerimaTanda : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val label = intent.getStringExtra("label") ?: return
        Perekam.tanda(label)
        Toast.makeText(context, "Tercatat: $label", Toast.LENGTH_SHORT).show()
    }
}
