package com.pencatat.memori

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

// Satu sesi shell yang tetap hidup, dijalankan sebagai uid game lewat
// "run-as <paket>" (hanya jalan untuk aplikasi debuggable, mis. Multi Run).
// Membaca memori game dari /proc/<pid>/mem dengan dd, hasilnya diubah jadi teks
// (base64 atau hex) supaya bisa dilewatkan lewat pipa teks.
class GameShell(private val paket: String) {

    private var proc: Process? = null
    private var keluar: OutputStream? = null
    private val antrean = LinkedBlockingQueue<String>()
    private var urut = 0

    @Volatile
    private var hidupFlag = false

    // 0 = base64 -w 0, 1 = base64 lalu tr, 2 = od hex
    private var mode = 0

    val hidup: Boolean
        get() = hidupFlag

    val namaMode: String
        get() = when (mode) {
            0 -> "base64"
            1 -> "base64 (tr)"
            else -> "hex"
        }

    fun buka(): Boolean {
        tutup()
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return false
        return try {
            val p = ShizukuHelper.start(arrayOf("sh", "-c", "run-as $paket sh"))
            proc = p
            keluar = p.outputStream
            hidupFlag = true
            Thread {
                try {
                    val r = p.inputStream.bufferedReader()
                    while (true) {
                        val baris = r.readLine() ?: break
                        antrean.offer(baris)
                    }
                } catch (e: Throwable) {
                }
                hidupFlag = false
            }.apply { isDaemon = true }.start()
            Thread {
                try {
                    val buf = ByteArray(1024)
                    while (p.errorStream.read(buf) >= 0) {
                    }
                } catch (e: Throwable) {
                }
            }.apply { isDaemon = true }.start()
            val id = jalankan("id -u")?.trim()
            if (id.isNullOrEmpty()) {
                tutup()
                false
            } else {
                pilihMode()
                true
            }
        } catch (e: Throwable) {
            tutup()
            false
        }
    }

    fun tutup() {
        hidupFlag = false
        try {
            proc?.destroy()
        } catch (e: Throwable) {
        }
        proc = null
        keluar = null
        antrean.clear()
    }

    // Kirim satu perintah, tunggu sampai penanda selesai muncul.
    // Kalau lewat batas waktu, sesi dianggap rusak dan ditutup (supaya sisa
    // keluaran lama tidak bercampur dengan perintah berikutnya).
    @Synchronized
    fun jalankan(perintah: String, batasMs: Long = 4000): String? {
        val o = keluar ?: return null
        if (!hidupFlag) return null
        urut++
        val tanda = "__SELESAI_" + urut
        antrean.clear()
        try {
            o.write((perintah + "\necho\necho " + tanda + "\n").toByteArray())
            o.flush()
        } catch (e: Throwable) {
            tutup()
            return null
        }
        val sb = StringBuilder()
        val akhir = System.currentTimeMillis() + batasMs
        while (true) {
            val sisa = akhir - System.currentTimeMillis()
            if (sisa <= 0) {
                tutup()
                return null
            }
            val baris = antrean.poll(sisa, TimeUnit.MILLISECONDS)
            if (baris == null) {
                tutup()
                return null
            }
            if (baris == tanda) break
            if (baris.isNotEmpty()) sb.append(baris).append('\n')
        }
        return sb.toString()
    }

    private fun pilihMode() {
        val a = jalankan("printf 'hi' | base64 -w 0")?.trim()
        if (a == "aGk=") {
            mode = 0
            return
        }
        val b = jalankan("printf 'hi' | base64 | tr -d '\\n'")?.trim()
        if (b == "aGk=") {
            mode = 1
            return
        }
        mode = 2
    }

    private fun hexKeBytes(s: String): ByteArray {
        val o = ByteArrayOutputStream()
        for (tok in s.split(' ', '\n', '\t')) {
            if (tok.length == 2) o.write(tok.toInt(16))
        }
        return o.toByteArray()
    }

    // Baca [panjang] byte mulai dari [alamat] di proses [pid].
    // dd membaca per halaman 4096 byte, jadi alamat diratakan dulu ke batas halaman.
    fun baca(pid: Int, alamat: Long, panjang: Int): ByteArray? {
        if (alamat <= 0L || panjang <= 0) return null
        val halamanAwal = alamat / 4096L
        val geser = (alamat % 4096L).toInt()
        val jumlahHalaman = (geser + panjang + 4095) / 4096
        val dd = "dd if=/proc/$pid/mem bs=4096 skip=$halamanAwal count=$jumlahHalaman 2>/dev/null"
        val perintah = when (mode) {
            0 -> "$dd | base64 -w 0"
            1 -> "$dd | base64 | tr -d '\\n'"
            else -> "$dd | od -An -v -tx1"
        }
        val teks = jalankan(perintah) ?: return null
        val mentah: ByteArray = try {
            if (mode == 2) hexKeBytes(teks) else Base64.decode(teks.trim(), Base64.DEFAULT)
        } catch (e: Throwable) {
            return null
        }
        if (mentah.size < geser + panjang) return null
        return mentah.copyOfRange(geser, geser + panjang)
    }

    fun bacaLong(pid: Int, alamat: Long): Long? {
        val b = baca(pid, alamat, 8) ?: return null
        return Daftar.le(b, 0, 8)
    }

    fun bacaTeks(pid: Int, alamat: Long, maks: Int): String? {
        val b = baca(pid, alamat, maks) ?: return null
        var n = 0
        while (n < b.size && b[n] != 0.toByte()) n++
        return String(b, 0, n, Charsets.ISO_8859_1)
    }
}
