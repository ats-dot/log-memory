package com.pencatat.memori

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

// Satu sesi shell yang tetap hidup, dijalankan sebagai uid game lewat
// "run-as <paket>" (hanya jalan untuk aplikasi debuggable, mis. Multi Run).
// Membaca memori game dari /proc/<pid>/mem dengan dd, hasilnya diubah jadi teks
// (base64 atau hex) supaya bisa dilewatkan lewat pipa teks.
class GameShell(private val paket: String) {

    private var proc: Process? = null
    private var keluar: OutputStream? = null
    private val antrean = LinkedBlockingQueue<String>()
    private var urut = 0

    @Volatile
    private var hidupFlag = false

    // Proses native tetap hidup untuk baca/tulis cepat. null / tidak hidup = pakai dd.
    @Volatile var nativo: HelperNative? = null

    fun bukaNativo(): Boolean {
        if (helperPath.isEmpty()) return false
        val h = HelperNative(paket, helperPath)
        val ok = h.buka()
        nativo = if (ok) h else null
        return ok
    }

    // Cara tulis alternatif lewat scanner (pwrite / vm / ptrace). null = pakai dd.
    @Volatile var helperPath: String = ""
    @Volatile var metodeTulis: String? = null

    // 0 = base64 -w 0, 1 = base64 lalu tr, 2 = od hex
    private var mode = 0

    val hidup: Boolean
        get() = hidupFlag

    val namaMode: String
        get() = when (mode) {
            0 -> "base64"
            1 -> "base64 (tr)"
            else -> "hex"
        }

    fun buka(): Boolean {
        tutup()
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return false
        return try {
            val p = ShizukuHelper.start(arrayOf("sh", "-c", "run-as $paket sh"))
            proc = p
            keluar = p.outputStream
            hidupFlag = true
            Thread {
                try {
                    val r = p.inputStream.bufferedReader()
                    while (true) {
                        val baris = r.readLine() ?: break
                        antrean.offer(baris)
                    }
                } catch (e: Throwable) {
                }
                hidupFlag = false
            }.apply { isDaemon = true }.start()
            Thread {
                try {
                    val buf = ByteArray(1024)
                    while (p.errorStream.read(buf) >= 0) {
                    }
                } catch (e: Throwable) {
                }
            }.apply { isDaemon = true }.start()
            val id = jalankan("id -u")?.trim()
            if (id.isNullOrEmpty()) {
                tutup()
                false
            } else {
                pilihMode()
                true
            }
        } catch (e: Throwable) {
            tutup()
            false
        }
    }

    fun tutup() {
        try { nativo?.tutup() } catch (_: Throwable) {}
        nativo = null
        hidupFlag = false
        try {
            proc?.destroy()
        } catch (e: Throwable) {
        }
        proc = null
        keluar = null
        antrean.clear()
    }

    // Kirim satu perintah, tunggu sampai penanda selesai muncul.
    // Kalau lewat batas waktu, sesi dianggap rusak dan ditutup (supaya sisa
    // keluaran lama tidak bercampur dengan perintah berikutnya).
    @Synchronized
    fun jalankan(perintah: String, batasMs: Long = 4000): String? {
        val o = keluar ?: return null
        if (!hidupFlag) return null
        urut++
        val tanda = "__SELESAI_" + urut
        antrean.clear()
        try {
            o.write((perintah + "\necho\necho " + tanda + "\n").toByteArray())
            o.flush()
        } catch (e: Throwable) {
            tutup()
            return null
        }
        val sb = StringBuilder()
        val akhir = System.currentTimeMillis() + batasMs
        while (true) {
            val sisa = akhir - System.currentTimeMillis()
            if (sisa <= 0) {
                tutup()
                return null
            }
            val baris = antrean.poll(sisa, TimeUnit.MILLISECONDS)
            if (baris == null) {
                tutup()
                return null
            }
            if (baris == tanda) break
            if (baris.isNotEmpty()) sb.append(baris).append('\n')
        }
        return sb.toString()
    }

    private fun pilihMode() {
        val a = jalankan("printf 'hi' | base64 -w 0")?.trim()
        if (a == "aGk=") {
            mode = 0
            return
        }
        val b = jalankan("printf 'hi' | base64 | tr -d '\\n'")?.trim()
        if (b == "aGk=") {
            mode = 1
            return
        }
        mode = 2
    }

    private fun hexKeBytes(s: String): ByteArray {
        val o = ByteArrayOutputStream()
        for (tok in s.split(' ', '\n', '\t')) {
            if (tok.length == 2) o.write(tok.toInt(16))
        }
        return o.toByteArray()
    }

    // Baca [panjang] byte mulai dari [alamat] di proses [pid].
    // dd membaca per halaman 4096 byte, jadi alamat diratakan dulu ke batas halaman.
    fun baca(pid: Int, alamat: Long, panjang: Int): ByteArray? {
        if (alamat <= 0L || panjang <= 0) return null
        val n = nativo
        if (n != null && n.hidup) {
            try {
                return n.baca(pid, alamat, panjang)
            } catch (_: Throwable) {
                // helper bermasalah: pakai dd di bawah
            }
        }
        val halamanAwal = alamat / 4096L
        val geser = (alamat % 4096L).toInt()
        val jumlahHalaman = (geser + panjang + 4095) / 4096
        val dd = "dd if=/proc/$pid/mem bs=4096 skip=$halamanAwal count=$jumlahHalaman 2>/dev/null"
        val perintah = when (mode) {
            0 -> "$dd | base64 -w 0"
            1 -> "$dd | base64 | tr -d '\\n'"
            else -> "$dd | od -An -v -tx1"
        }
        val teks = jalankan(perintah) ?: return null
        val mentah: ByteArray = try {
            if (mode == 2) hexKeBytes(teks) else Base64.decode(teks.trim(), Base64.DEFAULT)
        } catch (e: Throwable) {
            return null
        }
        if (mentah.size < geser + panjang) return null
        return mentah.copyOfRange(geser, geser + panjang)
    }

    fun bacaLong(pid: Int, alamat: Long): Long? {
        val b = baca(pid, alamat, 8) ?: return null
        return Daftar.le(b, 0, 8)
    }

    fun bacaTeks(pid: Int, alamat: Long, maks: Int): String? {
        val b = baca(pid, alamat, maks) ?: return null
        var n = 0
        while (n < b.size && b[n] != 0.toByte()) n++
        return String(b, 0, n, Charsets.ISO_8859_1)
    }

    // Tulis byte ke memori game lewat dd ke /proc/<pid>/mem (bs=1 supaya alamat tidak perlu rata halaman).
    // Data dikirim sebagai base64 (aman untuk byte 0) atau printf oktal kalau base64 tidak ada.
    // true = semua perintah selesai tanpa kegagalan shell. Hasil tulis SEBENARNYA harus dicek dengan baca().
    fun tulis(pid: Int, daftar: List<Pair<Long, ByteArray>>): Boolean {
        if (daftar.isEmpty()) return true
        val mt = metodeTulis
        val n = nativo
        if (mt == "vm" && n != null && n.hidup) {
            try {
                return n.tulis(pid, daftar)
            } catch (_: Throwable) {
                // helper bermasalah: pakai cara per-proses di bawah
            }
        }
        if (mt != null && helperPath.isNotEmpty()) return tulisHelper(pid, daftar, mt)
        for (potong in daftar.chunked(24)) {
            val sb = StringBuilder()
            for ((a, b) in potong) {
                if (a <= 0L || b.isEmpty()) continue
                if (mode != 2) {
                    sb.append("printf '%s' ").append(Base64.encodeToString(b, Base64.NO_WRAP))
                        .append(" | base64 -d | dd of=/proc/").append(pid)
                        .append("/mem bs=1 seek=").append(a).append(" conv=notrunc 2>/dev/null; ")
                } else {
                    sb.append("printf '")
                    for (x in b) sb.append('\\').append(String.format("%03o", x.toInt() and 0xFF))
                    sb.append("' | dd of=/proc/").append(pid)
                        .append("/mem bs=1 seek=").append(a).append(" conv=notrunc 2>/dev/null; ")
                }
            }
            if (sb.isEmpty()) continue
            jalankan(sb.toString(), 12000) ?: return false
        }
        return true
    }

    private fun hex(b: ByteArray): String {
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02x", x.toInt() and 0xFF))
        return sb.toString()
    }

    // Tulis lewat scanner (program native). Satu proses per kelompok alamat.
    fun tulisHelper(pid: Int, daftar: List<Pair<Long, ByteArray>>, metode: String): Boolean {
        for (potong in daftar.chunked(24)) {
            val sb = StringBuilder("$helperPath $pid wr $metode")
            var n = 0
            for ((a, b) in potong) {
                if (a <= 0L || b.isEmpty()) continue
                sb.append(' ').append(java.lang.Long.toHexString(a)).append(' ').append(hex(b))
                n++
            }
            if (n == 0) continue
            val out = jalankan(sb.toString(), 12000) ?: return false
            if (out.lines().none { it.trim() == "OK" }) return false
        }
        return true
    }

    // Diagnosa tulis lewat dd: keluaran mentah (lingkungan, pesan error dd, dan baca-ulang seketika).
    fun diagDd(pid: Int, a: Long, b: ByteArray): String? {
        val src = if (mode != 2) "printf '%s' " + Base64.encodeToString(b, Base64.NO_WRAP) + " | base64 -d"
        else {
            val sb = StringBuilder("printf '")
            for (x in b) sb.append('\\').append(String.format("%03o", x.toInt() and 0xFF))
            sb.append("'")
            sb.toString()
        }
        val skrip = """
P=@P@; A=@A@
echo "id: §(id -u) §(id -Z 2>&1)"
echo "selinux: §(getenforce 2>&1) | kernel §(uname -r 2>&1)"
echo "mem: §(ls -lZ /proc/§P/mem 2>&1)"
echo "status: §(grep -E '^(Uid|Seccomp|NoNewPrivs)' /proc/§P/status 2>&1 | tr '\n' ' ')"
echo "konteks proses: §(cat /proc/§P/attr/current 2>&1)"
E=§(@SRC@ | dd of=/proc/§P/mem bs=1 seek=§A conv=notrunc 2>&1); echo "dd rc=§? §E"
echo "baca: §(dd if=/proc/§P/mem bs=1 skip=§A count=@N@ 2>/dev/null | od -An -tx1 2>&1)"
""".trimIndent().replace('§', '$').replace("@P@", pid.toString()).replace("@A@", a.toString())
            .replace("@SRC@", src).replace("@N@", b.size.toString())
        return jalankan(skrip, 9000)
    }
}
