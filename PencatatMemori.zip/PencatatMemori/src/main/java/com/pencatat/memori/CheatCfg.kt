package com.pencatat.memori

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

// Konfigurasi fitur skrip. Nama kunci SAMA dengan tabel config di skrip GG (attribute.health, selfKda.kill, dst),
// jadi pemetaan 1:1 mudah dicek. Disimpan sebagai satu JSON di SharedPreferences.
// Template (statTemplateValue di skrip) disimpan terpisah, nama bawaan "N1 : 14 Minute".
object CheatCfg {
    private lateinit var sp: SharedPreferences
    @Volatile
    private var root = JSONObject()

    const val TEMPLATE_BAWAAN = "N1 : 14 Minute"

    // Isi template "N1 : 14 Minute" persis seperti di skrip
    private const val N1 = """{
"antiAfk":true,
"attribute":{"attSpeed":true,"auto":true,"autoAttr":true,"autoElement":false,"damage":1500,"health":20000,"movSpeed":2000},
"autoDelay":506,"autoOnAlert":false,"autoOnScriptTime":"03:31","autoSkipTime":true,"autoStopMinion":true,"cheatHealthTower":true,
"enemyKda":{"assist":3,"auto":true,"death":11,"gold":900,"kill":7,"maxLevel":true,"random":true},
"enemyRandomValue":{"assist":[2,6],"dKill":[0,2],"death":[8,13],"dmgDealt":[3846,7148],"dmgRec":[8571,10581],"gold":[821,919],"kill":[1,6],"legendary":[0,1],"legendaryBool":false,"maniac":[0,0],"savage":[0,0],"tKill":[0,1],"towerDmg":[980,4017]},
"enemyStat":{"auto":true,"dKill":5,"dmgDealt":9000,"dmgRec":16000,"legendary":false,"maniac":2,"random":true,"savage":1,"tKill":3,"towerDmg":8158},
"isAuto":true,"isUseAutoOn":false,
"selfKda":{"assist":8,"auto":true,"death":1,"gold":1450,"kill":16,"maxLevel":true,"random":true},
"selfRandomValue":{"assist":[7,11],"dKill":[4,6],"death":[1,3],"dmgDealt":[10810,12581],"dmgRec":[4581,6168],"gold":[1230,1450],"kill":[13,15],"legendary":[0,1],"legendaryBool":false,"maniac":[2,3],"savage":[1,2],"tKill":[3,4],"towerDmg":[13000,19071]},
"selfStat":{"auto":true,"dKill":5,"dmgDealt":12480,"dmgRec":10000,"legendary":true,"maniac":2,"random":true,"savage":1,"tKill":3,"towerDmg":21783},
"setTime":14,
"teamKda":{"assist":10,"auto":true,"death":2,"gold":1300,"kill":12,"maxLevel":true,"random":true},
"teamRandomValue":{"assist":[8,10],"dKill":[2,4],"death":[3,5],"dmgDealt":[8158,10269],"dmgRec":[5681,6816],"gold":[1010,1230],"kill":[6,11],"legendary":[0,1],"legendaryBool":false,"maniac":[1,2],"savage":[1,1],"tKill":[1,3],"towerDmg":[9000,12000]},
"teamStat":{"auto":true,"dKill":5,"dmgDealt":11000,"dmgRec":11000,"legendary":true,"maniac":2,"random":true,"savage":1,"tKill":3,"towerDmg":30000},
"teleportTower":true}"""

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("auto_up_lvl_cheat", Context.MODE_PRIVATE)
        root = try {
            val s = sp.getString("cfg", null)
            if (s == null) JSONObject(N1) else JSONObject(s)
        } catch (e: Throwable) {
            JSONObject(N1)
        }
        if (sp.getString("templates", null) == null) {
            val t = JSONObject()
            t.put(TEMPLATE_BAWAAN, JSONObject(N1))
            sp.edit().putString("templates", t.toString()).apply()
        }
    }

    fun json(): String = root.toString()

    @Synchronized
    fun simpan() {
        sp.edit().putString("cfg", root.toString()).apply()
    }

    // Ambil objek induk dari jalur "a.b.c"; buat kalau perlu
    private fun induk(p: String, buat: Boolean): Pair<JSONObject?, String> {
        val bagian = p.split('.')
        var o: JSONObject? = root
        for (i in 0 until bagian.size - 1) {
            val n = o?.optJSONObject(bagian[i])
            o = if (n != null) n else if (buat) JSONObject().also { o?.put(bagian[i], it) } else null
        }
        return Pair(o, bagian.last())
    }

    fun ada(p: String): Boolean {
        val (o, k) = induk(p, false)
        return o != null && o.has(k) && !o.isNull(k)
    }

    // Nilai Boolean. Di skrip, nil dan false sama-sama "mati".
    fun b(p: String): Boolean {
        val (o, k) = induk(p, false)
        return o?.optBoolean(k, false) ?: false
    }

    fun i(p: String): Int? {
        val (o, k) = induk(p, false)
        if (o == null || !o.has(k) || o.isNull(k)) return null
        return try {
            o.getDouble(k).toInt()
        } catch (e: Throwable) {
            null
        }
    }

    fun s(p: String): String? {
        val (o, k) = induk(p, false)
        if (o == null || !o.has(k) || o.isNull(k)) return null
        return o.optString(k)
    }

    // Rentang [min, maks]; null kalau belum diisi
    fun r(p: String): IntArray? {
        val (o, k) = induk(p, false)
        val a = o?.optJSONArray(k) ?: return null
        if (a.length() < 2 || a.isNull(0) || a.isNull(1)) return null
        return intArrayOf(a.optInt(0), a.optInt(1))
    }

    @Synchronized
    fun set(p: String, v: Any?) {
        val (o, k) = induk(p, true)
        if (o == null) return
        if (v == null || v == false) o.remove(k) else o.put(k, v)
        // Di skrip, false disimpan sebagai nil. Untuk tombol yang bawaan hidup (mis. random) kita simpan false eksplisit.
    }

    @Synchronized
    fun setBool(p: String, v: Boolean) {
        val (o, k) = induk(p, true)
        o?.put(k, v)
    }

    @Synchronized
    fun setRentang(p: String, a: Int?, b: Int?) {
        val (o, k) = induk(p, true)
        if (o == null) return
        if (a == null || b == null) {
            o.put(k, JSONArray().put(JSONObject.NULL).put(JSONObject.NULL))
        } else {
            o.put(k, JSONArray().put(a).put(b))
        }
    }

    // ── Template (Template Script di menu) ──
    private fun semuaTemplate(): JSONObject = try {
        JSONObject(sp.getString("templates", "{}") ?: "{}")
    } catch (e: Throwable) {
        JSONObject()
    }

    fun daftarTemplate(): List<String> {
        val o = semuaTemplate()
        val l = ArrayList<String>()
        val it = o.keys()
        while (it.hasNext()) l.add(it.next())
        return l
    }

    // Simpan isi config sekarang sebagai template. false = nama sudah ada (skrip menolak duplikat).
    fun simpanTemplate(nama: String, timpa: Boolean = false): Boolean {
        val n = nama.trim()
        if (n.isEmpty()) return false
        val o = semuaTemplate()
        if (o.has(n) && !timpa) return false
        o.put(n, JSONObject(root.toString()))
        sp.edit().putString("templates", o.toString()).apply()
        return true
    }

    // Terapkan template ke config sekarang (kunci template menimpa kunci config, sisanya dibiarkan)
    @Synchronized
    fun terapkanTemplate(nama: String): Boolean {
        val t = semuaTemplate().optJSONObject(nama) ?: return false
        val it = t.keys()
        while (it.hasNext()) {
            val k = it.next()
            root.put(k, t.get(k))
        }
        simpan()
        return true
    }

    fun hapusTemplate(nama: String) {
        if (nama == TEMPLATE_BAWAAN) return
        val o = semuaTemplate()
        o.remove(nama)
        sp.edit().putString("templates", o.toString()).apply()
    }

    @Synchronized
    fun kembalikanBawaan() {
        root = JSONObject(N1)
        simpan()
    }
}
