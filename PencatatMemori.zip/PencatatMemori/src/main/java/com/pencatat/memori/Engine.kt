package com.pencatat.memori

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.PowerManager

/**
 * Engine otomasi 26 langkah untuk Auto up lvl.
 *
 * Flow per server:
 *  1-3:  Lobby → cek ikon tangan "Pertumbuhan Level" → handle / Classic
 *  4-6:  Handle popup reward (Konfirmasi, Pergi ke Lobby, late timing)
 *  7-8:  Classic → Mulai Game, handle popup (Fitur Mabar, Panduan Map) dgn back
 *  9-11: Loading → In-game tap turret 4-6x → Victory
 * 12-14: Post-game (Lanjutkan, Lanjutkan, Konfirmasi)
 * 15-16: Back 3x ke lobby, handle popup
 * 17-20: Event → Petir → Hadiah Kemenangan → Klaim Semua
 * 21-22: Profil → dismiss popup → Akun/Pengaturan Akun
 * 23-26: Ganti Server → pilih next → Ganti Server → OK → restart
 */
object Engine {

    @Volatile var running = false
    @Volatile var status = "Siap"
    @Volatile var total = 0
    @Volatile var doneCount = 0
    @Volatile var startedAt = 0L
    @Volatile var endedAt = 0L
    @Volatile var freezeCount = 0
    val doneNames: List<String> get() = done.toList()
    val currentServer: String? get() = cur

    private var app: Context? = null
    private val done = HashSet<String>()
    private val skipped = HashSet<String>()
    private val order = ArrayList<String>()
    private var cur: String? = null
    private var acct = "-"
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastActive = 0L
    private var readNo = 0
    @Volatile private var layarW = 0
    @Volatile private var layarH = 0
    private var lastFrame: IntArray? = null
    private var lastFrameTime = 0L

    class Stop(msg: String) : RuntimeException(msg)

    // ── Screen Regions (fractional) ──
    data class Reg(val x0: Float, val y0: Float, val x1: Float, val y1: Float)

    private val R_BOTTOM = Reg(0.0f, 0.80f, 1.0f, 1.0f)
    private val R_MULAI = Reg(0f, 0.6f, 1f, 1f)
    private val R_ATAS = Reg(0.10f, 0.0f, 0.90f, 0.62f)  // judul dan isi popup halaman Classic
    private val R_TOP = Reg(0.0f, 0.0f, 1.0f, 0.14f)
    private val R_OK = Reg(0.20f, 0.60f, 0.80f, 1.0f)
    private val R_AKUNP = Reg(0.62f, 0.10f, 1.0f, 0.95f)     // tombol kanan Pengaturan Akun
    private val R_ROLE = Reg(0.55f, 0.0f, 1.0f, 0.09f)
    private val R_ACCID = Reg(0.70f, 0.12f, 1.0f, 0.20f)   // "Account ID" di Pengaturan Akun
    private val R_ID = Reg(0.20f, 0.14f, 0.50f, 0.26f)     // baris "ID: ... (kode server)" di Profil
    private val R_PROFIL = Reg(0.0f, 0.10f, 0.46f, 1.0f)
    private val R_AKUN = Reg(0.25f, 0.1f, 0.85f, 0.95f)
    private val R_SERVER = Reg(0.12f, 0.12f, 0.88f, 0.88f)
    private val R_MENU = Reg(0.04f, 0.08f, 0.27f, 0.99f)    // daftar menu kiri halaman Hadiah
    private val R_PANEL = Reg(0.38f, 0.05f, 1.0f, 1.0f)     // panel kanan Hadiah (Klaim, Pergi, koin)
    private val R_EVT = Reg(0.04f, 0.0f, 0.62f, 1.0f)       // judul halaman + menu kiri (cek halaman Hadiah terbuka)

    // Penghitung dan penanda yang dipakai kode salinan claim-vg
    private var flip = 0
    private var topupTaps = 0
    private var topupBlockUntil = 0L
    private var darkTaps = 0
    private var lastXx = -999f
    private var lastXy = -999f
    private var xRepeat = 0
    private var xBlockUntil = 0L
    private var serverT0 = 0L
    private val PETIR_X = 0.063f   // ikon petir (tab Hadiah) di kolom kiri halaman Event
    private val PETIR_Y = 0.51f
    private var lobbyEvX = -1f
    private var lobbyEvY = -1f
    private var lobbyEvT = 0L

    // Tanda halaman Event sendiri (menu kirinya). Dua tanda atau lebih = halaman Event
    private val EVENT_MARKS = listOf(
        "vanguardcoinsupply", "masukanadvanceserver", "hadiahpembaruan", "hadiahkemenangan", "hadiahrank",
        "pestaakhirpekan", "verifikasiusia", "karnavalpromo", "festivalpemuda", "bonusgratis", "farmpals", "mainbareng", "cobamodebaru"
    )
    private fun eventMarks(s: Scr): Int = EVENT_MARKS.count { s.all.contains(it) }
    private fun eventOpen(s: Scr): Boolean =
        s.has("vanguardcoin", "coinsupply", "pembaruan", "pembaharuan", "masukanadvance")
    private val menuUpdate = listOf("hadiahkemenangan", "kemenangan")
    private val panelUpdate = listOf("kemenangantotal", "peraturan", "klaimsemua", "menang")

    // ── Helpers ──
    private fun now() = System.currentTimeMillis()
    private fun log(m: String) = AppLog.add(m)
    private fun sleepMs(ms: Long) { Thread.sleep(ms.coerceAtLeast(10)) }
    private fun sleepS(s: Double) = sleepMs((s * 1000).toLong())

    // Tiap start()/stop() menaikkan generasi. Thread mesin lama yang masih tersisa (mis. Mulai ditekan lagi
    // sedetik sesudah Berhenti) ikut berhenti, tidak ikut jalan bersama sesi baru.
    @Volatile private var generasi = 0
    private val generasiThread = ThreadLocal<Int>()

    private fun alive() {
        if (!running) throw Stop("Dihentikan pengguna")
        val g = generasiThread.get()
        if (g != null && g != generasi) throw Stop("Sesi lama dihentikan")
    }

    private fun rect(bmp: Bitmap, r: Reg): Rect = Rect(
        (bmp.width * r.x0).toInt(), (bmp.height * r.y0).toInt(),
        (bmp.width * r.x1).toInt(), (bmp.height * r.y1).toInt()
    )

    // ── Screenshot + OCR ──
    // Disalin dari claim-vg (Engine.cap): jeda minimal antar screenshot, naik otomatis kalau sistem menolak
    private var minGap = 170L
    private var lastShot = 0L

    // Potongan satu tangkapan penuh menurut area: satu screenshot cukup untuk beberapa pemeriksaan sekaligus
    private fun subScr(s: Scr, reg: Reg): Scr {
        val r = rect(s.bmp, reg)
        return Scr(s.bmp, s.lines.filter { it.cx >= r.left && it.cx <= r.right && it.cy >= r.top && it.cy <= r.bottom })
    }

    private fun cap(reg: Reg? = null): Scr {
        var tries = 0
        var rateHits = 0
        while (true) {
            alive()
            val svc = AutoService.inst ?: throw Stop("Accessibility Service tidak aktif")
            val gap = minGap - (now() - lastShot)
            if (gap > 0) sleepMs(gap)
            lastShot = now()
            val t1 = now()
            val bmp = svc.shot()
            val t2 = now()
            if (bmp != null) {
                trackFrame(bmp)
                val rc = if (reg != null) rect(bmp, reg) else null
                var lines = Ocr.read(bmp, rc, Prefs.ocrScale)
                if (lines == null) {
                    log("OCR gagal, mencoba lagi")
                    lines = Ocr.read(bmp, rc, Prefs.ocrScale)
                    if (lines == null) log("OCR gagal dua kali, layar dianggap kosong")
                }
                val t3 = now()
                readNo++
                lastActive = now()
                log("    baca #" + readNo + ": screenshot " + (t2 - t1) + " ms, OCR " + (t3 - t2) + " ms (" + (if (reg == null) "layar penuh" else "area") + "), " + (lines?.size ?: 0) + " baris")
                if (tries > 0) log("Screenshot pulih setelah " + tries + " kegagalan berturut-turut")
                if (t3 - t1 > 3000L) log("Baca layar lambat: " + (t3 - t1) + " ms (screenshot " + (t2 - t1) + ", OCR " + (t3 - t2) + ")")
                layarW = bmp.width; layarH = bmp.height
                return Scr(bmp, lines ?: emptyList())
            }
            if (svc.lastShotError.startsWith("kode 3") && rateHits < 5) {
                rateHits++
                val nextGap = if (minGap < 345L) 345L else if (minGap < 420L) 420L else minGap
                if (nextGap != minGap) {
                    minGap = nextGap
                    log("Jeda screenshot dinaikkan ke " + nextGap + " ms (sistem menolak interval pendek)")
                }
                sleepMs(120)
                continue
            }
            tries++
            if (tries == 3) log("Screenshot gagal 3 kali berturut-turut (alasan terakhir: " + svc.lastShotError + ")")
            if (tries >= 12) throw Stop("Screenshot terus gagal 12 kali berturut-turut. Alasan terakhir: " + svc.lastShotError)
            sleepS(1.0)
        }
    }

    // Titik melayang: sama dengan claim-vg (applyPerf / releasePerf)
    private fun applyPerf() {
        val m = if (Prefs.dotAuto) Prefs.dotStyle else 0
        if (m >= 1) {
            AutoService.inst?.dot(m)
            log("Titik melayang gaya " + m + " aktif (" + dotName(m) + ")")
        }
    }

    private fun releasePerf() {
        AutoService.inst?.dot(0)
    }

    private fun dotName(m: Int): String = when (m) {
        1 -> "putih 14 dp"
        2 -> "putih kecil 2 dp"
        3 -> "putih hampir transparan 5%"
        4 -> "1 piksel tanpa warna"
        5 -> "14 dp tanpa warna"
        else -> "tanpa titik"
    }

    private var lastAvg = 0L

    private fun timeOcr(bmp: Bitmap, r: Rect?): String {
        val ts = ArrayList<Long>()
        var n = 0
        for (i in 0 until 3) {
            val t0 = now()
            val l = Ocr.read(bmp, r, Prefs.ocrScale)
            ts.add(now() - t0)
            if (l == null) return "OCR gagal"
            n = l.size
        }
        lastAvg = ts.sum() / ts.size
        return ts.joinToString(", ") + " ms (rata-rata " + lastAvg + " ms, " + n + " baris)"
    }

    // Uji gaya titik melayang pada screenshot yang SAMA; gaya paling tidak terlihat yang masih jauh lebih cepat disimpan
    fun ujiTitik(ctx: Context) {
        if (running) return
        Thread {
            try {
                running = true
                app = ctx.applicationContext
                Prefs.init(ctx)
                status = "Uji titik"
                log("── Uji titik melayang ── (pindah ke game dalam 10 detik, lobi saja cukup)")
                sleepS(10.0)
                val svc = AutoService.inst ?: throw Stop("Aksesibilitas tidak aktif")
                var bmp: Bitmap? = null
                for (i in 0..2) { bmp = svc.shot(); if (bmp != null) break; sleepMs(400) }
                if (bmp == null) throw Stop("Screenshot gagal")
                val res = LongArray(6)
                fun ukur(m: Int) {
                    alive()
                    svc.dot(m)
                    if (m >= 1) sleepS(1.5)
                    val a = timeOcr(bmp, null)
                    res[m] = lastAvg
                    val b = timeOcr(bmp, rect(bmp, R_SERVER))
                    log("Gaya " + m + " (" + dotName(m) + "): layar penuh " + a + " | area tengah " + b)
                }
                var best = 0
                try {
                    ukur(0); ukur(5); ukur(4)
                    if (res[5] > 0 && res[5] < res[0] * 0.75) best = 5
                    else if (res[4] > 0 && res[4] < res[0] * 0.75) best = 4
                    else {
                        ukur(3)
                        if (res[3] > 0 && res[3] < res[0] * 0.75) best = 3
                        else {
                            ukur(2); ukur(1)
                            if (res[2] > 0 && res[2] < res[0] * 0.75) best = 2
                            else if (res[1] > 0 && res[1] < res[0] * 0.75) best = 1
                        }
                    }
                } finally {
                    svc.dot(0)
                }
                Prefs.dotStyle = best
                if (best == 0) log("Tidak ada gaya titik yang jauh lebih cepat dari tanpa titik (" + res.joinToString(", ") + " ms). Dipakai tanpa titik.")
                else log("Gaya " + best + " (" + dotName(best) + ") dipakai otomatis: " + res[best] + " ms vs " + res[0] + " ms tanpa titik.")
                status = "Uji selesai"
            } catch (e: Stop) {
                log("Uji berhenti: ${e.message}")
                status = "Uji berhenti"
            } catch (e: Throwable) {
                log("Uji error: ${e.message}")
            } finally {
                running = false
            }
        }.apply { isDaemon = true; start() }
    }

    private fun trackFrame(bmp: Bitmap) {
        val kecil = Bitmap.createScaledBitmap(bmp, 96, 48, false)
        val g = IntArray(96 * 48)
        kecil.getPixels(g, 0, 96, 0, 0, 96, 48)
        kecil.recycle()
        for (i in g.indices) {
            val c = g[i]
            g[i] = ((c shr 16 and 255) * 77 + (c shr 8 and 255) * 150 + (c and 255) * 29) shr 8
        }
        val prev = lastFrame
        if (prev != null && prev.size == g.size) {
            var same = 0
            val step = g.size / 200
            for (i in g.indices step step.coerceAtLeast(1)) {
                if (kotlin.math.abs(g[i] - prev[i]) < 5) same++
            }
            val ratio = same.toFloat() / (g.size / step.coerceAtLeast(1))
            if (ratio < 0.90f) NetMon.terakhirLayarBerubah = now()
            if (ratio > 0.98f && now() - lastFrameTime > Prefs.lagSec * 1000L) {
                freezeCount++
                log("⚠ Layar tampak beku selama ${Prefs.lagSec}s")
                lastFrameTime = now()
            }
        } else {
            lastFrameTime = now()
        }
        lastFrame = g
    }

    // ── Tap / Swipe ──
    // Jeda sesudah ketukan/back dibatasi 150 ms: pembacaan layar berikutnya sudah menunggu jeda minimal screenshot sistem
    private fun settleMs(): Long = Prefs.stepMs.coerceAtMost(150L)

    private fun tapXY(x: Float, y: Float, label: String = "", doLog: Boolean = false) {
        val svc = AutoService.inst ?: throw Stop("Service mati")
        NetMon.ketuk(if (label.isNotEmpty()) label else "(${x.toInt()},${y.toInt()})")
        svc.tap(x, y)
        if (doLog && label.isNotEmpty()) log("Tap: $label (${x.toInt()},${y.toInt()})")
        sleepMs(settleMs())
    }

    private fun tapLine(l: Line, label: String = "") {
        tapXY(l.cx, l.cy, label, true)
    }

    private fun back(label: String = "Back") {
        NetMon.ketuk(label)
        AutoService.inst?.back()
        log(label)
        sleepMs(settleMs())
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = Prefs.swipeHardMs.toLong()) {
        AutoService.inst?.swipe(x1, y1, x2, y2, ms)
        sleepMs(200)
    }

    // ── Screen State Detection ──
    private fun isLobby(s: Scr): Boolean {
        val ok = Prefs.lobbyKeyList.any { s.has(it) }
        if (ok) {
            val e = s.exact("event")
            if (e != null) { lobbyEvX = e.cx; lobbyEvY = e.cy; lobbyEvT = now() }
        }
        return ok
    }

    // Lobi utama (bukan halaman Classic, yang juga memuat tulisan CLASSIC)
    private fun lobiUtama(s: Scr): Boolean {
        if (s.has("persiapan") || s.has("inventori") || s.has("koleksi")) return true
        return isLobby(s) && !isClassicPage(s)
    }

    // Layar Profil (kartu nama, Youth Care, Album + Riwayat). Dari claim-vg
    private fun isProfile(s: Scr): Boolean =
        s.has("youthcare", "kartunama") || (s.has("album") && s.has("riwayat")) || (s.has("pencapaian") && s.has("album"))

    // Layar Pengaturan Akun: ada tombol "Pusat Akun"/"Ganti Akun", atau judul "PENGATURAN AKUN" di bagian atas.
    // (Di layar Profil, "Pengaturan Akun" hanyalah tab di sisi kiri bawah.)
    private fun isAccount(s: Scr): Boolean {
        if (s.has("pusatakun", "gantiakun")) return true
        return s.lines.any { it.norm.contains("pengaturanakun") && it.cy < s.h * 0.12f }
    }

    // Daftar karakter: "Server Saat Ini" atau 3+ nomor server terbaca (tombol "Ganti Server" juga ada di Pengaturan Akun)
    private fun isServerList(s: Scr): Boolean = s.has("serversaatini") || serverNums(s).size >= 3


    private fun isClassicPage(s: Scr): Boolean {
        // "Mode Cepat" = nama baru Classic di Advance Server
        return (s.has("classic") || s.has("modecepat")) && (s.has("mulaigame") || s.has("mulai"))
    }

    private fun isLoading(s: Scr): Boolean {
        return s.has("memuatgame") || s.has("loading") || s.has("vsmatch")
    }

    private fun isInGame(s: Scr): Boolean {
        // In-game: minimal UI, biasanya ada minimap atau skill icons
        return !isLobby(s) && !isLoading(s) && !eventOpen(s) && !isProfile(s) && !isAccount(s) && !isServerList(s)
    }

    private fun isVictory(s: Scr): Boolean {
        return s.has("victory") || s.has("kemenangan") || s.has("mvp")
    }

    private fun isPostGame(s: Scr): Boolean {
        return s.has("lanjutkan") || s.has("konfirmasi") || s.has("achievement") || s.has("bagikan") || isVictory(s)
    }


    // Popup di halaman Classic. Deteksi sengaja ketat: teks petunjuk yang tertinggal di halaman Classic biasa
    // ("Atur preferensimu…", "Rekomendasi teman…") BUKAN penanda popup, karena back yang nyasar membawa kita keluar ke lobi.
    private var fiturBaruCoba = 0
    // "Fitur Mabar tersedia" / "Fitur Mabar telah ditingkatkan": judul bisa terbaca terpisah/typo OCR
    private fun adaFiturBaru(s: Scr): Boolean =
        s.has("mabartersedia", "fiturmabar", "mabartersed", "fiturmabartersedia", "mabarditingkatkan", "mabartelahditingkatkan",
              "tidakbisamembentuk", "belummembuka", "belumembuka") ||
        (s.has("fitur") && s.has("mabar") && (s.has("tersedia") || s.has("ditingkatkan")))

    private fun adaPopupMapTahunan(s: Scr): Boolean = s.has("perubahanmap", "maptahunan", "perubahanmaptahunan")

    // Semua popup halaman Classic (Fitur Mabar, Custom Signal, Panduan) ditutup dengan back SATU kali.
    // Setelah itu halaman Classic normal, jadi popup jenis yang sama tidak di-back lagi dalam 15 detik
    // (teksnya bisa masih terbaca sebentar selagi animasi menutup).
    private val backTerakhir = HashMap<String, Long>()
    private val cobaAwal = HashMap<String, Long>()
    private val cobaKe = HashMap<String, Int>()

    private fun jenisPopupClassic(s: Scr): String? = when {
        s.has("customsignal") || s.has("smartcommand") || s.has("sinyalpertempuran") -> "signal"
        s.lines.any { it.norm.contains("panduan") && it.cy < s.h * 0.25f } || adaPopupMapTahunan(s) -> "panduan"
        adaFiturBaru(s) -> "mabar"
        else -> null
    }

    private fun tutupFiturBaru(s: Scr) {
        val jenis = jenisPopupClassic(s) ?: "lain"
        val t = backTerakhir[jenis] ?: 0L
        if (now() - t < 4_000L) {
            return   // sudah di-back; pembacaan layar berikutnya cukup menunggu animasi tutup
        }
        backTerakhir[jenis] = now()
        fiturBaruCoba++
        // Back terbukti menutup animasi "Fitur Mabar tersedia". Kalau popup masih ada pada percobaan kedua (dalam 40 dtk),
        // dicoba ketukan di tengah layar.
        if (now() - (cobaAwal[jenis] ?: 0L) > 40_000L) { cobaAwal[jenis] = now(); cobaKe[jenis] = 0 }
        val ke = (cobaKe[jenis] ?: 0)
        cobaKe[jenis] = ke + 1
        if ((jenis == "mabar" || jenis == "lain") && ke % 2 == 1) {
            tapXY(s.w * 0.5f, s.h * 0.5f, "Tutup popup Classic: $jenis (ketuk tengah layar)", true)
        } else {
            back("Tutup popup Classic: $jenis (back 1x)")
        }
    }






    // ═══════════ Disalin dari claim-vg (Engine.kt): popup, lobi, Event ═══════════


    // Panah kembali di pojok kiri atas (persen layar, dari screenshot)
    private fun tapArrow(s: Scr) {
        val x = if (isServerList(s)) 0.16f else 0.097f
        tapXY(s.w * x, s.h * 0.045f, "panah kembali")
    }

    // Tombol X: tanpa template gambar (belum ada di apk ini), dibaca dari teks "x" di pojok kanan atas popup
    private fun tapX(s: Scr): Boolean {
        if (now() < xBlockUntil) return false
        val xl = s.lines.filter { (it.norm == "x" || it.norm == "×") && it.cx > s.w * 0.6f && it.cy < s.h * 0.3f }.minByOrNull { it.cy } ?: return false
        if (Math.abs(xl.cx - lastXx) < 40f && Math.abs(xl.cy - lastXy) < 40f) xRepeat++
        else { xRepeat = 0; lastXx = xl.cx; lastXy = xl.cy }
        if (xRepeat >= 2) {
            xBlockUntil = now() + 60000L
            xRepeat = 0
            log("X di titik yang sama berulang tanpa menutup apa pun, X diabaikan 60 detik")
            return false
        }
        tapXY(xl.cx, xl.cy, "tutup X")
        return true
    }

    // true kalau sudah ada popup yang muncul (dan ditangani) sejak mulai menunggu lobby.
    // Kalau sudah ada, waktu tunggu lobby tidak dipakai lagi (popupnya sudah keluar sebelum lobby).
    @Volatile private var popupSeen = false

    private fun popups(s: Scr): Boolean {
        val r = popupsRaw(s)
        if (r) popupSeen = true
        return r
    }

    // Popup "Mastery Code": menutupi lobby, tanpa tombol X. Ditutup dengan Back (dicek lewat OCR), tanpa menunggu hilang sendiri.
    private fun waitMasteryCode() {
        log("Popup Mastery Code: ditutup dengan Back")
        for (i in 1..3) {
            back("Back (Mastery Code) $i/3")
            val t0 = now()
            while (now() - t0 < 1500L) {
                alive()
                if (!cap().has("masterycode")) return
            }
        }
        log("Popup Mastery Code masih terlihat sesudah 3x Back, menunggu hilang sendiri")
        val tw = now()
        while (now() - tw < 6000L) {
            alive()
            if (!cap().has("masterycode")) return
        }
        log("Popup Mastery Code masih terlihat setelah 6 detik")
    }

    // Popup "Hero Guide" (Want to gain an edge? / set the pace? / control the battlefield?), semua varian role.
    // Ditutup lewat X di pojok kanan atas. Tombol GO dan empat tombol biru TIDAK disentuh (membuka halaman panduan)
    // Popup ini muncul berurutan (satu per role) tiap kali ditutup. Karena itu X diketuk 3 kali berturut-turut tanpa membaca layar
    // di antaranya (membaca layar tiap ketukan lebih lambat). Kalau masih terlihat sesudah 3 ketukan, putaran berikutnya mengetuk lagi
    private fun closeHeroGuide(s: Scr): Boolean {
        if (!s.has("startbylearningyourhero")) return false
        for (i in 0 until 3) {
            tapXY(s.w * 0.845f, s.h * 0.12f, "tutup X (popup Hero Guide) " + (i + 1) + "/3", true)
            if (i < 2) sleepMs(150)
        }
        return true
    }

    // Dialog "Pilih Hero" (muncul kalau tombol Top Up Sekarang di popup Hadiah Top Up Pertama terketuk): menelan semua ketukan,
    // termasuk ketukan di X popup di belakangnya. X-nya ada di kanan atas judul dialog (sekitar 80% lebar layar).
    // Diketuk sekali lalu ditunggu sampai hilang; kalau masih ada, Back sekali. Maksimal 2 percobaan beruntun
    private var heroDlgTaps = 0

    private fun closePilihHero(s: Scr): Boolean {
        val t = s.find("pilihhero") ?: return false
        if (heroDlgTaps >= 2) {
            heroDlgTaps = 0
            log("Dialog Pilih Hero tidak menutup setelah 2 percobaan")
            return false
        }
        heroDlgTaps++
        log("Dialog Pilih Hero muncul dan menelan ketukan, ditutup dengan X-nya")
        tapXY(s.w * 0.80f, t.cy, "tutup X (dialog Pilih Hero)", true)
        val t0 = now()
        var gone = false
        while (now() - t0 < 1500L) {
            alive()
            if (!cap().has("pilihhero")) {
                gone = true
                break
            }
        }
        if (gone) {
            heroDlgTaps = 0
        } else {
            log("Dialog Pilih Hero masih terlihat, dicoba Back sekali")
            back()
            sleepMs(300)
        }
        popupSeen = true
        return true
    }

    private var luckyTaps = 0
    private var luckyBlockUntil = 0L

    // Dialog "Keluar" (Kamu masih memiliki hadiah gratis yang belum diklaim hari ini): muncul kalau Back ditekan di lobi. Tutup dengan Back
    private fun dialogKeluar(s: Scr): Boolean =
        s.has("kamumasihmemilikihadiahgratis", "hadiahgratisyangbelum", "belumdiklaimharini") ||
            (s.lines.count { it.norm == "keluar" } >= 2 && s.exact("klaim") != null)

    // Halaman Event/StarLight yang tidak diinginkan: kalau app masuk ke sini (misalnya panduan tangan mengarahkan ke Event),
    // langsung keluar dengan Back. Kata kunci dari screenshot StarLight Fest spin wheel.
    private fun isUnwantedEventPage(s: Scr): Boolean =
        s.has("starlight", "starlightfest", "feastofeternity", "koleksiistimewa", "star2026") ||
            (s.has("lewati") && eventMarks(s) >= 2 && !s.has("hadiahkemenangan"))

    private fun popupsRaw(s: Scr): Boolean {
        // Halaman Event/StarLight yang tidak diinginkan: keluar dengan Back
        if (isUnwantedEventPage(s)) {
            log("Halaman Event/StarLight tidak diinginkan terdeteksi, keluar dengan Back")
            back()
            sleepMs(500)
            return true
        }
        if (dialogKeluar(s)) {
            log("Dialog Keluar (hadiah gratis belum diklaim) muncul: ditutup dengan Back")
            back()
            sleepMs(450)
            return true
        }
        if (resourceFailPopup(s)) return true
        if (closeCamMenu(s)) return true
        if (leaveVideoPages(s)) return true
        if (s.has("masterycode")) {
            waitMasteryCode()
            return true
        }
        if (closeHeroGuide(s)) return true
        // Popup fitur baru (Custom Signal, Panduan Perubahan Map Tahunan, Fitur Mabar tersedia): tanpa X, ditutup dengan Back sekali
        if (s.has("customsignal") || adaPopupMapTahunan(s) || adaFiturBaru(s)) {
            tutupFiturBaru(s)
            return true
        }
        // Tutorial Pertumbuhan Level, urutan yang benar: (1) ikon Battle Spell ditunjuk tangan -> (2) "Selamat! Kamu Mendapatkan"
        // -> Konfirmasi -> (3) "Saatnya mencoba Battle Spell" -> Pergi ke Lobby. Tombol Pergi ke Lobby sudah terlihat sejak langkah 1,
        // jadi jangan diketuk sebelum langkah terakhir.
        if (!isLobby(s) && !isClassicPage(s) && s.has("sudahmembuka", "spellpertamamu", "membukabattle")) {
            tapXY(s.w * 0.285f, s.h * 0.70f, "ikon Battle Spell (posisi tetap)", true)
            return true
        }
        if (!isLobby(s) && !isClassicPage(s) && !isInGame(s) && !isVictory(s) &&
            (s.has("kamumendapatkan") || (s.has("selamat") && s.has("mendapatkan")))) {
            tapXY(s.w * 0.5f, s.h * 0.917f, "Konfirmasi (posisi tetap)", true)
            // Tombol baru aktif sesudah animasi: ketukan beruntun cepat tanpa membaca layar di antaranya
            for (k in 0 until 3) {
                AutoService.inst?.tap(s.w * 0.5f, s.h * 0.917f)
                sleepMs(110)
            }
            return true
        }
        // Halaman Pertumbuhan Level / hadiah level: tombol "Pergi ke Lobby" diketuk di halaman mana pun (langkah 5-6)
        run {
            val l = s.find("pergikelobby") ?: s.find("pergikelobbi") ?: s.find("pergikeloby")
            if (l != null && !isClassicPage(s) && !s.has("sudahmembuka", "spellpertamamu", "membukabattle")) {
                tapLine(l, "Pergi ke Lobby")
                sleepMs(500)
                return true
            }
        }
        if (s.has("pilihhero") && closePilihHero(s)) return true
        if (s.has("bonuslogin") && !eventOpen(s) && !isLobby(s)) {
            log("Layar Bonus Login 9 Hari muncul, ditutup tanpa klaim")
            if (flip++ % 2 == 0) tapArrow(s) else back()
            return true
        }
        // Popup "Bintang Keberuntungan (Super)" / penawaran khusus: judul di bagian atas, atau tulisan "Penawaran khusus" di
        // pita bawahnya. X emas ada di posisi yang sama dengan popup Top Up. Maksimal 3 ketukan, lalu diabaikan 60 detik
        val lk = s.find("bintangkeberuntungan")
        val lp = s.find("penawarankhusus")
        if ((lk != null && lk.cy < s.h * 0.2f) || (lp != null && lp.cy > s.h * 0.85f)) {
            if (now() < luckyBlockUntil) return false
            if (luckyTaps >= 3) {
                luckyBlockUntil = now() + 60_000L
                luckyTaps = 0
                log("Popup Bintang Keberuntungan tidak menutup setelah 3 ketukan X. Diabaikan 60 detik (cek posisi X: 85,6% / 9%)")
                return false
            }
            luckyTaps++
            tapXY(s.w * 0.856f, s.h * 0.09f, "tutup X (popup Bintang Keberuntungan)")
            waitPromoGone()
            return true
        }
        luckyTaps = 0
        val tu = s.find("hadiahtopup")
        if (tu != null && tu.cy < s.h * 0.18f) {
            if (now() < topupBlockUntil) return false
            if (topupTaps >= 3) {
                topupBlockUntil = now() + 60_000L
                topupTaps = 0
                log("Popup Hadiah Top Up Pertama tidak menutup setelah 3 ketukan X. Diabaikan 60 detik (cek posisi X: 85,6% / 7,4%)")
                return false
            }
            topupTaps++
            tapXY(s.w * 0.856f, s.h * 0.09f, "tutup X (Hadiah Top Up Pertama; tidak mengetuk Top Up Sekarang)")
            return true
        }
        topupTaps = 0
        if (tapX(s)) return true
        for (k in listOf("ketukuntukmelanjutkan", "ketukuntuk")) {
            val l = ketukLine(s, k)
            if (l != null) {
                tapLine(l, "lanjut")
                return true
            }
        }
        for (k in listOf("konfirmasi", "ok", "berikutnya", "lewati", "lanjut")) {
            val l = s.exact(k)
            if (l != null) {
                // "lewati" di halaman Event (StarLight dsb) bukan popup — jangan ketuk, biar isUnwantedEventPage handle
                if (k == "lewati" && eventMarks(s) >= 1) continue
                tapLine(l, k)
                return true
            }
        }
        if (s.has("hadiahselamatdatang", "datanguntukmu")) {
            val l = s.exact("klaim")
            if (l != null) {
                tapLine(l, "Klaim hadiah selamat datang")
                return true
            }
        }
        return false
    }

    // Baris "Ketuk untuk ...", tapi bukan petunjuk lobi yang membuka halaman lain (mis. "Ketuk untuk memasuki StarLight.")
    private fun ketukLine(s: Scr, k: String): Line? =
        s.lines.firstOrNull { it.norm.contains(k) && !it.norm.contains("memasuki") && !it.norm.contains("masuki") && !it.norm.contains("starlight") }

    // Popup "System Notice: Loading resources failed. Some resources are probably missing. Do you want to restart the game and
    // re-extract the resources?" Muncul saat layar Memuat Game, sebelum lobby. Ketuk Confirm (game restart dan ekstrak ulang resource).
    // Dibaca di area tengah layar (popup tidak masuk strip bawah). Tombol Confirm = emas, di kanan; Cancel = biru, di kiri.
    private var resFailLast = 0L
    private var resFailTaps = 0

    private fun resourceFailPopup(s: Scr): Boolean {
        if (!s.has("loadingresourcesfailed", "probablymissing", "reextracttheresources", "restartthegameandreextract")) return false
        val b = s.exact("confirm")
        if (b != null) {
            resFailTaps++
            log("Popup System Notice (Loading resources failed) muncul saat memuat game, ketuk Confirm (" + resFailTaps + ")")
            tapLine(b, "Confirm (Loading resources failed)")
        } else {
            // Tulisan Confirm tidak terbaca: tombol emas ada di kanan bawah dialog (sekitar 60% lebar, 67% tinggi)
            resFailTaps++
            log("Popup System Notice terlihat tapi tulisan Confirm tidak terbaca, ketuk posisi tombol (" + resFailTaps + ")")
            tapXY(s.w * 0.60f, s.h * 0.67f, "Confirm (posisi tetap, Loading resources failed)")
        }
        popupSeen = true
        lastActive = now()
        sleepMs(500)
        return true
    }

    // Cek popup di atas hanya tiap ~1,2 detik supaya OCR area tengah tidak memperlambat loop loading
    private fun checkResourceFail(): Boolean {
        if (now() - resFailLast < 1200L) return false
        resFailLast = now()
        return resourceFailPopup(cap(R_SERVER))
    }

    private fun awaitLobby(maxSec: Int, needLoad: Boolean = false): Scr {
        popupSeen = false
        val t0 = now()
        var okCount = 0
        var relaunched = 0
        var quietLogged = false
        var loadLogged = false
        var loadSeen = false
        var roleTries = 0
        val quietMs = 15_000L
        while (now() - t0 < maxSec * 1000L) {
            // Baca hanya strip bawah layar: cukup untuk mengenali "Memuat Game" dan menu lobby
            var s = cap(R_BOTTOM)
            lastActive = now()
            val elapsed = now() - t0
            if (elapsed > (relaunched + 1) * 100_000L && relaunched < 2) {
                relaunched++
                log("Lobby belum muncul, membuka game lagi (" + relaunched + "/2)")
                app?.let { bukaGame(it) }
                sleepS(5.0)
                continue
            }
            // Layar loading ("Memuat Game..." + tulisan persyaratan di bawahnya): jangan diketuk
            if (s.has("memuatgame", "sayatelahmembaca")) {
                okCount = 0
                loadSeen = true
                if (checkResourceFail()) continue
                if (!loadLogged) {
                    log("Game sedang memuat (tidak mengetuk apa pun)")
                    loadLogged = true
                }
                continue
            }
            // Setelah ganti server: lobby lama bisa terlihat sebentar sebelum game restart
            val tooEarly = needLoad && !loadSeen && elapsed < 25_000L
            if (isLobby(s) && !tooEarly) {
                okCount++
                if (okCount >= 2) {
                    log("Lobby terdeteksi")
                    return s
                }
                continue
            }
            okCount = 0
            if (elapsed < quietMs || tooEarly) {
                // Game masih memuat: jangan mengetuk apa pun
                if (!quietLogged) {
                    log("Game sedang loading, menunggu (tidak mengetuk apa pun)")
                    quietLogged = true
                }
                if (checkResourceFail()) continue
                continue
            }
            // Strip bawah tidak cukup mengenali layar: baca layar penuh
            s = cap()
            if (isLobby(s) && !eventOpen(s) && !isServerList(s)) {
                okCount++
                if (okCount >= 2) {
                    log("Lobby terdeteksi")
                    return s
                }
                continue
            }
            if (!popups(s)) {
                log("Menunggu layar dikenali...")
            }
        }
        throw Stop("Lobby tidak terdeteksi (jalankan Diagnosa di tab Log dan kirim lognya)")
    }

    private fun lum(c: Int): Int {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return (r * 30 + g * 59 + b * 11) / 100
    }

    private fun maxLum(bmp: Bitmap, r: Rect): Int {
        var m = 0
        val x0 = r.left.coerceIn(0, bmp.width - 1)
        val x1 = r.right.coerceIn(x0 + 1, bmp.width)
        val y0 = r.top.coerceIn(0, bmp.height - 1)
        val y1 = r.bottom.coerceIn(y0 + 1, bmp.height)
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val l = lum(bmp.getPixel(x, y))
                if (l > m) m = l
                x += 2
            }
            y += 2
        }
        return m
    }

    // Popup apa pun menggelapkan lobby di belakangnya. Kalau tulisan "Event" di lobby tampak redup,
    // ketuk X di pojok kanan atas (x 85,6%, y 9%, pas untuk popup Top Up Pertama dan Bintang Keberuntungan).
    private var darkSince = 0L
    private var darkMiss = 0
    private var darkBacks = 0
    private var cardBacks = 0

    // Menu kecil dari tombol kamera melayang di kanan atas (Rekam, Tutup, Video Saya)
    private fun camMenuOpen(s: Scr): Boolean =
        s.lines.any { it.norm == "rekam" && it.cx > s.w * 0.80f && it.cy < s.h * 0.30f }

    // Tutup menu itu dengan Back; kalau masih terlihat, ketuk tombol kameranya (membuka dan menutup menu)
    private fun closeCamMenu(s: Scr): Boolean {
        if (!camMenuOpen(s)) return false
        log("Menu tombol kamera (Rekam, Tutup, Video Saya) terbuka, ditutup dengan Back")
        back()
        lastActive = now()
        val t0 = now()
        var c = cap()
        while (now() - t0 < 1500L && camMenuOpen(c)) {
            alive()
            c = cap()
        }
        if (camMenuOpen(c)) {
            log("Menu kamera masih terbuka, mengetuk tombol kameranya untuk menutup")
            tapXY(c.w * 0.889f, c.h * 0.102f, "tombol kamera (tutup menu)", true)
            waitScreenChange(c.all)
        }
        return true
    }

    private fun isVideoPage(s: Scr): Boolean = pageTitle(s).contains("videosaya") || s.has("panduansorotan")

    private fun isCatatanDialog(s: Scr): Boolean = s.has("otorisasitampilanavatarkustom", "datapertandinganmu")

    // Halaman Video Saya, Panduan Sorotan, dan dialog Catatan terbuka karena salah ketuk: keluar. Dialog Catatan
    // (persetujuan unggah data pertandingan ke luar negeri) DIBATALKAN, tidak disetujui
    private fun leaveVideoPages(s: Scr): Boolean {
        if (isCatatanDialog(s)) {
            log("Dialog Catatan (unggah data pertandingan) terbuka: dibatalkan, tidak disetujui")
            val b = s.exact("batal")
            if (b != null) tapLine(b, "Batal (dialog Catatan)") else back()
            waitScreenChange(s.all)
            return true
        }
        if (isVideoPage(s)) {
            log("Halaman Video Saya terbuka (salah ketuk), keluar dengan Back")
            back()
            lastActive = now()
            waitScreenChange(s.all)
            return true
        }
        return false
    }

    private val CARD_ICON_Y = floatArrayOf(0.5032f, 0.5801f, 0.6574f, 0.7356f)
    private val CARD_RING_R = doubleArrayOf(0.90, 0.97)

    // Kartu profil singkat (muncul di lobi sesudah Back dari akun target) dikenali dari empat ikon bundar di sisi kanannya:
    // susunan, obrolan, tambah teman, pencarian. Ikon itu tetap dan tidak pernah berubah (beda dengan angka dan tulisan di
    // kartu), dan posisinya dalam persen layar, jadi sama di iQOO dan Realme. Tiap ikon dicek dari cincin hijau-biru di
    // pinggirnya (16 titik) dan gambar terang di dalamnya. Cukup 3 dari 4 ikon
    private fun cardUp(s: Scr): Boolean {
        val bm = s.bmp
        val w = bm.width
        val h = bm.height
        val cx = w * 0.7167f
        val r = h * 0.0287f
        val hsv = FloatArray(3)
        var found = 0
        for (i in CARD_ICON_Y.indices) {
            if (i == 2 && found == 0) return false
            val cy = h * CARD_ICON_Y[i]
            var ring = 0
            for (k in 0 until 16) {
                val a = Math.PI * 2.0 * k / 16.0
                var ok = false
                for (rr in CARD_RING_R) {
                    val x = (cx + Math.cos(a) * r * rr).toInt()
                    val y = (cy + Math.sin(a) * r * rr).toInt()
                    if (x in 0 until w && y in 0 until h) {
                        android.graphics.Color.colorToHSV(bm.getPixel(x, y), hsv)
                        if (hsv[0] in 173f..202f && hsv[1] > 0.40f && hsv[2] > 0.35f) {
                            ok = true
                            break
                        }
                    }
                }
                if (ok) ring++
            }
            if (ring < 12) continue
            var light = 0
            var tot = 0
            val rad = (r * 0.6f).toInt()
            var dy = -rad
            while (dy <= rad) {
                var dx = -rad
                while (dx <= rad) {
                    if (dx * dx + dy * dy <= rad * rad) {
                        tot++
                        val x = (cx + dx).toInt()
                        val y = (cy + dy).toInt()
                        if (x in 0 until w && y in 0 until h) {
                            android.graphics.Color.colorToHSV(bm.getPixel(x, y), hsv)
                            if (hsv[2] > 0.70f && hsv[1] < 0.50f) light++
                        }
                    }
                    dx += 3
                }
                dy += 3
            }
            if (tot > 0 && light * 100 >= tot * 8) found++
        }
        return found >= 3
    }

    // Tutup kartu profil singkat dengan ketukan di luar kartu (titik X lama). Kartu sudah terkonfirmasi lewat 4 ikon, jadi
    // ketukan itu mendarat di lapisan gelap dan tidak bisa mengenai ikon video di bawahnya. Sesudah ketukan, layar dibaca
    // sampai ikon hilang (tanpa jeda tetap; ketukan kedua hanya kalau 3 pembacaan berturut-turut masih menampilkan kartu,
    // supaya tidak jatuh di lobi yang sedang memudar). Percobaan ke-3 memakai Back, ke-4 berhenti dengan pesan.
    // Back sendirian tidak menutup kartu ini
    private fun closeProfileCard(s: Scr): Boolean {
        popupSeen = true
        cardBacks++
        if (cardBacks > 3) {
            cardBacks = 0
            val msg = "Kartu profil singkat di lobi tidak bisa ditutup (ketuk di luar 2x dan Back). Periksa layar, lalu mulai lagi"
            log(msg)
            throw Stop(msg)
        }
        val t0 = now()
        if (cardBacks <= 2) {
            log("Kartu profil singkat terbuka di lobi (dikenali dari 4 ikon), ketuk di luar kartu " + cardBacks + "/2")
            tapXY(s.w * 0.856f, s.h * 0.09f, "tutup kartu profil (di luar kartu)", true)
        } else {
            log("Kartu profil singkat belum tertutup, memakai Back")
            back()
        }
        var still = 0
        while (still < 3) {
            alive()
            val c = cap(R_TOP)
            if (!cardUp(c)) {
                cardBacks = 0
                log("Kartu profil singkat tertutup (" + (now() - t0) + " ms)")
                return true
            }
            still++
        }
        return true
    }

    // Sesudah mengetuk X popup promo: baca layar sampai tulisan judul popup hilang (maks 3 pembacaan berturut-turut yang masih
    // menampilkannya). Mencegah ketukan X kedua jatuh di lobi yang sedang memudar, tempat ikon video berada
    private fun waitPromoGone() {
        var n = 0
        while (n < 3) {
            alive()
            val c = cap(R_TOP)
            val hu = c.find("hadiahtopup")
            val still = (hu != null && hu.cy < c.h * 0.18f) || c.has("bintangkeberuntungan", "penawarankhusus", "topupsekarang", "skindeluxe")
            if (!still) return
            n++
        }
    }

    private fun darkPopupX(s: Scr): Boolean {
        if (closeCamMenu(s)) {
            popupSeen = true
            return true
        }
        if (cardUp(s)) return closeProfileCard(s)
        cardBacks = 0
        if (!isLobby(s)) return false
        // Lobi digelapkan panduan tutorial (ikon tangan / tooltip Hadiah Pertumbuhan Level): bukan popup, jangan dibaca ulang atau di-Back
        if (s.has("pertumbuhanlevel", "levelgrowth") || cariTangan(s) != null) return false
        val ev = s.exact("event") ?: return false
        val m = maxLum(s.bmp, ev.r)
        if (m >= 175) {
            darkTaps = 0
            darkSince = 0L
            darkMiss = 0
            darkBacks = 0
            return false
        }
        if (s.has("masterycode")) {
            waitMasteryCode()
            popupSeen = true
            return true
        }
        if (closeHeroGuide(s)) {
            popupSeen = true
            return true
        }
        // Dialog "Pilih Hero" menelan ketukan di X popup belakangnya: tutup dulu dialog itu
        if (s.has("pilihhero") && closePilihHero(s)) {
            popupSeen = true
            return true
        }
        // Dialog "Keluar" (Kamu masih memiliki hadiah gratis yang belum diklaim hari ini): tidak punya tombol X, tutup dengan Back
        if (s.has("hadiahgratis", "belumdiklaimhariini")) {
            log("Dialog Keluar (hadiah gratis belum diklaim) ditutup dengan Back")
            back()
            popupSeen = true
            return true
        }
        if (now() < topupBlockUntil) return false
        // Titik X di kanan atas berdekatan dengan tombol kamera melayang, jadi TIDAK diketuk tanpa bukti ada popup promo
        // yang punya X di situ. Tanpa bukti, hanya baca layar lagi (Hero Guide dan popup lain dikenali lewat jalurnya sendiri)
        val hu = s.find("hadiahtopup")
        val evidence = (hu != null && hu.cy < s.h * 0.18f) || s.has("bintangkeberuntungan", "penawarankhusus", "topupsekarang", "skindeluxe")
        if (!evidence) {
            if (darkSince == 0L) darkSince = now()
            darkMiss++
            // Empat pembacaan berturut-turut tetap gelap tanpa popup yang dikenali: Back (maks 2x), lalu satu ketukan X cadangan.
            // Lobi yang baru berhenti memudar (sesudah popup hilang) terang lagi sebelum itu, jadi tidak di-Back
            if (darkMiss >= 4) {
                darkMiss = 0
                if (darkBacks < 2) {
                    darkBacks++
                    log("Lobi gelap dan popupnya tidak dikenali, ditutup dengan Back " + darkBacks + "/2. Teks layar: " + s.all.take(100))
                    back()
                    waitScreenChange(s.all)
                    return true
                }
                if (darkTaps < 1) {
                    darkTaps++
                    log("Lobi masih gelap sesudah Back 2x, ketukan X cadangan")
                    tapXY(s.w * 0.856f, s.h * 0.09f, "tutup X (cadangan)", true)
                    return true
                }
            }
            if (now() - darkSince > 6000L) {
                darkSince = 0L
                val msg = "Lobi gelap lebih dari 6 detik dan popupnya tidak dikenali (tidak ada yang diketuk). Periksa layar, lalu mulai lagi. Teks layar: " + s.all.take(140)
                log(msg)
                throw Stop(msg)
            }
            return true
        }
        darkSince = 0L
        // Maksimal 3 ketukan X (tanpa jeda tambahan, tanpa dibatalkan penjaga ketukan dobel). Kalau popup masih ada,
        // bot BERHENTI dengan pesan supaya Anda yang memeriksa layarnya.
        if (darkTaps >= 3) {
            darkTaps = 0
            val msg = "Popup di lobby tidak bisa ditutup setelah 3 ketukan X. Periksa layar, lalu mulai lagi"
            log(msg)
            throw Stop(msg)
        }
        darkTaps++
        val promo = s.has("bintangkeberuntungan") || s.has("penawarankhusus")
        log("Lobby tampak gelap (kecerahan teks Event " + m + ")" + (if (promo) ", popup promo layar penuh" else ", kemungkinan ada popup") + ", ketukan X " + darkTaps + "/3")
        tapXY(s.w * 0.856f, s.h * 0.09f, "tutup X (popup)", true)
        popupSeen = true
        waitPromoGone()
        return true
    }

    // Waktu tunggu lobby (milidetik) HANYA dipakai kalau lobby langsung muncul setelah loading tanpa popup apa pun.
    // Kalau popup (misalnya Bonus Login 9 Hari) sudah muncul dan ditutup sebelum lobby, tidak menunggu lagi:
    // cukup tutup popup yang masih terlihat, lalu lanjut.
    private fun settleLobby(cepat: Boolean = false) {
        if (cepat) {
            // Sesudah match: lobi sudah dikenali lewat OCR, cukup satu pemeriksaan popup (tanpa menunggu waktu tenang)
            val s = cap()
            if (popups(s) || darkPopupX(s)) closeRemainingPopups()
            return
        }
        if (popupSeen) {
            log("Popup sudah muncul sebelum lobby, waktu tunggu lobby dilewati")
            closeRemainingPopups()
            return
        }
        val calm = Prefs.lobbyCalm.toLong().coerceIn(0L, 30_000L)
        log("Lobby langsung muncul tanpa popup, menunggu paling lama " + calm + " ms untuk popup")
        val t0 = now()
        while (now() - t0 < calm) {
            val s = cap()
            if (isLobby(s) && (s.has("pertumbuhanlevel", "levelgrowth") || cariTangan(s) != null)) {
                log("Panduan tutorial terlihat di lobi: waktu tunggu dilewati")
                return
            }
            if (popups(s) || darkPopupX(s)) {
                // Popup pertama sudah muncul dan ditutup: tidak menunggu lagi, hanya periksa popup susulan
                log("Popup muncul dan ditutup, waktu tunggu lobby selesai")
                closeRemainingPopups()
                return
            }
        }
    }

    // Tutup popup susulan yang langsung muncul setelah popup sebelumnya. Selesai kalau satu pemeriksaan bersih.
    private fun closeRemainingPopups() {
        var guard = 0
        while (guard < 4) {
            guard++
            val s = cap()
            if (!(popups(s) || darkPopupX(s))) return
        }
    }

    private fun backToLobby() {
        var promoX = 0
        for (i in 0 until 12) {
            val s = cap()
            // Kartu profil singkat menggelapkan lobi sehingga layar tidak dikenali sebagai lobi: periksa lewat ikonnya lebih dulu
            if (cardUp(s)) {
                closeProfileCard(s)
                continue
            }
            val halamanHadiah = eventOpen(s) || eventMarks(s) >= 2 || s.has("kemenangantotal")
            if (isLobby(s) && !halamanHadiah && !isServerList(s)) {
                // Menu bawah lobi (Persiapan/Inventori) terlihat: langsung dianggap lobi. Popup sisa ditangani langkah berikutnya
                if (!s.has("persiapan", "inventori", "koleksi") && darkPopupX(s)) continue
                log("Sudah di lobi")
                return
            }
            if (halamanHadiah) log("Halaman Hadiah/Event masih terbuka, kembali ke lobi (putaran ${i + 1})")
            // Popup promo Top Up ("Top Up Sekarang" / "Skin Deluxe") sering muncul sesudah beli. Back sering diabaikan,
            // jadi tutup lewat X emas di pojok kanan atas (posisi tetap). Dua kali saja, sisanya cara biasa
            if (promoX < 2 && s.has("topupsekarang", "skindeluxe")) {
                promoX++
                tapXY(s.w * 0.858f, s.h * 0.076f, "tutup X (popup Top Up)")
                waitScreenChange(s.all)
                continue
            }
            if (!isServerList(s) && tapX(s)) {
                // X sudah diketuk
            } else if (i % 2 == 0 && (halamanHadiah || isAccount(s) || isProfile(s) || isServerList(s))) {
                tapArrow(s)
                log("Ketuk panah kembali")
            } else {
                back("Back ke lobi")
            }
            // Satu aksi saja, lalu tunggu layar berubah dan tenang. Aksi diulang (panah lagi atau Back) hanya kalau dalam
            // 1,3 dtk layar belum berubah. Supaya Back tidak jatuh di lobi (memunculkan dialog Keluar)
            waitScreenSettled(s.all)
        }
        throw Stop("Gagal kembali ke lobby")
    }

    private fun waitEventOpen(sec: Double): Boolean {
        val t0 = now()
        while (now() - t0 < (sec * 1000).toLong()) {
            if (eventOpen(cap(R_EVT))) return true
        }
        return false
    }

    // Judul halaman: tulisan di pojok kiri atas
    // Judul halaman Event (mulai sesudah panah kembali, x > 14% lebar). Nama pemain di lobby ada di sebelah kiri dan tidak ikut
    private fun eventTitle(s: Scr): String =
        s.lines.filter { it.cy < s.h * 0.09f && it.r.left > s.w * 0.14f && it.cx < s.w * 0.5f && it.norm.length >= 4 && it.norm != "new" }
            .sortedBy { it.cx }.joinToString("") { it.norm }

    // Tunggu sampai isi layar berubah dari yang tadi (maksimal 1,5 detik)
    // Sesudah SATU ketukan panah atau Back: tunggu layar berubah (maks 1,3 dtk; kalau tidak berubah, aksi boleh diulang).
    // Kalau layar berubah, tunggu sampai dikenali sebagai lobi atau TENANG (dua bacaan berturut-turut sama, maks 3 dtk),
    // supaya aksi berikutnya tidak jatuh di tengah transisi (Back di lobi memunculkan dialog Keluar)
    private fun waitScreenSettled(prev: String) {
        val t0 = now()
        var deadline = t0 + 1300L
        var changed = false
        var last = prev
        while (now() < deadline) {
            alive()
            val c = cap()
            if (c.all != prev) {
                if (isLobby(c) && !eventOpen(c) && !isServerList(c)) return
                if (changed && c.all == last) return
                if (!changed) {
                    changed = true
                    deadline = t0 + 3000L
                }
            }
            last = c.all
        }
    }

    private fun waitScreenChange(prev: String) {
        val t0 = now()
        while (now() - t0 < 1500L) {
            alive()
            if (cap().all != prev) return
            sleepMs(40)
        }
    }

    private fun pageTitle(s: Scr): String =
        s.lines.filter { it.cy < s.h * 0.10f && it.cx < s.w * 0.5f }.sortedBy { it.cx }.joinToString("") { it.norm }

    // Setelah mengetuk sebuah tab: tunggu SABAR sampai halaman Hadiah terbuka (jaringan lambat bisa butuh
    // beberapa detik). Pindah ke tab lain hanya kalau halaman sudah jelas bukan Hadiah.
    private fun waitHadiah(before: String): Boolean {
        val t0 = now()
        var titled = false
        while (now() - t0 < 9000L) {
            val m = cap(R_EVT)
            if (eventOpen(m)) return true
            if (m.exact("hadiah") != null) {
                if (!titled) {
                    titled = true
                    log("Judul Hadiah terlihat, menunggu daftar menu dimuat...")
                }
            } else if (!titled && before.isNotEmpty() && now() - t0 > 2500L) {
                val t = pageTitle(m)
                if (t.isNotEmpty()) {
                    log("Halaman setelah ketuk tab: judul \"" + t + "\" (bukan Hadiah)")
                    return false
                }
            }
        }
        return titled
    }

    // Jumlah minimal item menu di daftar kiri halaman Hadiah (petir) supaya dianggap sudah selesai dimuat
    private val MIN_MENU = 5

    private fun menuCount(s: Scr): Int {
        val ys = s.lines.filter {
            it.cx > s.w * 0.07f && it.cx < s.w * 0.24f && it.cy > s.h * 0.12f && it.cy < s.h * 0.97f &&
                it.norm.length >= 3 && it.norm != "new"
        }.map { it.cy }.sorted()
        var n = 0
        var prev = -1f
        for (y in ys) {
            if (prev < 0f || y - prev > s.h * 0.06f) n++
            prev = y
        }
        return n
    }

    // Halaman Toko (salah ketuk): judul "TOKO" besar di pojok kiri atas. Tulisan "Toko" di lobi ada di kolom kiri tengah, bukan di atas
    private fun isTokoPage(s: Scr): Boolean =
        s.lines.any { it.norm == "toko" && it.cy < s.h * 0.14f && it.cx < s.w * 0.45f }

    // Popup Stardust: muncul kalau ikon di atas petir terketuk (halaman Stardust Vault). Tanpa X dan Back diabaikan; harus
    // diikuti Berikutnya, Konfirmasi, lalu Klaim. Tiap tombol hanya diketuk kalau tulisan halamannya juga terlihat, dan
    // tombol "Kembali" di halaman kedua tidak pernah diketuk. Sesudah selesai, halaman Stardust Vault dengan kolom ikon kiri
    // terlihat, dan petir langsung diketuk dari situ (tanpa Back ke lobi)
    private var starLast = ""
    private var starWait = -1
    private var starSteps = 0

    private fun stardustStep(s: Scr): Boolean {
        val next = s.lines.firstOrNull { it.norm == "berikutnya" }
        val conf = s.lines.firstOrNull { it.norm == "konfirmasi" }
        val klaim = s.lines.firstOrNull { it.norm == "klaim" }
        var target: Line? = null
        var name = ""
        if (next != null && s.has("stardustblessing", "stardustcrystal")) {
            target = next
            name = "Berikutnya"
        } else if (conf != null && s.has("menukarkanskin")) {
            target = conf
            name = "Konfirmasi"
        } else if (klaim != null && s.has("hadiahselamatdatang")) {
            target = klaim
            name = "Klaim"
        }
        if (target == null) {
            if (starLast.isNotEmpty()) {
                log("Popup Stardust selesai")
                starLast = ""
                starWait = -1
                starSteps = 0
                return false
            }
            return false
        }
        // Halaman yang sama masih terlihat: baca lagi (maks 3 pembacaan) sebelum mengetuk ulang tombolnya
        if (starLast == name && starWait in 0..2) {
            starWait++
            return true
        }
        starSteps++
        if (starSteps > 12) {
            starSteps = 0
            throw Stop("Popup Stardust tidak selesai (tombol " + name + " berulang). Periksa layar, lalu mulai lagi")
        }
        starLast = name
        starWait = 0
        log("Popup Stardust (tanpa X, tidak bisa di-Back): ketuk " + name)
        tapLine(target, name + " (popup Stardust)")
        return true
    }

    // Halaman Stardust Vault (tab Event yang bukan Hadiah): kolom ikon kiri terlihat, jadi petir bisa langsung diketuk dari sini
    private fun stardustPage(s: Scr): Boolean = s.has("stardustvault") && s.has("sorotan", "riwayat")

    private fun openEvent() {
        var tokoBacks = 0
        var eventMiss = 0   // berapa pembacaan lobi berturut-turut tanpa tulisan atau gambar Event
        var tappedEvent = false   // Event sudah diketuk, halamannya belum terbuka
        var unchanged = 0         // pembacaan lobi berturut-turut yang tampak tidak berubah sesudah Event diketuk
        // Posisi tulisan Event (dan Toko) di pembacaan sebelumnya: ketukan baru boleh kalau posisinya sama di dua pembacaan
        // berturut-turut (lobi sudah berhenti bergeser). Diisi dari pembacaan lobi terakhir kalau masih baru
        var prevEvX = -1f
        var prevEvY = -1f
        if (lobbyEvX >= 0f && now() - lobbyEvT < 4000L) {
            prevEvX = lobbyEvX
            prevEvY = lobbyEvY
        }
        var prevTkX = -1f
        var prevTkY = -1f
        // Halaman tak dikenal yang isinya sama di pembacaan berturut-turut
        var unkSig = ""
        var unkSame = 0
        var lastTxt = ""
        var recoveries = 0
        var failTaps = 0
        // Halaman Hadiah terbuka tapi menunya belum lengkap (3 atau kurang): Back ke lobby, lalu Event dan petir lagi
        fun recoverShort(n: Int) {
            recoveries++
            if (recoveries > 3) throw Stop("Menu Hadiah hanya " + n + " item (minimal " + MIN_MENU + ") setelah 3 kali pemulihan")
            log("Menu Hadiah baru " + n + " item (belum selesai dimuat). Back ke lobby, lalu ketuk Event dan petir lagi")
            back()
            failTaps = 0
        }
        val tEnd = now() + 45_000L
        outer@ while (now() < tEnd) {
            val s = cap()
            // Salah masuk Toko: langsung Back (dikenali dari judul "Toko"), tanpa menunggu
            if (isTokoPage(s)) {
                tokoBacks++
                if (tokoBacks > 4) throw Stop("Halaman Toko terus terbuka sesudah mengetuk Event (4 kali). Periksa tata letak lobi")
                log("Halaman Toko terbuka (salah ketuk Event), langsung Back (" + tokoBacks + ")")
                back()
                tappedEvent = false
                unchanged = 0
                prevEvX = -1f
                waitScreenChange(s.all)
                continue
            }
            if (stardustStep(s)) {
                // Popup Stardust sedang diikuti: sesudahnya petir dicari lewat template di seluruh kolom kiri
                failTaps = maxOf(failTaps, 1)
                tappedEvent = false
                continue
            }
            if (eventOpen(s)) {
                val n = menuCount(s)
                if (n > MIN_MENU - 1) return
                recoverShort(n)
                continue
            }
            if (s.exact("hadiah") != null && waitHadiah("")) {
                val n = menuCount(cap())
                if (n > MIN_MENU - 1) return
                recoverShort(n)
                continue
            }
            if (popups(s)) continue
            lastTxt = s.all.take(120)
            // Halaman Event dikenali dari menu kirinya (dua tanda atau lebih), walau layar juga terbaca mirip lobi
            val onEventPage = eventMarks(s) >= 2 || stardustPage(s)
            if (!isLobby(s) || onEventPage) {
                // Bukan lobby dan bukan halaman Hadiah. Hanya mengetuk kolom ikon kiri kalau layar jelas halaman Event.
                val before = pageTitle(s)
                // Halaman yang salah (Berita, Chat Global): ikon petir di situ bukan tab Hadiah. Back ke lobby, lalu Event dan petir lagi
                val videoPg = before.contains("videosaya") || s.has("panduansorotan")
                if (before == "berita" || before == "semuateman" || s.has("chatglobal") || videoPg) {
                    recoveries++
                    if (recoveries > 3) throw Stop("Halaman salah terus terbuka (" + before + "), bukan Hadiah. Teks layar: " + lastTxt)
                    log("Halaman " + (if (videoPg) "Video Saya" else if (before == "berita") "Berita (Patch Note)" else "Chat Global") + " terbuka, bukan Hadiah. Back ke lobby, lalu ketuk Event dan petir lagi")
                    back()
                    failTaps = 0
                    continue
                }
                // Layar belum jelas: baca ulang tanpa mengetuk kolom kiri. Kalau isinya sama di 3 pembacaan berturut-turut dan cukup
                // banyak tulisan (bukan layar kosong saat memuat), itu halaman yang salah: Back ke lobi, lalu Event diketuk lagi
                if (eventTitle(s).isEmpty() && !onEventPage) {
                    val sig = s.all.take(160)
                    if (sig == unkSig) unkSame++ else {
                        unkSig = sig
                        unkSame = 1
                    }
                    if (sig.length >= 60 && unkSame >= 3) {
                        recoveries++
                        if (recoveries > 3) throw Stop("Halaman salah terus terbuka (bukan Event). Teks layar: " + lastTxt)
                        log("Halaman tidak dikenal terbuka (isinya sama di 3 pembacaan), bukan Event. Back ke lobby, lalu ketuk Event lagi. Teks: " + sig.take(60))
                        back()
                        failTaps = 0
                        tappedEvent = false
                        unchanged = 0
                        unkSig = ""
                        unkSame = 0
                        continue
                    }
                    continue
                }
                unkSig = ""
                unkSame = 0
                tappedEvent = false
                // Baca ulang sebelum mengetuk di titik berisiko
                val s2 = cap()
                if ((isLobby(s2) && eventMarks(s2) < 2) || eventOpen(s2)) continue
                val t2 = pageTitle(s2)
                var tx = s2.w * PETIR_X
                var ty = s2.h * PETIR_Y
                var how = "posisi tetap petir"
                tapXY(tx, ty, "tab Hadiah (" + how + ") di " + tx.toInt() + "," + ty.toInt() + " (layar " + s2.w + "x" + s2.h + ")")
                if (waitHadiah(t2)) {
                    val n = menuCount(cap())
                    if (n > MIN_MENU - 1) return
                    recoverShort(n)
                    continue
                }
                failTaps++
                if (failTaps >= 2) {
                    recoveries++
                    if (recoveries > 3) throw Stop("Tab Hadiah tidak terbuka setelah beberapa kali. Teks layar: " + lastTxt)
                    log("Tab Hadiah belum terbuka setelah " + failTaps + " ketukan. Back ke lobby, lalu ketuk Event dan petir lagi")
                    back()
                    failTaps = 0
                }
                continue
            }
            if (darkPopupX(s)) continue
            val l = s.exact("event")
            if (l != null) {
                eventMiss = 0
                val same = prevEvX >= 0f && Math.abs(l.cx - prevEvX) < s.w * 0.01f && Math.abs(l.cy - prevEvY) < s.h * 0.01f
                prevEvX = l.cx
                prevEvY = l.cy
                // Lobi masih bergeser (ikon pindah saat memuat): baca lagi, jangan mengetuk
                if (!same) {
                    unchanged = 0
                    continue
                }
                // Sudah diketuk tapi halaman belum terbuka: ketuk ulang hanya kalau lobi tampak tidak berubah di 4 pembacaan berturut-turut
                if (tappedEvent) {
                    unchanged++
                    if (unchanged < 2) continue
                    log("Event belum terbuka sesudah " + unchanged + " pembacaan lobi tanpa perubahan, ketuk ulang")
                }
                unchanged = 0
                tappedEvent = true
                tapLine(l, "Event")
                continue
            }
            // Tulisan dan gambar Event tidak terbaca. Tidak ada ketukan titik tetap (bisa jatuh di Toko): Event dihitung
            // satu baris di bawah Toko (jarak 10,8% tinggi layar) kalau Toko terbaca; kalau tidak, hanya membaca ulang
            eventMiss++
            if (eventMiss < 2) continue
            val tk = s.exact("toko")
            if (tk != null) {
                val sameTk = prevTkX >= 0f && Math.abs(tk.cx - prevTkX) < s.w * 0.01f && Math.abs(tk.cy - prevTkY) < s.h * 0.01f
                prevTkX = tk.cx
                prevTkY = tk.cy
                if (!sameTk) continue
                if (tappedEvent) {
                    unchanged++
                    if (unchanged < 2) continue
                }
                unchanged = 0
                tappedEvent = true
                log("Tulisan Event tidak terbaca, Event dihitung satu baris di bawah Toko")
                tapXY(tk.cx, tk.cy + s.h * 0.1083f, "Event (satu baris di bawah Toko)")
                continue
            }
            if (eventMiss == 2 || eventMiss % 10 == 0) log("Tulisan Event dan Toko tidak terbaca, membaca ulang tanpa mengetuk. Teks lobi: " + s.all.take(100))
        }
        throw Stop("Halaman Hadiah di Event tidak terbuka. Teks layar terakhir: " + lastTxt)
    }

    private fun openMenu(keys: List<String>, panelKeys: List<String>): Scr? {
        var seen = ""
        for (i in 0 until 7) {
            val s = cap(R_MENU)
            seen = s.all
            for (k in keys) {
                val l = s.find(k)
                if (l != null) {
                    tapLine(l, "menu " + k)
                    return waitPanel(panelKeys)
                }
            }
            val x = s.w * 0.15f
            if (i < 3) swipe(x, s.h * 0.75f, x, s.h * 0.30f) else swipe(x, s.h * 0.30f, x, s.h * 0.75f)
        }
        log("Menu " + keys[0] + " tidak ketemu setelah 7 kali baca. Teks menu terakhir: " + seen.take(140))
        return null
    }

    private fun okBtn(s: Scr): Line? = s.exact("ok") ?: s.exact("konfirmasi") ?: s.exact("berikutnya")

    private fun waitOk(maxMs: Long = 4000L): Boolean {
        val t0 = now()
        while (now() - t0 < maxMs) {
            val s = cap(R_OK)
            val b = okBtn(s)
            if (b != null) {
                tapLine(b, "OK")
                lastActive = now()
                // tunggu popup hilang (tanpa tidur tetap); ulangi OK kalau masih terlihat
                var tapT = now()
                val t1 = now()
                while (now() - t1 < 2500L) {
                    val s2 = cap(R_OK)
                    val b2 = okBtn(s2) ?: break
                    if (now() - tapT > 900L) {
                        tapLine(b2, "OK diulang")
                        tapT = now()
                    }
                }
                return true
            }
            val c = ketukLine(s, "ketukuntuk")
            if (c != null) {
                tapLine(c, "lanjut")
                return true
            }
        }
        return false
    }

    private fun claimLoop(label: String, maxRounds: Int, first: Scr? = null): Int {
        var claimed = 0
        var idle = 0
        var noPopup = 0
        for (round in 0 until maxRounds) {
            if (now() - serverT0 > 15 * 60_000L) throw Stop("Server ini terlalu lama (>15 menit)")
            var s = if (round == 0 && first != null) first else cap(R_PANEL)
            var l = s.exact("klaimsemua") ?: s.find("klaimsemua") ?: s.exactAll("klaim").firstOrNull()
            if (round == 0 && l == null && !s.has("sudahdiklaim")) {
                // Tombol kadang belum tergambar (panel masih memuat): baca ulang sampai 3 kali berturut-turut sebelum dianggap tidak ada
                var reads = 0
                while (l == null && reads < 1 && !s.has("sudahdiklaim")) {
                    alive()
                    s = cap(R_PANEL)
                    l = s.exact("klaimsemua") ?: s.find("klaimsemua") ?: s.exactAll("klaim").firstOrNull()
                    reads++
                }
            }
            if (s.has("sudahdiklaim")) {
                log(label + ": sudah diklaim")
                break
            }
            if (l == null) {
                log(label + ": tombol Klaim Semua tidak ada (hadiah sudah diklaim semua)")
                break
            }
            tapLine(l, "Klaim (" + label + ")")
            claimed++
            lastActive = now()
            // Popup OK tidak pernah muncul sesudah Klaim Semua: tidak menunggu, langsung selesai (panah kembali diketuk pemanggil)
            val got = true
            if (got) {
                // "Klaim Semua" sudah mengklaim semuanya: langsung selesai, tanpa baca panel lagi
                noPopup = 0
                break
            } else {
                // tidak ada popup hadiah: kemungkinan sudah terklaim semua, berhenti
                noPopup++
                if (noPopup >= 1) break
            }
        }
        return claimed
    }



    // Halaman Event hilang atau tertutup popup promo di tengah klaim
    private var eventLost = false

    private fun eventScreenLost(f: Scr): Boolean =
        f.has("topuppertama", "topupsekar", "pilihhero", "bintangkeberuntungan", "penawarankhusus") || (isLobby(f) && !eventOpen(f))

    private fun noteEventLost(why: String, f: Scr) {
        eventLost = true
        log("Halaman Event tertutup atau terhalang popup (" + why + "). Teks layar: " + f.all.take(120))
    }

    // Langkah 17-20: Event -> petir -> "Hadiah Kemenangan" -> "Klaim Semua".
    // Kalau menu "Hadiah Kemenangan" tidak ada: kembali ke lobi, buka Event + petir lagi, cari lagi (maks 3 kali).
    // Ikon Event ada di lobi? Dibaca 2 kali; dianggap tidak ada kalau Toko terbaca tapi tulisan Event tidak pernah muncul
    private fun eventIkonAda(): Boolean {
        var toko = 0
        var baca = 0
        var i = 0
        while (i < 8 && baca < 2) {
            i++
            alive()
            val s = cap()
            if (popups(s)) continue
            if (!isLobby(s)) return true
            if (s.exact("event") != null || eventMarks(s) >= 2) return true
            baca++
            if (s.exact("toko") != null) toko++
        }
        return toko < 2
    }

    // Ikon Event belum muncul: ketuk Hero (halaman daftar hero), lalu Back; sesudahnya ikon Event muncul
    private fun heroLaluBack() {
        for (i in 0 until 3) {
            alive()
            val s = cap()
            if (popups(s)) continue
            val h = s.lines.firstOrNull { it.norm == "hero" && it.cy > s.h * 0.85f } ?: s.exact("hero")
            if (h == null) continue
            tapLine(h, "Hero (supaya ikon Event muncul)")
            val t0 = now()
            var buka = false
            while (now() - t0 < 3500L) {
                alive()
                val p = cap()
                if (p.has("dimiliki", "masterycode") || (p.has("semua") && p.has("fighter") && p.has("marksman"))) { buka = true; break }
            }
            log(if (buka) "Halaman Hero terbuka, Back" else "Halaman Hero belum terbaca, tetap Back")
            back()
            return
        }
        log("Tombol Hero tidak terbaca, dilewati")
    }

    private fun claimHadiahKemenangan() {
        if (!eventIkonAda()) {
            log("Ikon Event belum muncul di lobi: ketuk Hero lalu Back supaya ikon Event muncul")
            heroLaluBack()
            backToLobby()
            // Sesudah Hero lalu Back ikon Event muncul: lanjut klaim seperti biasa
        }
        var percobaan = 0
        while (percobaan < 3) {
            alive()
            percobaan++
            eventLost = false
            status = "Membuka Event"
            openEvent()
            var menu: Line? = null
            var digeser = false
            for (baca in 0 until 4) {
                val s = cap(R_MENU)
                for (k in menuUpdate) {
                    menu = s.find(k)
                    if (menu != null) break
                }
                if (menu != null) break
                if (!digeser && baca >= 1) {
                    // belum kelihatan: geser daftar menu kiri sekali
                    val x = s.w * 0.15f
                    swipe(x, s.h * 0.75f, x, s.h * 0.30f)
                    digeser = true
                }
            }
            if (menu == null) {
                log("Menu Hadiah Kemenangan belum ketemu (percobaan $percobaan/3). Kembali ke lobi, buka Event dan petir lagi")
                backToLobby()
                continue
            }
            status = "Klaim Hadiah Kemenangan"
            tapLine(menu, "menu Hadiah Kemenangan")
            var p = waitPanel(panelUpdate, 1.5, true)
            if (!p.has(*panelUpdate.toTypedArray())) {
                val f = cap()
                if (eventScreenLost(f)) {
                    noteEventLost("sesudah ketuk Hadiah Kemenangan", f)
                    backToLobby()
                    continue
                }
                tapLine(menu, "menu Hadiah Kemenangan (ulang)")
                p = waitPanel(panelUpdate)
            }
            val n = claimLoop("Hadiah Kemenangan", 3, p)
            log("Hadiah Kemenangan selesai ($n ketukan klaim)")
            // Pakai Back button (bukan panah kembali) supaya lebih stabil
            back()
            backToLobby()
            return
        }
        log("Hadiah Kemenangan tidak ditemukan setelah 3 kali coba, lanjut ke langkah berikutnya")
        backToLobby()
    }

    private fun waitPanel(keys: List<String>, sec: Double = 3.0, quiet: Boolean = false): Scr {
        val t0 = now()
        var s = cap(R_PANEL)
        while (!s.has(*keys.toTypedArray())) {
            if (now() - t0 > (sec * 1000).toLong()) {
                if (!quiet) {
                    log("Panel menu belum terverifikasi dalam " + sec + " detik, lanjut. Teks panel kanan: " + s.all.take(120))
                    val f = cap()
                    if (eventScreenLost(f)) noteEventLost("panel menu belum terbuka", f)
                }
                break
            }
            s = cap(R_PANEL)
        }
        return s
    }



    // Tombol "Klaim Semua": emas = siap, abu-abu = sudah diklaim. Diukur dari warna di kiri dan kanan tulisan.
    private fun btnGold(s: Scr, b: Line): Boolean {
        var r = 0
        var bl = 0
        var n = 0
        val bmp = s.bmp
        for (x in intArrayOf(b.r.left - 16, b.r.right + 16)) {
            for (dy in intArrayOf(-12, 0, 12)) {
                val y = (b.cy + dy).toInt()
                if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) continue
                val c = bmp.getPixel(x, y)
                r += (c shr 16) and 255
                bl += c and 255
                n++
            }
        }
        if (n == 0) return true
        return (r - bl) / n > 35
    }

    // ── Server List Navigation (from claim-vg patterns) ──
    // ── Daftar server: cara baca dan geser disalin dari claim-vg ──
    private val SRV = Regex("s?[0-9]{4,6}")

    // Nama server yang sah. Kalau rentang ID diisi (Pengaturan), hanya nomor di rentang itu dan OCR yang kehilangan
    // satu digit diperbaiki kalau hanya ada SATU nomor yang cocok. Kalau rentang kosong, semua 4-6 digit diterima.
    private fun fixSrv(raw: String): String? {
        val lo = Prefs.idMin
        val hi = Prefs.idMax
        val digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        if (lo <= 0 || hi <= 0) return "s" + digits
        val len = lo.toString().length
        if (digits.length == len) {
            val n = digits.toIntOrNull() ?: return null
            return if (n in lo..hi) "s" + digits else null
        }
        if (digits.length == len - 1) {
            val cands = LinkedHashSet<Int>()
            for (i in 0..digits.length) {
                for (d in 0..9) {
                    val v = (digits.substring(0, i) + d + digits.substring(i)).toIntOrNull() ?: continue
                    if (v in lo..hi) cands.add(v)
                }
            }
            if (cands.size == 1) return "s" + cands.first()
        }
        return null
    }

    private fun serverNums(s: Scr): LinkedHashMap<String, Line> {
        // Baris di atas judul "Semua Server" (bagian "Server Saat Ini") tidak ikut dihitung
        val hdr = s.find("semuaserver")
        val minY: Float = hdr?.cy ?: -1f
        val sorted = s.lines
            .filter { it.cy > minY && it.cy > s.h * 0.17f && it.cy < s.h * 0.70f && SRV.containsMatchIn(it.norm) }
            .sortedWith(compareBy({ (it.cy / 40f).toInt() }, { it.cx }))
        val m = LinkedHashMap<String, Line>()
        for (l in sorted) {
            val raw = SRV.find(l.norm)?.value ?: continue
            val k = fixSrv(raw) ?: continue
            if (!m.containsKey(k)) m[k] = l
        }
        return m
    }

    private fun isServerList(s: Scr, dummy: Boolean): Boolean = s.has("serversaatini") || serverNums(s).size >= 3

    private fun readCurrent(s: Scr): String? {
        val h = s.find("serversaatini")
        if (h != null) {
            val h2 = s.find("semuaserver")
            val maxY: Float = h2?.cy ?: (h.cy + s.h * 0.15f)
            val c = s.lines
                .filter { it.cy > h.cy && it.cy < maxY && SRV.containsMatchIn(it.norm) }
                .sortedBy { it.cy }
            for (l in c) {
                val raw = SRV.find(l.norm)?.value ?: continue
                val k = fixSrv(raw)
                if (k != null) return k
            }
        }
        // Cadangan: baris bertanda "Sedang Digunakan"
        val cur = s.lines.firstOrNull { it.norm.contains("sedangdigunakan") }
        if (cur != null) {
            val n = s.lines.firstOrNull { SRV.containsMatchIn(it.norm) && kotlin.math.abs(it.cy - cur.cy) < s.h * 0.05f }
            if (n != null) return SRV.find(n.norm)?.value?.let { fixSrv(it) }
        }
        return null
    }

    private var logAkun = ""

    private fun setAccount(id: String, from: String) {
        if (id == acct) return
        acct = id
        // Arsip log per AKUN (bukan per server): arsipkan hanya saat akun berganti
        if (logAkun.isNotEmpty() && logAkun != id) AppLog.archiveSession("Akun " + logAkun)
        logAkun = id
        log("Akun terbaca dari $from: ID $acct")
    }

    // Layar Profil menulis "ID: 2281758175 (57102)" -> (ID akun, kode server saat ini)
    private fun parseProfileLines(lines: List<Line>): Pair<String, String>? {
        val re = Regex("([0-9]{6,12})\\s*\\(\\s*([0-9]{4,6})\\s*\\)")
        for (l in lines) {
            val m = re.find(l.text) ?: continue
            return Pair(m.groupValues[1], "s" + m.groupValues[2])
        }
        return null
    }

    private fun readProfileInfo(s: Scr) {
        val lo = parseProfileLines(s.lines)
        val hiLines = Ocr.read(s.bmp, rect(s.bmp, R_ID), 100)
        val hi = if (hiLines != null) parseProfileLines(hiLines) else null
        val p = hi ?: lo ?: return
        setAccount(p.first, "Profil")
        cur = p.second
        log("Profil: akun ${p.first}, server ${p.second}")
    }

    private fun readAccountId(s: Scr) {
        val hi = Ocr.read(s.bmp, rect(s.bmp, R_ACCID), 100)
        val txt = if (hi != null) hi.joinToString("") { it.norm } else ""
        val re = Regex("accountid([0-9]{6,12})")
        val m = re.find(txt) ?: re.find(s.all) ?: return
        val id = m.groupValues[1]
        if (acct == "-") setAccount(id, "Pengaturan Akun")
    }

    // Tab menuju Pengaturan Akun di layar Profil (namanya "Akun" di versi lama, "Pengaturan Akun" di versi baru)
    private fun akunTab(a: Scr): Pair<Float, Float> {
        val l = a.lines.firstOrNull { it.norm.contains("pengaturanakun") && it.cx < a.w * 0.25f }
            ?: a.lines.firstOrNull { it.norm == "pengaturan" && it.cx < a.w * 0.25f && it.cy > a.h * 0.5f }
            ?: a.lines.firstOrNull { it.norm == "akun" && it.cx < a.w * 0.25f && it.cy > a.h * 0.5f }
        return if (l != null) Pair(l.cx, l.cy) else Pair(a.w * 0.105f, a.h * 0.745f)
    }

    // Popup besar "Fitur ... Telah Hadir!" di tengah layar: tanpa tombol X, hanya bisa ditutup dengan Back.
    // Tooltip kecil di bagian atas tidak dihitung: Back pada tooltip bisa keluar dari Profil.
    private fun featurePopup(s: Scr): Boolean =
        s.lines.any { it.norm.contains("telahhadir") && it.cy > s.h * 0.15f && it.cy < s.h * 0.55f }

    private fun tapAvatar(s: Scr) {
        val px = s.w * Prefs.avatarX
        val py = s.h * Prefs.avatarY
        tapXY(px, py, "ikon profil (posisi tetap " + px.toInt() + "," + py.toInt() + ")", true)
    }

    // Tunggu daftar karakter selesai dimuat (bisa beberapa detik kalau jaringan lambat)
    private fun waitServerList(sec: Double): Scr? {
        val t0 = now()
        var logged = false
        while (now() - t0 < (sec * 1000).toLong()) {
            val l = cap(R_SERVER)
            if (isServerList(l)) return l
            if (!logged) {
                log("Menunggu daftar karakter dimuat...")
                logged = true
            }
        }
        return null
    }

    // Layar Pengaturan Akun: ketuk Ganti Server, tunggu daftar karakter
    private fun accountToList(a: Scr): Scr? {
        readAccountId(a)
        val gs = a.exact("gantiserver") ?: a.find("gantiserver")
        if (gs == null) {
            log("Di layar Pengaturan Akun, tombol Ganti Server tidak terbaca (teks: " + a.all.take(120) + ")")
            sleepS(1.0)
            return null
        }
        tapLine(gs, "Ganti Server")
        val l = waitServerList(12.0)
        if (l != null) return l
        log("Daftar karakter belum terbaca 12 detik setelah Ganti Server")
        return null
    }

    // Layar Profil: baca ID, ketuk Akun, tunggu Pengaturan Akun
    private fun profileToList(p: Scr): Scr? {
        readProfileInfo(p)
        val tab = akunTab(p)
        tapXY(tab.first, tab.second, "tab Pengaturan Akun", true)
        var x = cap(R_AKUNP)
        val tw = now()
        while (!isAccount(x) && now() - tw < 4000L) {
            alive()
            x = cap(R_AKUNP)
        }
        if (isAccount(x)) return accountToList(x)
        log("Setelah ketuk Akun, Pengaturan Akun belum terbaca (teks: " + x.all.take(100) + ")")
        return null
    }

    // Jalur cepat dari lobi: ketuk ikon profil, ketuk Akun, baca Pengaturan Akun, Ganti Server.
    // Popup di Profil: "Fitur ... Telah Hadir" ditutup Back 1x, popup lain lewat popups(); layar tidak dikenal dicatat ke log
    private fun fastToList(s: Scr): Scr? {
        tapAvatar(s)
        val t0 = now()
        var lastAv = now()
        var backTaps = 0
        var tabTaps = 0
        var lastTab = 0L
        var popupTaps = 0
        var lobiBeruntun = 0
        while (now() - t0 < 9000L) {
            val a = cap()
            if (isAccount(a)) return accountToList(a)
            if (isServerList(a)) return a
            if (!isLobby(a)) lobiBeruntun = 0
            if (isProfile(a)) {
                if (featurePopup(a) && backTaps < 1) {
                    backTaps++
                    log("Popup fitur baru di Profil (tanpa tombol X) ditutup dengan Back")
                    AutoService.inst?.back()
                    lastActive = now()
                    val tp = now()
                    while (now() - tp < 1500L) {
                        alive()
                        val c = cap()
                        if (!(isProfile(c) && featurePopup(c))) break
                    }
                    val tb = akunTab(a)
                    lastTab = now()
                    tabTaps++
                    tapXY(tb.first, tb.second, "tab Pengaturan Akun", true)
                    continue
                }
                // Popup lain yang menutupi Profil (X, Konfirmasi, OK, "ketuk untuk melanjutkan"): tutup dulu
                if (popupTaps < 4 && (darkPopupX(a) || popups(a))) {
                    popupTaps++
                    log("Popup di Profil ditutup ($popupTaps)")
                    continue
                }
                if (now() - lastTab > 1200L) {
                    lastTab = now()
                    tabTaps++
                    if (tabTaps >= 3) log("Tab Pengaturan Akun diketuk ${tabTaps}x tapi belum pindah. Teks layar: " + a.all.take(120))
                    val tab = akunTab(a)
                    tapXY(tab.first, tab.second, "tab Pengaturan Akun", true)
                }
            } else if (isLobby(a)) {
                if (darkPopupX(a)) continue
                // Ketuk ikon profil lagi hanya kalau lobi terbaca jelas 2x berturut-turut dan sudah 3,5 dtk sejak ketukan terakhir.
                // Kalau Profil sudah terbuka tapi sesaat terbaca seperti lobi, ketukan di pojok kiri atas itu menutup Profil lagi
                lobiBeruntun++
                if (now() - lastAv > 3500L && lobiBeruntun >= 2) {
                    lastAv = now()
                    lobiBeruntun = 0
                    tapAvatar(a)
                }
            } else {
                if (!popups(a) && !darkPopupX(a)) {
                    if (now() - lastTab > 2500L) {
                        lastTab = now()
                        log("Layar belum dikenali saat menuju Akun. Teks terbaca: " + a.all.take(160))
                    }
                } else {
                    popupTaps++
                    log("Popup ditutup saat menuju Akun ($popupTaps)")
                }
            }
        }
        log("Jalur cepat: Pengaturan Akun belum terbaca dalam 9 detik")
        return null
    }

    private fun openServerList(): Scr {
        var fastFails = 0
        var unknown = 0
        var attempt = -1
        var darkSpins = 0
        status = "Membuka daftar server"
        while (++attempt < 10) {
            alive()
            val s = cap()
            if (isServerList(s)) return s
            if (cardUp(s)) {
                closeProfileCard(s)
                attempt--
                if (++darkSpins > 40) throw Stop("Lobi tetap tertutup popup. Periksa layar, lalu mulai lagi")
                continue
            }
            log("Buka daftar server: layar " + (if (isAccount(s)) "Pengaturan Akun" else if (isProfile(s)) "Profil" else if (isLobby(s)) "lobby" else "lain") + " [" + s.all.take(50) + "]")
            if (s.has("daftarkarakter") && !isAccount(s)) {
                val w = waitServerList(12.0)
                if (w != null) return w
                continue
            }
            if (isAccount(s)) {
                val r = accountToList(s)
                if (r != null) return r
                continue
            }
            if (isProfile(s)) {
                val r = profileToList(s)
                if (r != null) return r
                continue
            }
            if (!isLobby(s) || eventOpen(s)) {
                if (!popups(s)) {
                    unknown++
                    if (unknown >= 3) {
                        unknown = 0
                        back()
                    } else {
                        log("Layar belum dikenali, menunggu. Teks terbaca: " + s.all.take(160))
                        sleepMs(300)
                    }
                }
                continue
            }
            if (darkPopupX(s)) {
                attempt--
                if (++darkSpins > 40) throw Stop("Lobi tetap tertutup popup. Periksa layar, lalu mulai lagi")
                continue
            }
            val fl = fastToList(s)
            if (fl != null) return fl
            fastFails++
            log("Jalur ke daftar server gagal ($fastFails), diulang dari awal")
            if (fastFails >= 3) throw Stop("Ikon profil tidak membuka menu Profil/Akun. Lihat log: teks layar dicatat di atas.")
        }
        throw Stop("Daftar server tidak terbuka")
    }

    // ── Geser daftar (claim-vg) ──
    private class Step(val scr: Scr, val moved: Boolean, val lost: Boolean)

    private var scrollNo = 0
    private val listSeen = LinkedHashSet<String>()
    private val rowOrder = ArrayList<String>()
    private var listPulled = false
    private var idleSlow = 0
    private var stalled = 0
    private var idleSince = 0L
    private var lastSig = ""
    private var listOpenedAt = 0L
    private var firstPullSince = 0L
    private var listReopened = false

    private fun doSwipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, why: String) {
        val svc = AutoService.inst
        if (svc == null) {
            log("GESERAN GAGAL ($why): aksesibilitas mati")
            return
        }
        val ts = now()
        var ok = svc.swipe(x1, y1, x2, y2, ms)
        log("    geser ($why): ${now() - ts} ms (durasi $ms ms)" + (if (ok) "" else ", gagal"))
        if (!ok) {
            sleepMs(300)
            ok = svc.swipe(x1, y1, x2, y2, ms)
            if (!ok) log("GESERAN GAGAL ($why)")
        }
    }

    // Tinggi satu baris server (piksel), dari jarak antar baris yang terbaca
    private fun rowH(s: Scr): Float {
        val ys = serverNums(s).values.map { it.cy }.sorted()
        if (ys.size < 2) return s.h * 0.08f
        val d = ArrayList<Float>()
        for (i in 1 until ys.size) d.add(ys[i] - ys[i - 1])
        d.sort()
        return d[d.size / 2].coerceIn(s.h * 0.05f, s.h * 0.12f)
    }

    private fun rangeText(m: Map<String, Line>): String {
        val k = m.keys.toList()
        return if (k.isEmpty()) "kosong" else if (k.size == 1) k[0] else k[0] + " sampai " + k[k.size - 1] + " (" + k.size + " baris)"
    }

    private fun mergeRows(keys: List<String>) {
        for (i in keys.indices) {
            val k = keys[i]
            if (k == cur || rowOrder.contains(k)) continue
            var at = -1
            var j = i - 1
            while (j >= 0 && at < 0) {
                val idx = rowOrder.indexOf(keys[j])
                if (idx >= 0) at = idx + 1
                j--
            }
            j = i + 1
            while (j < keys.size && at < 0) {
                val idx = rowOrder.indexOf(keys[j])
                if (idx >= 0) at = idx
                j++
            }
            if (at < 0) rowOrder.add(k) else rowOrder.add(at, k)
        }
    }

    private fun movedText(before: Map<String, Line>, after: Map<String, Line>, rh: Float): String {
        val k = after.keys.firstOrNull { before.containsKey(it) } ?: return "melompat (tidak ada baris yang sama)"
        val d = (before[k]!!.cy - after[k]!!.cy) / rh
        if (Math.abs(d) < 0.15f) return "tidak bergerak"
        return "bergerak " + String.format("%.1f", Math.abs(d)) + " baris " + (if (d > 0) "ke atas" else "ke bawah")
    }

    private fun expectRows(): Int = (Prefs.serverCount - 1).coerceAtLeast(0)

    private fun beginList(s: Scr, resetReopen: Boolean = true) {
        listSeen.clear()
        listPulled = false
        idleSlow = 0
        stalled = 0
        idleSince = 0L
        lastSig = ""
        rowOrder.clear()
        listOpenedAt = now()
        if (resetReopen) {
            listReopened = false
            firstPullSince = now()
        }
        for (k in serverNums(s).keys) if (k != cur) listSeen.add(k)
        mergeRows(serverNums(s).keys.toList())
    }

    // Satu geser cepat keras (hanya SEKALI per daftar yang dibuka)
    private fun pullOnce(s: Scr, tag: String): Scr? {
        val xf = Prefs.swipeX / 100f
        val y0 = Prefs.swipeStart / 100f
        val y1 = minOf(Prefs.swipeEnd / 100f, y0 - 0.1f)
        doSwipe(s.w * xf, s.h * y0, s.w * xf, s.h * y1, Prefs.swipeHardMs.toLong(),
            "geser cepat (${Prefs.swipeStart}% ke ${Prefs.swipeEnd}%, ${Prefs.swipeHardMs}ms)")
        sleepMs(700)
        scrollNo++
        var r: Scr = s
        var after = serverNums(cap(R_SERVER).also { r = it })
        if (after.isEmpty()) after = serverNums(cap(R_SERVER).also { r = it })
        if (after.isEmpty()) {
            log("Geseran $scrollNo ($tag): daftar tidak terbaca setelah geser cepat")
            return null
        }
        return r
    }

    // Pastikan layar berisi minimal 1 server lama (patokan); kalau belum, geser balik sampai terlihat
    private fun settleWindow(start: Scr, prev: Map<String, Line>, tag: String): Step {
        var scr = start
        var rows: Map<String, Line> = serverNums(scr)
        var steps = 0
        while (steps <= 5) {
            for (k in rows.keys) if (k != cur) listSeen.add(k)
            mergeRows(rows.keys.toList())
            val newCount = rows.keys.count { !prev.containsKey(it) && it != cur }
            val oldCount = rows.keys.count { prev.containsKey(it) }
            if (oldCount >= 1 || prev.isEmpty()) {
                log("Geseran $scrollNo ($tag): layar ${rangeText(rows)}, $newCount server baru, $oldCount lama" +
                    (if (steps > 0) " (setelah geser balik ${steps}x)" else ""))
                return Step(scr, true, false)
            }
            if (steps == 5) break
            val bx = scr.w * Prefs.swipeX / 100f
            val ys = scr.h * Prefs.swipeBackStart / 100f
            val ye = scr.h * Prefs.swipeBackEnd / 100f
            doSwipe(bx, ys, bx + scr.w * 0.01f, ye, Prefs.swipeBackMs.toLong(),
                "geser balik (${Prefs.swipeBackStart}% ke ${Prefs.swipeBackEnd}%)")
            sleepMs(500)
            scrollNo++
            val r2 = serverNums(cap(R_SERVER).also { scr = it })
            if (r2.isNotEmpty()) rows = r2
            steps++
        }
        log("Geseran $scrollNo ($tag): batas geser balik tercapai, layar ${rangeText(rows)} (mungkin ada baris terlewat)")
        return Step(scr, true, false)
    }

    private fun scrollNext(s: Scr, tag: String): Step {
        val expect = expectRows()
        if (expect > 0 && listSeen.size >= expect) {
            log("Geseran ($tag): semua $expect server di daftar sudah terlihat")
            return Step(s, false, false)
        }
        val rh = rowH(s)
        val prev = serverNums(s)
        for (k in prev.keys) if (k != cur) listSeen.add(k)
        mergeRows(prev.keys.toList())
        var scr = s

        if (!listPulled) {
            val seenBefore = listSeen.size
            val since = now() - listOpenedAt
            val r = pullOnce(s, tag)
            listPulled = true
            if (r == null) {
                log("Geseran $scrollNo ($tag): daftar tidak terbaca setelah geser cepat, lanjut geser pelan")
                return Step(s, true, false)
            }
            scr = r
            val after = serverNums(r)
            val extra = after.keys.count { !listSeen.contains(it) && it != cur }
            for (k in after.keys) if (k != cur) listSeen.add(k)
            mergeRows(after.keys.toList())
            log("Geseran $scrollNo ($tag): geser cepat sekali, dimulai $since ms sejak daftar terbaca, ${movedText(prev, after, rh)}, terlihat ${rangeText(after)}" +
                (if (seenBefore + extra > 5) " (memuat server baru)" else " (belum ada server baru)"))
            return settleWindow(r, prev, tag)
        }

        // Sesudah geser cepat pertama: hanya geser pelan
        val x0 = s.w * Prefs.swipeX / 100f
        val y0 = s.h * Prefs.swipeSlowStart / 100f
        val y1 = s.h * Prefs.swipeSlowEnd / 100f
        doSwipe(x0, y0, x0 + s.w * 0.02f, y1, Prefs.swipeSlowMs.toLong(), "geser pelan (${Prefs.swipeSlowStart}% ke ${Prefs.swipeSlowEnd}%)")
        sleepMs(450)
        scrollNo++
        var after = serverNums(cap(R_SERVER).also { scr = it })
        if (after.isEmpty()) after = serverNums(cap(R_SERVER).also { scr = it })
        if (after.isEmpty()) {
            log("Geseran $scrollNo ($tag): daftar tidak terbaca setelah geser pelan")
            return Step(scr, false, true)
        }
        val globalNew = after.keys.count { !listSeen.contains(it) && it != cur }
        if (globalNew > 0) {
            idleSlow = 0
            stalled = 0
            idleSince = 0L
            return settleWindow(scr, prev, tag)
        }
        for (k in after.keys) if (k != cur) listSeen.add(k)
        mergeRows(after.keys.toList())
        idleSlow++
        if (idleSince == 0L) idleSince = now()
        val sig = after.keys.joinToString(",")
        if (sig == lastSig) stalled++ else stalled = 0
        lastSig = sig
        if (now() - idleSince > 600_000L) {
            val msg = "Daftar tidak menemukan server baru selama 10 menit, baru ${listSeen.size} dari $expect server terlihat. Periksa Jumlah server atau setelan geser"
            log("Geseran $scrollNo ($tag): $msg")
            throw Stop(msg)
        }
        if (stalled >= 2) {
            log("Geseran $scrollNo ($tag): layar tidak berubah $stalled kali, terlihat ${listSeen.size} dari $expect server. Lanjut geser pelan")
            sleepMs(800)
        } else {
            log("Geseran $scrollNo ($tag): melewati baris yang sudah terlihat, layar ${rangeText(after)}")
        }
        return Step(scr, true, false)
    }

    // Geser daftar ke ATAS (pelan) dan buktikan daftarnya bergerak
    private fun scrollStep(s: Scr, tag: String, maxTry: Int = 3): Step {
        val before = serverNums(s)
        val rh = rowH(s)
        var cur2 = s
        for (attempt in 0 until maxTry) {
            val y0 = s.h * 0.38f
            val d = minOf(3.0f * rh, s.h * 0.90f - y0)
            doSwipe(s.w * 0.77f, y0, s.w * 0.79f, y0 + d, 300, "geser daftar ke atas")
            sleepMs(450)
            scrollNo++
            cur2 = cap(R_SERVER)
            val after = serverNums(cur2)
            if (after.isNotEmpty() && movedText(before, after, rh) != "tidak bergerak") {
                return Step(cur2, true, false)
            }
        }
        return Step(cur2, false, false)
    }

    private fun scrollTop(first: Scr): Scr {
        var s = first
        for (i in 0 until 25) {
            val st = scrollStep(s, "ke atas", 1)
            s = st.scr
            if (!st.moved) break
        }
        return s
    }

    // Uji sampai bawah: geser dengan cara yang sama seperti saat memilih server, sampai ujung, lalu laporkan
    fun ujiGeser(ctx: Context) {
        if (running) return
        Thread {
            try {
                running = true
                app = ctx.applicationContext
                Prefs.init(ctx)
                status = "Uji geser"
                applyPerf()
                log("── Uji sampai bawah ── (buka Daftar Karakter, lalu pindah ke game)")
                sleepS(15.0)
                var s = cap(R_SERVER)
                if (!isServerList(s, true)) throw Stop("Daftar Karakter tidak terlihat. Buka dulu daftarnya.")
                cur = readCurrent(s)
                beginList(s)
                var guard = 0
                while (guard++ < 80) {
                    alive()
                    val st = scrollNext(s, "uji")
                    s = st.scr
                    if (!st.moved) break
                    if (expectRows() > 0 && listSeen.size >= expectRows()) break
                }
                log("Uji selesai: ${listSeen.size} server terlihat dari ${expectRows()} yang diharapkan: " + listSeen.joinToString(", "))
                status = "Uji selesai"
            } catch (e: Stop) {
                log("Uji berhenti: ${e.message}")
                status = "Uji berhenti"
            } catch (e: Throwable) {
                log("Uji error: ${e.message}")
            } finally {
                releasePerf()
                running = false
            }
        }.apply { isDaemon = true; start() }
    }

    // Level akun di satu baris daftar karakter: angka paling kanan di baris itu (mis. 20, 20, 3)
    private fun rowLevel(s: Scr, row: Line): Int? {
        val band = s.lines.filter { Math.abs(it.cy - row.cy) < s.h * 0.035f }
        val right = band.maxByOrNull { it.r.right } ?: return null
        val tok = right.text.trim().split(Regex("\\s+")).lastOrNull() ?: return null
        val digits = tok.filter { it.isDigit() }
        if (digits.isEmpty() || digits.length > 3) return null
        return digits.toIntOrNull()
    }

    private val levelWarned = HashSet<String>()

    // true = server boleh dipilih (level akun di server itu tidak melebihi batas)
    private fun levelOk(name: String, s: Scr, row: Line): Boolean {
        val max = Prefs.serverMaxLevel
        val lv = rowLevel(s, row)
        if (lv == null) {
            if (levelWarned.add(name)) log("Level server $name tidak terbaca, dianggap memenuhi")
            return true
        }
        if (lv > max) {
            log("Server $name dilewati: level $lv (maksimal $max)")
            return false
        }
        log("Server $name level $lv (maksimal $max): dipilih")
        return true
    }

    // Progres = server selesai + server yang dilewati (level terlalu tinggi)
    private fun refreshCount() { doneCount = done.size + skipped.size }

    private fun pickNext(): String? {
        var s = openServerList()
        val rc = readCurrent(s)
        if (rc != null) cur = rc
        beginList(s)
        if (serverNums(s).isEmpty()) {
            val tE = now()
            while (serverNums(s).isEmpty() && now() - tE < 5000L) {
                alive()
                s = cap(R_SERVER)
            }
            log("Daftar server belum menampilkan nomor saat dibuka, dibaca ulang ${now() - tE} ms: " +
                (if (serverNums(s).isEmpty()) "masih kosong" else rangeText(serverNums(s))))
        }
        for (page in 0 until 3000) {
            alive()
            for ((n, ln) in serverNums(s)) {
                if (!done.contains(n) && !skipped.contains(n) && n != cur) {
                    if (!levelOk(n, s, ln)) {
                        skipped.add(n)
                        refreshCount()
                        // Sudah level 20 (dilewati, bukan di-up aplikasi ini): tetap dicatat ke Catatan Cabang
                        val lvSkip = rowLevel(s, ln)
                        if (lvSkip != null && lvSkip >= 20) catatKe(n, 20, "Biasa", "sudah level $lvSkip, dilewati")
                        continue
                    }
                    if (!order.contains(n)) order.add(n)
                    return n
                }
            }
            val st = scrollNext(s, "cari server berikutnya")
            s = st.scr
            if (!st.moved) {
                log(if (st.lost) "Peringatan: geseran gagal, daftar mungkin belum habis" else "Ujung daftar: tidak ada server yang belum selesai")
                break
            }
        }
        return null
    }

    private fun switchTo(name: String) {
        log("Ganti server -> $name")
        status = "Ganti server $name"
        var s = cap(R_SERVER)
        if (!isServerList(s, true)) {
            s = openServerList()
            beginList(s)
        }
        if (serverNums(s)[name] == null) {
            for (i in 0 until 3) {
                alive()
                s = cap(R_SERVER)
                if (serverNums(s)[name] != null) break
            }
        }
        var found: Line? = null
        for (pass in 0 until 2) {
            for (page in 0 until 60) {
                alive()
                val l = serverNums(s)[name]
                if (l != null) {
                    found = l
                    break
                }
                val st = if (pass == 0) scrollNext(s, "cari $name") else scrollStep(s, "cari $name")
                s = st.scr
                if (!st.moved) break
            }
            if (found != null) break
        }
        val l = found ?: throw Stop("Server $name tidak ditemukan di daftar")
        tapLine(l, "Pilih server $name")
        sleepMs(250)
        val s2 = cap(R_OK)
        val gs = s2.exact("gantiserver") ?: s2.find("gantiserver")
        if (gs != null) tapLine(gs, "Ganti Server")
        confirmSwitch()
    }

    private fun confirmSwitch() {
        val t0 = now()
        var abuLog = false
        while (now() - t0 < 20_000L) {
            alive()
            val s = cap()
            if (s.has("memuatgame")) { log("Game memuat ulang"); return }
            if (s.has("pemberitahuansistem", "servertelahdiganti", "melakukanrestart", "restartgame")) {
                val ok = s.exact("ok") ?: s.find("ok")
                if (ok != null) {
                    val siap = btnGold(s, ok)
                    if (siap || now() - t0 > 15_000L) {
                        tapLine(ok, if (siap) "OK Pemberitahuan Sistem (emas, siap)" else "OK Pemberitahuan Sistem (batas waktu)")
                        sleepMs(300)
                        return
                    }
                    if (!abuLog) {
                        abuLog = true
                        log("Tombol OK masih abu-abu, menunggu sampai emas-cokelat")
                    }
                }
                continue
            }
            if (isLobby(s)) return
            popups(s)
        }
    }

    // ── Panduan tangan (tutorial game): ikon tangan emas menunjuk ke kiri-atas ke target yang harus diketuk ──
    // Dikenali dari bentuk gumpalan warna kuning pucat (±5000 px, ±120x85 px). Target = di kiri-atas ujung tangan.
    private fun cariTangan(s: Scr): Pair<Float, Float>? {
        // Lobi biasa (tidak gelap) tidak pernah punya panduan tangan: gumpalan kuning di sana adalah tombol Classic / banner
        if (isLobby(s) && !lobiGelap(s)) return null
        val b = s.bmp
        val w = b.width; val h = b.height
        val sc = w / 2400f
        val cell = maxOf(4, (8 * sc).toInt())
        val st = maxOf(1, (2 * sc).toInt())
        val cw = w / cell; val ch = h / cell
        if (cw < 10 || ch < 10) return null
        val per = (cell / st) * (cell / st)
        val need = maxOf(2, per / 4)
        val on = BooleanArray(cw * ch)
        val row = IntArray(w * cell)
        for (cy in 0 until ch) {
            b.getPixels(row, 0, w, 0, cy * cell, w, cell)
            for (cx in 0 until cw) {
                var n = 0
                var yy = 0
                while (yy < cell) {
                    var xx = 0
                    while (xx < cell) {
                        val c = row[yy * w + cx * cell + xx]
                        val r = c shr 16 and 255; val g = c shr 8 and 255; val bl = c and 255
                        if (r > 225 && g > 200 && bl > 100 && bl < 205 && r - bl > 45 && g - bl > 30) n++
                        xx += st
                    }
                    yy += st
                }
                if (n >= need) on[cy * cw + cx] = true
            }
        }
        val seen = BooleanArray(cw * ch)
        val stack = IntArray(cw * ch)
        for (start in on.indices) {
            if (!on[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start; seen[start] = true
            var count = 0; var minX = cw; var maxX = 0; var minY = ch; var maxY = 0
            while (sp > 0) {
                val cur = stack[--sp]
                val cy = cur / cw; val cx = cur % cw
                count++
                if (cx < minX) minX = cx; if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy; if (cy > maxY) maxY = cy
                for (dy in -1..1) for (dx in -1..1) {
                    val ny = cy + dy; val nx = cx + dx
                    if (ny < 0 || nx < 0 || ny >= ch || nx >= cw) continue
                    val ni = ny * cw + nx
                    if (on[ni] && !seen[ni]) { seen[ni] = true; stack[sp++] = ni }
                }
            }
            val bw = (maxX - minX + 1) * cell / sc
            val bh = (maxY - minY + 1) * cell / sc
            val skalaCell = (cell / sc) / 8f
            val n8 = count * skalaCell * skalaCell
            if (n8 in 70f..125f && bw in 100f..150f && bh in 70f..110f) {
                val x = (minX * cell - 40 * sc).coerceAtLeast(5f)
                val y = (minY * cell - 55 * sc).coerceAtLeast(5f)
                return Pair(x, y)
            }
        }
        return null
    }

    private fun tapTangan(s: Scr): Boolean {
        val p = cariTangan(s) ?: return false
        log("Panduan tangan terdeteksi: ketuk target yang ditunjuk (${p.first.toInt()},${p.second.toInt()})")
        tapXY(p.first, p.second, "Target panduan tangan", false)
        sleepMs(600)
        return true
    }

    // Setelah ikon Pertumbuhan Level diketuk: ikuti panduan tangan, klaim/konfirmasi hadiah, lalu "Pergi ke Lobby"
    private fun selesaikanHadiahLevel(awal: Scr? = null) {
        log("Tutorial Pertumbuhan Level: ketukan di posisi tetap (ikon, Battle Spell, Konfirmasi, Pergi ke Lobby)")
        var tanpa = 0
        var pergi = 0
        var ikon = 0
        for (i in 0..40) {
            alive()
            val p = if (i == 0 && awal != null) awal else cap()
            // Sudah di halaman Classic (latar gelap mirip lobi gelap): tutorial selesai, jangan ketuk ikon kiri atas lagi
            if (isClassicPage(p)) {
                log("Tutorial selesai: halaman Classic terlihat")
                return
            }
            val dapat = p.has("kamumendapatkan") || (p.has("selamat") && p.has("mendapatkan"))
            val halaman = !isLobby(p) && (p.has("pertumbuhanlevel") || p.has("pergikelobby") || p.has("kesulitanhero"))
            when {
                // Foto 5: "Selamat! Kamu Mendapatkan ..." -> Konfirmasi (tengah bawah)
                dapat -> {
                    tapXY(p.w * 0.5f, p.h * 0.917f, "Konfirmasi (posisi tetap)", true)
                    // Tombol baru aktif sesudah animasi hadiah: ketukan beruntun cepat (tanpa membaca layar di antaranya),
                    // supaya langsung terkena begitu aktif, bukan menunggu satu putaran baca layar (±0,6 dtk) per ketukan
                    for (k in 0 until 3) {
                        AutoService.inst?.tap(p.w * 0.5f, p.h * 0.917f)
                        sleepMs(110)
                    }
                    tanpa = 0
                }
                // Foto 4: tangan menunjuk ikon Battle Spell (hijau) di bawah hero Aurora
                halaman && (p.has("sudahmembuka") || p.has("spellpertamamu") || p.has("membukabattle")) -> {
                    tapXY(p.w * 0.285f, p.h * 0.70f, "ikon Battle Spell (posisi tetap)", true)
                    tanpa = 0
                }
                // Foto 6: "Saatnya mencoba Battle Spell" -> Pergi ke Lobby (kanan bawah)
                halaman -> {
                    if (!(p.has("mencoba") || p.has("pergikelobby")) && tapTangan(p)) {
                        tanpa = 0
                    } else if (p.has("mencoba") || p.has("pergikelobby")) {
                        // Hanya kalau "Saatnya mencoba Battle Spell" / tombol Pergi ke Lobby benar-benar terlihat (langkah terakhir)
                        tapXY(p.w * 0.875f, p.h * 0.917f, "Pergi ke Lobby (posisi tetap)", true)
                        pergi++
                        tanpa = 0
                    } else {
                        // Halaman Pertumbuhan Level sedang dimuat / belum ada petunjuk: tunggu bacaan berikutnya, jangan mengetuk
                        if (!popups(p)) tanpa++
                        if (tanpa >= 8) return
                    }
                }
                // Foto 3: lobi gelap / tooltip "Hadiah Pertumbuhan Level tersedia" -> ikon kiri atas
                pergi == 0 && isLobby(p) && !isClassicPage(p) && ikon < 7 && (lobiGelap(p) || p.has("pertumbuhanlevel") || p.has("levelgrowth") || cariTangan(p) != null) -> {
                    ikon++
                    // Ikon tangan terlihat tapi menunjuk bukan ke ikon kiri atas (mis. tombol lain): ikuti tangan
                    val th = cariTangan(p)
                    if (th != null && !(th.first < p.w * 0.35f && th.second < p.h * 0.45f)) {
                        tapTangan(p)
                        continue
                    }
                    // Ikon panduan bisa muncul di salah satu dari 3 tempat (ditandai 1,2,3 dari atas): ketuk yang sedang menyala
                    val tiga = floatArrayOf(0.18f, 0.275f, 0.38f)
                    val terang = spotTerang(p, tiga)
                    val idx = if (ikon >= 4 || terang < 0) (ikon - 1) % 3 else terang
                    log("Ikon panduan: posisi " + (idx + 1) + " dari 3" + (if (terang >= 0 && ikon < 4) " (yang menyala)" else " (bergantian)"))
                    tapXY(p.w * 0.092f, p.h * tiga[idx], "Ikon Pertumbuhan Level (posisi " + (idx + 1) + ")", true)
                    tanpa = 0
                    sleepMs(250)
                }
                lobiUtama(p) && !lobiGelap(p) && (pergi > 0 || i >= 8) -> {
                    log("Tutorial selesai: lobi terlihat")
                    return
                }
                else -> {
                    if (!popups(p)) tanpa++
                    if (tanpa >= 8) return
                }
            }
        }
    }

    // Cari mana dari beberapa posisi ikon (pecahan tinggi layar, kolom kiri) yang disorot lingkaran terang panduan.
    // Mengembalikan indeks posisi, atau -1 kalau tidak ada sorotan yang jelas lebih terang dari sekitarnya.
    private fun spotTerang(s: Scr, ys: FloatArray): Int {
        val b = s.bmp
        val w = b.width; val h = b.height
        val xc = (w * 0.092f).toInt()
        val half = (h * 0.03f).toInt().coerceAtLeast(6)
        fun terangDi(yc: Int): Int {
            var sum = 0L; var n = 0
            var y = (yc - half).coerceAtLeast(0)
            val yEnd = (yc + half).coerceAtMost(h - 1)
            while (y <= yEnd) {
                var x = (xc - half).coerceAtLeast(0)
                val xEnd = (xc + half).coerceAtMost(w - 1)
                while (x <= xEnd) {
                    val c = b.getPixel(x, y)
                    sum += ((c shr 16 and 255) * 299 + (c shr 8 and 255) * 587 + (c and 255) * 114) / 1000
                    n++
                    x += 5
                }
                y += 5
            }
            return if (n > 0) (sum / n).toInt() else 0
        }
        // Pindai kolom dari atas ke bawah, cari titik paling terang (pusat lingkaran sorotan)
        val ys0 = (h * 0.10f).toInt(); val ys1 = (h * 0.56f).toInt()
        var bestY = ys0; var best = -1
        val semua = ArrayList<Int>()
        var y = ys0
        while (y <= ys1) {
            val v = terangDi(y)
            semua.add(v)
            if (v > best) { best = v; bestY = y }
            y += (h * 0.012f).toInt().coerceAtLeast(4)
        }
        semua.sort()
        val median = semua[semua.size / 2]
        if (best < 110 || best < median * 1.3f) return -1
        var idx = 0; var jarak = Int.MAX_VALUE
        for (i in ys.indices) {
            val d = Math.abs((h * ys[i]).toInt() - bestY)
            if (d < jarak) { jarak = d; idx = i }
        }
        log("  Sorotan panduan: terang $best (median $median) di y=$bestY -> posisi ${idx + 1}")
        return idx
    }

    // Panduan tangan di lobi: seluruh layar digelapkan (langit lobi ±55% lebih gelap dari biasanya). Ukur kecerahan area langit.
    private fun lobiGelap(s: Scr): Boolean {
        val b = s.bmp
        val x0 = (b.width * 0.54f).toInt(); val x1 = (b.width * 0.79f).toInt()
        val y0 = (b.height * 0.09f).toInt(); val y1 = (b.height * 0.46f).toInt()
        var sum = 0L; var n = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = b.getPixel(x, y)
                sum += ((c shr 16 and 255) * 299 + (c shr 8 and 255) * 587 + (c and 255) * 114) / 1000
                n++
                x += 24
            }
            y += 24
        }
        val rata = if (n > 0) (sum / n).toInt() else 255
        if (rata < 125 && gelapLog != rata / 10) { gelapLog = rata / 10; log("  Lobi tampak gelap (kecerahan langit $rata, normal ±180): kemungkinan panduan tangan") }
        return rata < 125
    }
    private var gelapLog = -1

    // ── Level Growth Check (Pertumbuhan Level) ──
    private fun checkLevelGrowth(s: Scr): Boolean {
        // Cek ikon tangan "Pertumbuhan Level" di lobby
        if (s.has("pertumbuhanlevel") || s.has("levelgrowth")) {
            log("Pertumbuhan Level terdeteksi")
            // Teks "Hadiah Pertumbuhan Level tersedia" hanya tooltip (tidak bisa diketuk). Yang diketuk: ikon di kiri atas
            selesaikanHadiahLevel()
            return true
        }
        return false
    }

    // ── Steps 7-8: Enter Classic Mode ──
    // Lobi utama dengan tombol "Kembali ke Lobby" (muncul bila back kebablasan dari halaman Classic): ketuk untuk kembali.
    private fun kembaliKeClassic(s: Scr): Boolean {
        if (isClassicPage(s)) return false
        val k = s.lines.filter { it.norm.contains("kembalikelobby") || it.norm.contains("kembalikelobi") }
            .maxByOrNull { it.cy } ?: return false
        tapLine(k, "Kembali ke Lobby (menuju halaman Classic)")
        sleepMs(300)
        return true
    }

    // Quick Mode harus sudah tertulis selagi game masih di lobi (status Unknown), jadi jangan lanjut sebelum cheat terhubung.
    private fun tungguCheat() {
        if (!Cheat.aktif || Cheat.siapMain) return
        log("Menunggu cheat terhubung dan Quick Mode terpasang sebelum masuk Classic…")
        val t0 = now()
        var terakhir = 0L
        while (now() - t0 < 90_000L && Cheat.aktif && !Cheat.siapMain) {
            alive()
            if (now() - terakhir > 5000L) {
                terakhir = now()
                log("  …cheat: ${Cheat.statusTeks} · status memori ${Cheat.statusGame}")
            }
            sleepMs(300)
        }
        if (Cheat.siapMain) log("Cheat siap (${(now() - t0) / 1000}s)")
        else log("⚠ Cheat belum siap dalam 90 detik, lanjut tanpa menunggu")
    }

    private fun enterClassic() {
        log("Langkah 7-8: Masuk Classic mode")
        status = "Masuk Classic"

        // Tap Classic button di lobby
        var gagalClassic = 0
        var levelCoba = 0
        var percobaan = 0
        var tanganKetuk = 0
        var tutorialMasuk = 0
        var tungguCheatT0 = 0L
        while (percobaan < 9) {
            alive()
            val s = cap()
            if (isClassicPage(s)) break
            // Popup fitur baru (Custom Signal dll) menutupi halaman Classic/Mode Cepat: tutup di langkah berikutnya
            if (!isLobby(s) || s.has("classic") || s.has("modecepat")) {
                if (jenisPopupClassic(subScr(s, R_ATAS)) != null) {
                    log("Halaman Classic dengan popup terdeteksi")
                    break
                }
            }
            // Panduan tangan menutupi layar: ketuk yang ditunjuk tangan lebih dulu (maks 30x)
            if (!isLobby(s) && (s.has("pertumbuhanlevel") || s.has("kamumendapatkan"))) {
                selesaikanHadiahLevel()
                continue
            }
            // Lobi gelap / ikon tangan terlihat sejak bacaan pertama: langsung urutan ketukan tetap (tanpa mengetuk Classic dulu)
            if (tutorialMasuk < 3 && isLobby(s) && !isClassicPage(s) && (lobiGelap(s) || cariTangan(s) != null)) {
                tutorialMasuk++
                log("Tutorial terdeteksi sejak bacaan pertama: langsung ketuk ikon Pertumbuhan Level")
                selesaikanHadiahLevel(s)
                gagalClassic = 0
                continue
            }
            if (percobaan >= 2 && tanganKetuk < 10 && tapTangan(s)) { tanganKetuk++; continue }
            percobaan++

            // Panduan tangan "Hadiah Pertumbuhan Level tersedia" menutupi lobi: hanya ikon bertangan yang bisa diketuk
            if (levelCoba < 2 && isLobby(s) && (s.has("pertumbuhanlevel") || s.has("levelgrowth"))) {
                levelCoba++
                checkLevelGrowth(s)
                gagalClassic = 0
                continue
            }
            if (isLobby(s) && (gagalClassic >= 2 || lobiGelap(s))) {
                log("Lobi digelapkan panduan tangan (Classic diketuk ${gagalClassic}x): ketuk ikon Pertumbuhan Level (kiri atas)")
                selesaikanHadiahLevel()
                gagalClassic = 0
                continue
            }

            // Tutorial (ketuk ikon dll) tidak menunggu cheat; cheat baru ditunggu sebelum Classic diketuk.
            // Selama menunggu, layar tetap dibaca ulang tiap putaran (tutorial/popup yang muncul langsung ditangani),
            // dan Classic tidak diketuk dari bacaan lama
            if (Cheat.aktif && !Cheat.siapMain) {
                if (tungguCheatT0 == 0L) {
                    tungguCheatT0 = now()
                    log("Menunggu cheat siap sebelum Classic diketuk (layar tetap dipantau)…")
                }
                if (now() - tungguCheatT0 < 90_000L) {
                    percobaan--
                    popups(s)
                    continue
                }
                log("⚠ Cheat belum siap dalam 90 detik, lanjut tanpa menunggu")
            } else if (tungguCheatT0 != 0L) {
                log("Cheat siap (${(now() - tungguCheatT0) / 1000}s)")
                tungguCheatT0 = 0L
            }
            val classic = s.find("classic") ?: s.find("modecepat")
            if (classic != null) {
                tapLine(classic, "Classic/Mode Cepat")
                gagalClassic++
                waitScreenChange(s.all)
            } else if (isLobby(s)) {
                // Classic/Mode Cepat mungkin di bottom menu
                tapXY(s.w * 0.35f, s.h * 0.93f, "Menu Classic (posisi tetap)")
                waitScreenChange(s.all)
            } else {
                popups(s)
            }
        }

        // Tap Mulai Game. Dibaca di bagian bawah layar saja supaya cepat; layar penuh hanya kalau tombol tidak terlihat (ada popup)
        var diketuk = false
        var mulaiMandek = 0
        var dumpQuickDilakukan = false
        fiturBaruCoba = 0
        for (attempt in 0..39) {
            alive()
            // Popup fitur baru menutupi layar tetapi tombol Mulai Game tetap terlihat di bawahnya: cek bagian tengah dulu
            val full = cap()
            if (!diketuk && fiturBaruCoba < 6) {
                val t = subScr(full, R_ATAS)
                if (jenisPopupClassic(t) != null) {
                    tutupFiturBaru(t)
                    continue
                }
            }
            val r = subScr(full, R_MULAI)
            val mulai = r.find("mulaigame") ?: r.find("mulai")
            if (mulai != null && mulai.cy > r.h * 0.7f) {
                // Mulai Game sudah diketuk 3x tapi tombolnya masih ada: ada popup tak dikenal yang menelan ketukan -> Back sekali
                if (diketuk && ++mulaiMandek >= 2) {
                    mulaiMandek = 0
                    log("Mulai Game tidak merespons setelah 2 ketukan: kemungkinan popup tak dikenal")
                    tutupFiturBaru(full)
                    diketuk = false
                    continue
                }
                tungguCheat()
                if (!dumpQuickDilakukan) {
                    dumpQuickDilakukan = true
                    Cheat.dumpQuickArea("sebelum")
                    Cheat.kilatQuick(7000)
                    tapLine(mulai, "Mulai Game")
                    Cheat.jadwalkanDumpSesudahMulai()
                } else {
                    Cheat.kilatQuick(7000)
                    tapLine(mulai, "Mulai Game")
                }
                diketuk = true
                waitScreenChange(full.all)
                continue
            }
            if (diketuk) break  // tombol sudah hilang: pencarian match dimulai
            val s = full
            if (isLoading(s)) return
            // Panduan tangan lanjutan (langkah 7): ketuk yang ditunjuk tangan
            if (tanganKetuk < 30 && tapTangan(s)) { tanganKetuk++; continue }
            // Sudah kembali ke lobi (mis. sesudah "Pergi ke Lobby"): ketuk Classic lagi
            if (!diketuk && isLobby(s) && !isClassicPage(s)) {
                val c = s.find("classic") ?: s.find("modecepat")
                if (c != null) {
                    tapLine(c, "Classic/Mode Cepat (kembali dari lobi)")
                    waitScreenChange(s.all)
                    continue
                }
            }
            if (jenisPopupClassic(s) != null) {
                tutupFiturBaru(s)
                continue
            }
            // Back yang kebablasan membawa ke lobi utama (ada tombol "Kembali ke Lobby"): ketuk untuk kembali ke halaman Classic
            if (kembaliKeClassic(s)) continue
            popups(s)
        }
    }

    // ── Steps 9-11: In-game turret tapping + victory ──
    private fun playGame() {
        val t0play = now()
        log("Langkah 9-11: Dalam game → tap turret → Victory")
        status = "Dalam game"

        // Tunggu pertandingan benar-benar mulai. Layar tidak disentuh sebelum itu, karena ketukan saat
        // pencarian match bisa membatalkan match. Patokan utama: status game di memori = Play.
        status = "Menunggu match"
        val tunggu0 = now()
        var terakhirLayar = 0L
        var terakhirDetak = 0L
        var classicBerturut = 0
        var ketukUlang = 0
        var terakhirKetukUlang = 0L
        var stabil = 0
        var mulaiMain = false
        while (now() - tunggu0 < 300_000L) {
            alive()
            if (Cheat.aktif && Cheat.statusGame == "Play") {
                log("Match dimulai (status Play, ${(now() - tunggu0) / 1000}s)")
                mulaiMain = true
                break
            }
            if (now() - terakhirDetak > 5000L) {
                terakhirDetak = now()
                log("Menunggu match ${(now() - tunggu0) / 1000}s · cheat ${if (Cheat.aktif) "aktif" else "mati"} · status memori ${Cheat.statusGame} · tulis ${when (Cheat.tulisTerbukti) { true -> "terbukti"; false -> "TIDAK masuk"; null -> "belum dicoba" }}")
            }
            if (now() - terakhirLayar > 2500L) {
                terakhirLayar = now()
                val s = cap()
                if (popups(s)) {
                    classicBerturut = 0   // popup tadi baru ditutup; tombol Mulai Game mungkin belum sempat diketuk
                } else {
                    // Masih di halaman Classic dengan tombol Mulai Game terlihat padahal game belum masuk pencarian/match:
                    // ketukan sebelumnya mungkin tertelan popup. Ketuk lagi (setelah terlihat 2 kali berturut-turut).
                    val st = Cheat.statusGame
                    if (isClassicPage(s) && st != "waitReady" && st != "Play" && st != "End") {
                        classicBerturut++
                        if (classicBerturut >= 2 && ketukUlang < 5 && now() - terakhirKetukUlang > 6000L) {
                            val mg = s.find("mulaigame") ?: s.find("mulai")
                            if (mg != null) {
                                ketukUlang++
                                terakhirKetukUlang = now()
                                log("Masih di halaman Classic, ketuk Mulai Game lagi (${ketukUlang}/5)")
                                tapLine(mg, "Mulai Game (ulang)")
                                classicBerturut = 0
                            }
                        }
                    } else classicBerturut = 0
                    if (st != "waitReady" && st != "selectHero" && st != "Play" && st != "waitEnd" && st != "End" &&
                        ketukUlang < 5 && now() - terakhirKetukUlang > 6000L && kembaliKeClassic(s)) {
                        ketukUlang++
                        terakhirKetukUlang = now()
                    }
                    if (!Cheat.aktif) {
                        // Tanpa data memori: anggap sudah main kalau layar bukan lobi, bukan loading, dan bukan halaman Classic 3 kali berturut-turut
                        if (!isLobby(s) && !isLoading(s) && !isClassicPage(s)) stabil++ else stabil = 0
                        if (stabil >= 3) { mulaiMain = true; break }
                    }
                }
            }
            sleepMs(100)
        }
        if (!mulaiMain) log("⚠ Match belum mulai dalam 300 detik, lanjut ke langkah berikutnya")
        status = "Dalam game"

        // In-game: ketuk terus-menerus HANYA ikon turret (di samping ikon kapak). Ikon serangan dasar (kapak) tidak dipakai.
        log("Ketuk ikon turret (samping kapak) terus-menerus (150 ms/ketuk) sampai match selesai")
        mulaiSpam(listOf(0.887f to 0.727f), 150)
        try {
            val victT0 = now()
            while (now() - victT0 < 300_000L) { // Max 5 minutes
                alive()
                val st = Cheat.statusGame
                if (Cheat.aktif && (st == "waitEnd" || st == "End")) {
                    log("Match selesai (status $st) — playGame total ${(now() - t0play) / 1000}s")
                    return
                }
                val s = cap()
                if (isVictory(s) || isPostGame(s)) {
                    log("Victory/Post-game terdeteksi!")
                    return
                }
            }
            log("⚠ Victory tidak terdeteksi dalam 5 menit, lanjut saja (playGame ${(now() - t0play) / 1000}s)")
        } finally {
            hentikanSpam()
        }
    }

    // Ketuk beruntun tiap 50 ms di tempat tombol Lanjutkan/Konfirmasi (kanan bawah), walau teksnya belum terlihat
    // (animasi Victory). Pembacaan layar hanya untuk memeriksa, tidak memengaruhi jeda ketukan.
    @Volatile private var spamAktif = false
    private var spamThread: Thread? = null

    private fun mulaiSpamLanjut() = mulaiSpam(listOf(0.8625f to 0.921f), 50)

    // Ketuk beruntun di thread terpisah. Beberapa titik diketuk bergantian. Thread tidak boleh mati karena exception
    // (interrupt saat dihentikan sempat membuat aplikasi crash).
    private fun mulaiSpam(titik: List<Pair<Float, Float>>, jedaMs: Long) {
        hentikanSpam()
        spamAktif = true
        spamThread = Thread {
            var i = 0
            try {
                while (spamAktif && running) {
                    val sv = AutoService.inst ?: break
                    if (layarW > 0) {
                        val (fx, fy) = titik[i % titik.size]
                        sv.tapCepat(layarW * fx, layarH * fy)
                        i++
                    }
                    Thread.sleep(jedaMs)
                }
            } catch (_: Throwable) {
            }
        }.apply { isDaemon = true; start() }
    }

    private fun hentikanSpam() {
        spamAktif = false
        spamThread?.interrupt()
        spamThread = null
    }

    // ── Steps 12-14: Post-game screens ──
    private fun postGame() {
        val t0post = now()
        log("Langkah 12-14: Post-game, ketuk cepat tombol Lanjutkan (50 ms/ketuk) sampai lobi")
        log("  Game state saat masuk postGame: ${Cheat.statusGame}")
        status = "Post-game"
        mulaiSpamLanjut()
        val t0 = now()
        var halamanTerakhir = ""
        try {
            while (now() - t0 < 90_000L) {
                alive()
                val s = cap()
                // Selesai hanya kalau lobi/Classic benar-benar terlihat (menu bawah lobi atau tombol Mulai Game),
                // bukan sekadar ada kata kunci lobi di layar
                val lobiPasti = s.has("persiapan") || s.has("inventori") || s.has("koleksi") || isClassicPage(s)
                if (lobiPasti && !isPostGame(s)) {
                    log("Post-game selesai: ${if (isClassicPage(s)) "halaman Classic" else "lobi"} terlihat — postGame total ${(now() - t0post) / 1000}s")
                    return
                }
                val halaman = when {
                    s.has("mendapatkanmvp") -> "MVP"
                    s.has("konfirmasi") -> "Konfirmasi"
                    s.has("lanjutkan") -> "Lanjutkan"
                    s.has("victory") -> "Victory"
                    else -> ""
                }
                if (halaman.isNotEmpty() && halaman != halamanTerakhir) {
                    log("Halaman post-game: $halaman (${(now() - t0post) / 1000}s sejak postGame mulai) | game state: ${Cheat.statusGame}")
                    halamanTerakhir = halaman
                }
                // Konfirmasi di halaman Victory/MVP (pojok kanan bawah): ketuk lalu LANGSUNG back 3x (tanpa menunggu halaman lain)
                val konMvp = s.lines.firstOrNull { it.norm == "konfirmasi" && it.cx > s.w * 0.7f && it.cy > s.h * 0.85f }
                if (konMvp != null) {
                    tapLine(konMvp, "Konfirmasi (MVP)")
                    log("Konfirmasi MVP diketuk: langsung back 3x — postGame ${(now() - t0post) / 1000}s")
                    return
                }
                val ok = s.exact("ok")
                if (ok != null && ok.cy > s.h * 0.4f) {
                    tapLine(ok, "OK post-game")
                    continue
                }
                if (s.has("ketukdimanapun")) {
                    tapXY(s.w * 0.5f, s.h * 0.5f, "Tap anywhere post-game")
                    continue
                }
                popups(s)
            }
            log("⚠ Post-game belum selesai dalam 90 detik, lanjut saja — postGame ${(now() - t0post) / 1000}s")
        } finally {
            hentikanSpam()
        }
    }

    // ── Steps 15-16: Back to lobby ──
    private fun returnToLobby() {
        log("Langkah 15-16: back 3x ke lobby")
        status = "Kembali ke lobby"

        // Langkah 15: back tepat 3x (dari halaman Achievement / Classic ke lobi)
        for (i in 1..3) {
            alive()
            // Jeda antar back tepat 200 ms (bukan jeda antar langkah)
            AutoService.inst?.back()
            log("Back $i/3")
            sleepMs(200)
        }
        // Langkah 16: kalau masih ada popup, back 1x lagi
        run {
            val s = cap()
            if (!lobiUtama(s)) {
                log("Belum di lobi utama sesudah 3x back: back 1x lagi")
                back("Back tambahan (popup)")
            }
        }
        // Pengaman: kalau masih belum lobi utama, lanjut seperti sebelumnya
        for (i in 0..5) {
            alive()
            val s = cap()
            if (lobiUtama(s)) { log("Lobi utama tercapai"); break }
            if (tapTangan(s)) continue
            if (jenisPopupClassic(s) != null || (popups(s) && !isClassicPage(s))) continue
            back("Back ke lobby ($i)" + if (isClassicPage(s)) " dari halaman Classic" else "")
            sleepMs(300)
        }
        settleLobby(true)
    }



    // ── Steps 21-22: Profile → Akun ──
    // ── Steps 23-26: Ganti Server → next → confirm ──
    // These are handled by openServerList(), pickNext(), switchTo()

    // ── Main Flow ──
    private fun processOneServer(serverName: String) {
        serverT0 = now()
        log("═══ SERVER $serverName ═══")
        status = "Server $serverName"
        PaketKirim.reset()  // Reset seq tracker untuk server baru

        // Mode Cheat Only: hanya cheat yang jalan, Engine tidak melakukan apa-apa.
        // Tidak auto-off, tidak pindah server. Pengguna kontrol sendiri.
        if (Prefs.featCheatOnly) {
            log("Mode Cheat Only: Engine standby, hanya cheat yang aktif")
            log("  Cheat status: ${if (Cheat.aktif) "aktif" else "mati"} | tulis: ${when (Cheat.tulisTerbukti) { true -> "terbukti"; false -> "TIDAK masuk"; null -> "belum dicoba" }}")
            log("  Game status: ${Cheat.statusGame}")

            // Tunggu terus sampai user matikan — tidak auto-off, tidak pindah server
            var lastLog = 0L
            var lastGameState = ""
            while (running) {
                alive()
                val gs = Cheat.statusGame
                // Log tiap perubahan state game
                if (gs != lastGameState) {
                    log("[CheatOnly] Game state: $lastGameState → $gs")
                    lastGameState = gs
                }
                // Heartbeat log tiap 30 detik
                if (now() - lastLog > 30_000L) {
                    lastLog = now()
                    val elapsed = (now() - serverT0) / 1000
                    log("[CheatOnly] Berjalan ${elapsed}s | game=$gs | cheat=${if (Cheat.aktif) "aktif" else "mati"} | tulis=${Cheat.tulisTerbukti}")
                }
                sleepMs(500)
            }
            return
        }

        // Steps 1-3: Lobby → check Pertumbuhan Level
        if (Prefs.featLevelCheck) {
            run {
                val s = cap()
                if (isLobby(s)) {
                    checkLevelGrowth(s)
                }
            }
        } else {
            log("⊘ Cek Pertumbuhan Level: OFF")
        }

        // Steps 4-6 handled by checkLevelGrowth popups

        if (Prefs.featPlayGame) {
            // Steps 7-8: Enter Classic
            val t0enter = now()
            enterClassic()
            log("⏱ enterClassic: ${(now() - t0enter) / 1000}s")

            // Steps 9-11: Play game (tap turrets, wait for victory)
            val t0play = now()
            playGame()
            log("⏱ playGame: ${(now() - t0play) / 1000}s")

            // Steps 12-14: Post-game screens
            val t0post = now()
            postGame()
            log("⏱ postGame: ${(now() - t0post) / 1000}s")

            // Steps 15-16: Back to lobby
            val t0back = now()
            returnToLobby()
            log("⏱ returnToLobby: ${(now() - t0back) / 1000}s")
        } else {
            log("⊘ Main Classic: OFF")
        }

        // Steps 17-20: Event rewards (Hadiah Kemenangan)
        val t0claim = now()
        if (Prefs.featClaimEvent) {
            if (Prefs.featKlaimTcp) {
                // MODE TCP: kirim klaim via paket TCP langsung
                if (Cheat.tcpKlaimTerkirim) {
                    log("✓ TCP Klaim sudah terkirim saat End (skip klaim di lobby)")
                    Cheat.tcpKlaimTerkirim = false
                } else if (PaketKirim.capturedKlaimPost.isNotEmpty()
                    && PaketKirim.lastSeq > 0
                    && PaketKirim.gameServerIp.isNotEmpty()) {
                    log("TCP Klaim: payload tertangkap, kirim langsung via TCP")
                    val ok = PaketKirim.kirimKlaimHadiah()
                    if (ok) {
                        log("✓ Klaim terkirim via TCP (skip navigasi Event)")
                        sleepMs(1000)
                    } else {
                        log("TCP Klaim gagal, fallback ke navigasi Event")
                        claimHadiahKemenangan()
                    }
                } else {
                    PaketKirim.siapTangkap = true
                    log("TCP Klaim tidak tersedia (seq=${PaketKirim.lastSeq}, ip=${PaketKirim.gameServerIp}), klaim via UI + tangkap payload")
                    claimHadiahKemenangan()
                }
            } else {
                // MODE UI (default): klaim lewat navigasi Event di lobby
                log("Klaim via UI (navigasi Event)")
                claimHadiahKemenangan()
            }
            log("⏱ klaimEvent: ${(now() - t0claim) / 1000}s")
        } else {
            log("⊘ Klaim Event: OFF")
        }

        val elapsed = (now() - serverT0) / 1000
        log("Server $serverName selesai dalam ${elapsed}s")

        done.add(serverName)
        Prefs.addDone(serverName, acct)
        refreshCount()

        log("Progres: $doneCount/$total")

        // Catat ke aplikasi Catatan Cabang: server ini sudah di-up sampai level 20, keterangan "Biasa"
        if (Prefs.featPlayGame) catatKe(serverName, 20, "Biasa", "selesai di-up")
    }

    // Antrean catatan ke Catatan Cabang. Pengiriman jalan di latar belakang (satu utas sendiri) supaya tidak menahan proses up level.
    // Catatan yang belum bisa dikirim (ID akun atau kode server belum terbaca) ditahan dan dicoba lagi pada pengiriman berikutnya
    private val catatanTunda = ArrayList<Triple<String, Int, String>>()
    private val catatanPool = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "catatan-cabang").apply { isDaemon = true }
    }

    private fun catatKe(server: String, level: Int, ket: String, alasan: String) {
        synchronized(catatanTunda) {
            catatanTunda.add(Triple(server, level, ket))
            while (catatanTunda.size > 40) catatanTunda.removeAt(0)
        }
        val ctxC = app ?: return
        val id = acct
        val curNow = cur ?: ""
        try {
            catatanPool.execute { kirimTunda(ctxC, id, curNow, server, alasan) }
        } catch (e: Exception) {
            log("Catatan Cabang: gagal menjadwalkan pengiriman: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    private fun kirimTunda(ctxC: Context, id: String, curNow: String, server: String, alasan: String) {
        if (id.filter { it.isDigit() }.length < 6) {
            log("Catatan Cabang: ID akun belum terbaca, server $server ditahan dulu ($alasan)")
            return
        }
        val daftar = synchronized(catatanTunda) { ArrayList(catatanTunda) }
        for (e in daftar) {
            var sv = e.first
            // Server pertama belum punya kode (dicatat sebagai "Awal"): pakai kode server saat ini yang sudah terbaca
            if (sv.none { it.isDigit() }) {
                if (curNow.any { it.isDigit() }) sv = curNow else continue
            }
            val hasil = CatatanLink.kirim(ctxC, id, sv, e.second, e.third)
            log("Catatan Cabang: akun $id, server $sv, level ${e.second}, keterangan ${e.third}: $hasil" +
                (if (e.first == server) " ($alasan)" else " (tertunda)") + " [latar belakang]")
            if (hasil.startsWith("terkirim") || hasil.startsWith("dikirim")) {
                synchronized(catatanTunda) { catatanTunda.remove(e) }
            }
        }
    }

    private fun main() {
        val ctx = app ?: throw Stop("Aplikasi tidak siap")
        done.clear()
        synchronized(catatanTunda) { catatanTunda.clear() }
        skipped.clear()
        order.clear()
        cur = null
        acct = "-"
        doneCount = 0
        Prefs.purgeOld()

        status = "Membuka game"
        log("Mulai Auto up lvl. Paket: ${Prefs.pkg}")

        // Buka ML lewat Multi Run (otomatis, tanpa ketukan dari pengguna)
        bukaGame(ctx)

        sleepS(2.0)
        awaitLobby(240)
        settleLobby()

        // Log active features
        val feats = Prefs.activeFeatures()
        log("Fitur aktif: ${feats.joinToString(", ")}")
        log("Arah geser: ${if (Prefs.scrollDir == 0) "Cepat (maju)" else "Balik (dari awal)"}")

        // Process first server (current)
        status = "Server awal"
        processOneServer("Awal")

        if (!Prefs.featSwitchServer) {
            log("Ganti Server: OFF — hanya proses 1 server")
        } else {
            // Open server list
            status = "Membaca daftar server"
            val ls = openServerList()
            val rc = readCurrent(ls)
            if (rc != null) {
                cur = rc
                done.add(rc)
                // Server "Awal" adalah server yang sama dengan server saat ini: jangan dihitung dua kali
                done.remove("Awal")
                // Level server saat ini dibaca dari baris di "Semua Server", bukan dari baris "Server Saat Ini" (angkanya bisa usang, mis. 3)
                val hSemua = ls.find("semuaserver")
                val barisSemua = ls.lines.filter {
                    (hSemua == null || it.cy > hSemua.cy) &&
                        SRV.find(it.norm)?.value?.let { v -> fixSrv(v) } == rc
                }.minByOrNull { it.cy }
                val lvSemua = if (barisSemua != null) rowLevel(ls, barisSemua) else null
                if (lvSemua != null) log("Level $rc menurut daftar Semua Server: $lvSemua")
            }
            refreshCount()
            total = Prefs.serverCount
            log("Server saat ini: ${cur ?: "-"}, total: $total, selesai: $doneCount")

            // If scroll direction is "balik", scroll to top first
            if (Prefs.scrollDir == 1) {
                log("Scroll balik ke atas…")
                scrollTop(cap(R_SERVER))
            }

            // Cycle through remaining servers
            var guard = 0
            while (true) {
                alive()
                if (total > 0 && doneCount >= total) break
                val next = pickNext()
                if (next == null) {
                    log("Tidak ada server berikutnya")
                    break
                }
                switchTo(next)
                cur = next

                // Wait for lobby after server switch (lobi lama bisa terlihat sebentar sebelum game restart)
                awaitLobby(200, true)
                settleLobby()

                processOneServer(next)

                // Open server list again for next switch
                if (total > 0 && doneCount < total) {
                    openServerList()
                }

                guard++
                if (guard > 80) throw Stop("Terlalu banyak server (>80)")
            }
        }

        // Finish
        finishAction(ctx)
    }

    // Buka Multi Run lalu masuk ke ML otomatis.
    // 1) Kalau pengguna mengisi perintah langsung (Pengaturan), jalankan itu lewat Shizuku.
    // 2) Kalau tidak: buka Multi Run, cari entri ML lewat pohon aksesibilitas (klik), lalu OCR bila gagal.
    private fun bukaGame(ctx: Context) {
        var cmd = Prefs.launchCmd.trim()
        // Klon sendiri (Clone up lvl): buka MLBB di dalamnya langsung lewat ShortcutActivity, tanpa ketuk daftar.
        if (cmd.isEmpty() && Prefs.pkg == "top.niunaijun.blackbox") {
            cmd = "am start -n top.niunaijun.blackbox/top.niunaijun.blackboxa.view.main.ShortcutActivity " +
                "-e pkg com.mobile.legends --ei userId 0"
            log("Paket klon terdeteksi: MLBB dibuka langsung di Clone up lvl")
        }
        if (cmd.isNotEmpty()) {
            log("Buka langsung: $cmd")
            try {
                val r = ShizukuHelper.run(arrayOf("sh", "-c", cmd))
                log("Hasil perintah: kode ${r.first} ${r.second.take(160)} ${r.third.take(160)}")
            } catch (e: Throwable) {
                throw Stop("Perintah buka langsung gagal: ${e.message}")
            }
            return
        }
        try {
            val intent = ctx.packageManager.getLaunchIntentForPackage(Prefs.pkg)
                ?: throw Stop("Game ${Prefs.pkg} tidak ditemukan")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: Stop) { throw e } catch (e: Throwable) {
            throw Stop("Gagal membuka game: ${e.message}")
        }
        val re = Regex(Prefs.mlLabel, RegexOption.IGNORE_CASE)
        val t0 = now()
        var masuk = false
        sleepS(1.5)
        while (now() - t0 < 25000 && !masuk) {
            alive()
            val svc = AutoService.inst ?: throw Stop("Accessibility Service tidak aktif")
            if (svc.clickText(re)) {
                log("Entri ML di daftar app diketuk otomatis (pohon aksesibilitas)")
                masuk = true
                break
            }
            sleepMs(700)
        }
        if (!masuk) {
            // OCR: kalau Multi Run menggambar daftar tanpa node teks
            try {
                val s = cap()
                val l = s.lines.firstOrNull { re.containsMatchIn(it.text) }
                if (l != null) {
                    tapLine(l, "Entri ML (OCR)")
                    masuk = true
                }
            } catch (e: Stop) { throw e } catch (_: Throwable) {}
        }
        if (!masuk) {
            val teks = AutoService.inst?.dumpTexts(25) ?: emptyList()
            log("Entri ML tidak ditemukan di layar app. Teks terbaca: " + teks.joinToString(" | ").take(500))
            log("Kalau game sudah terbuka sendiri, proses lanjut menunggu lobby.")
        }
        sleepS(4.0)
    }

    // Diagnosa Multi Run: kumpulkan info untuk mencari cara membuka ML langsung
    fun diagnosaMultiRun(ctx: Context) {
        Thread {
            try {
                log("── Diagnosa Clone up lvl ──")
                if (!ShizukuHelper.hasPermission()) { log("Shizuku belum siap"); return@Thread }
                val p = Prefs.pkg
                val cmds = listOf(
                    "pm list packages -U | grep -i -E 'multirun|mobile.legends|mlbb|moba'",
                    "dumpsys package $p | grep -E 'Activity Resolver|android.intent.action.MAIN|LAUNCHER|filter|Action:' | head -30",
                    "cmd package resolve-activity --brief $p",
                    "dumpsys shortcut | grep -i -E 'multirun|shortLabel|cmp=' | head -30",
                    "dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity' | head -5"
                )
                for (c in cmds) {
                    val r = ShizukuHelper.run(arrayOf("sh", "-c", c))
                    log("$ $c")
                    for (ln in (r.second + "\n" + r.third).lines().filter { it.isNotBlank() }.take(30)) log("  " + ln.trim().take(220))
                }
                val tx = AutoService.inst?.dumpTexts(40)
                if (tx != null) log("Teks layar sekarang: " + tx.joinToString(" | ").take(700))
                log("── Selesai diagnosa ──")
            } catch (e: Throwable) {
                log("Diagnosa gagal: ${e.message}")
            }
        }.apply { isDaemon = true; start() }
    }

    private fun finishAction(ctx: Context) {
        val mode = Prefs.afterDone
        if (mode == 1) {
            log("Selesai: kembali ke Auto up lvl")
            try {
                val i = Intent(ctx, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                ctx.startActivity(i)
            } catch (_: Throwable) {}
        } else if (mode == 2) {
            log("Selesai: ke Home")
            AutoService.inst?.home()
        } else {
            log("Selesai: tetap di game")
            try { backToLobby() } catch (_: Stop) {}
        }
    }

    // ── Public API ──
    fun start(ctx: Context) {
        if (running) return
        generasi++
        val gSesi = generasi
        Prefs.init(ctx)
        CheatCfg.init(ctx)
        app = ctx.applicationContext
        running = true
        startedAt = System.currentTimeMillis()
        endedAt = 0L
        freezeCount = 0
        lastActive = now()
        readNo = 0
        lastFrame = null
        PaketKirim.resetSemua()  // Reset semua state paket untuk sesi baru

        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            try { wakeLock?.release() } catch (_: Throwable) {}
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AutoUpLvl::Engine").apply { acquire() }
        } catch (e: Throwable) {
            log("Wake lock gagal: ${e.javaClass.simpleName} ${e.message}")
        }
        try {
            KeepAliveService.start(ctx)
        } catch (e: Throwable) {
            log("Layanan latar gagal: ${e.javaClass.simpleName} ${e.message}")
        }

        Thread {
            generasiThread.set(gSesi)
            try {
                status = "Menyalakan aksesibilitas"
                if (AutoService.inst == null) {
                    AutoAccess.siapkan(ctx.applicationContext, 8000) { log(it) }
                }
                applyPerf()
                try { NetMon.mulai(ctx.applicationContext, Prefs.pkg) } catch (e: Throwable) { log("Pemantau jaringan gagal: ${e.message}") }
                Cheat.mulai(ctx)
                main()
                val n = done.size
                if (total > 0 && n >= total) Prefs.markAccountDone("sesi-" + System.currentTimeMillis())
                status = "Selesai ($n server)"
                log("═══ SELESAI: $n server telah di-up ═══")
                AutoService.inst?.banner("Selesai! $n server telah di-up level", 10000L)
            } catch (e: Stop) {
                if (gSesi == generasi) {
                    status = "Berhenti: ${e.message}"
                    log("Berhenti: ${e.message}")
                    AutoService.inst?.banner("Berhenti: ${e.message}", 8000L)
                } else log("Sesi lama berhenti (sudah digantikan sesi baru)")
            } catch (e: Throwable) {
                if (gSesi == generasi) {
                    status = "Error: ${e.message}"
                    log("Error: ${e.javaClass.simpleName}: ${e.message}")
                }
            } finally {
                // Sesi lama yang sudah digantikan tidak boleh mematikan sesi baru
                if (gSesi == generasi) {
                    running = false
                    endedAt = System.currentTimeMillis()
                    releasePerf()
                    Cheat.berhenti()
                    NetMon.henti()
                    try { wakeLock?.release() } catch (_: Throwable) {}
                    wakeLock = null
                    KeepAliveService.stop(ctx)
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        hentikanSpam()
        endedAt = System.currentTimeMillis()
        releasePerf()
        Cheat.berhenti()
        NetMon.henti()
        status = "Dihentikan"
        log("Dihentikan oleh pengguna")
    }
}
