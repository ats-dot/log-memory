package com.pencatat.memori

import android.content.Context
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.random.Random

// Port fitur skrip GG (ScriptV4.2.2 Offline) ke Kotlin. Berjalan di thread sendiri, bersamaan dengan Engine.
// Nama fungsi dan urutan langkah mengikuti skrip: putaranUtama -> tick(), executeScript, callEntity, logicAttribute,
// setHealthTower, logicSelfKDA/TeamKDA/EnemyKDA, logicSelfStat/TeamStat/EnemyStat, setAntiAfk, setTime, dst.
// Semua tulisan memori lewat Mem (dd ke /proc/<pid>/mem). Hasil tulis dicek dengan baca ulang dan dilaporkan di log.
object Cheat {

    private val C = CheatCfg

    @Volatile var aktif = false
    @Volatile var statusTeks = "Mati"
    @Volatile var statusGame = "-"
    // null = belum dicoba, true = tulis terbukti masuk, false = tulis dicoba tapi tidak masuk
    @Volatile var tulisTerbukti: Boolean? = null
    @Volatile var langkahTeks = ""
    // true = sudah terhubung ke game dan Quick Mode sudah diproses (atau tidak perlu). Engine menunggu ini sebelum Mulai Game.
    @Volatile var siapMain = false
    // Diset true oleh Engine selama playGame() (dari mulai nunggu match sampai match selesai/Victory).
    // Watchdog offset lbm di tick() cuma boleh curiga & rescan kalau ini true — di luar rentang ini (lobi,
    // navigasi menu, dll.) status "Unknown" itu MEMANG benar, bukan tanda offset salah, jadi jangan dipicu.
    @Volatile var sedangTungguMatch = false

    private var thread: Thread? = null
    private var ctxApp: Context? = null
    private val aksi = ConcurrentLinkedQueue<String>()

    private fun log(m: String) = AppLog.add("[Cheat] $m")

    fun mulai(ctx: Context) {
        if (aktif) return
        ctxApp = ctx.applicationContext
        aktif = true
        siapMain = false
        statusTeks = "Menunggu game"
        thread = Thread({ utama() }, "cheat").apply { isDaemon = true; start() }
    }

    fun berhenti() {
        aktif = false
        thread?.interrupt()
        thread = null
        statusTeks = "Mati"
    }

    // Aksi sekali jalan dari Pengaturan (padanan item menu yang bukan toggle)
    fun minta(nama: String) {
        aksi.add(nama)
    }

    // ═══════════ Konstanta offset (tabel offset skrip) ═══════════
    private const val O_STATE = 288
    private const val O_SELF = 416
    private const val O_FRAME = 316
    private const val O_REALCOUNT = 412
    private const val O_SOLDIER = 200
    private const val O_MAIN_A = 112
    private const val O_MAIN_B = 120
    private const val O_DIC_MON = 80
    private const val O_DIC_PLAYER = 72
    private const val O_CAMP = 484
    private const val O_BSELF = 440
    private const val O_ID = 180
    private const val O_ACID = 48
    private const val O_POS = 604
    private const val O_POSV = 612
    private const val O_DPX = 620
    private const val O_DPY = 628
    private const val O_POS3 = 636
    private const val O_POS3V = 644
    private const val O_MOVEDIR = 652
    private const val O_ATTRCOMP = 1296
    private const val O_CANTHURT = 1888
    private const val O_DELET = 1840
    private const val O_PLAYERDATA = 3384
    private const val O_CONNECTED = 3248
    private const val O_WAITAI = 3156
    private const val O_OPMON = 3424
    private const val O_TOTALGOLD = 2184
    private const val O_HURTHERO = 2216
    private const val O_HURTTOWER = 2280
    private const val O_INJURED = 2368
    private const val O_DOUBLE = 2884
    private const val O_TRIPLE = 2888
    private const val O_QUADRA = 2892
    private const val O_PENTA = 2896
    private const val O_MAXCONT = 3672
    private const val O_WEEKKILL = 3688
    private const val O_KILLTOWER = 2696
    private const val O_KILLLINGZHU = 2712
    private const val O_KILLSHENGUI = 2720
    private const val D_KILL = 56
    private const val D_DEAD = 60
    private const val D_ASSIST = 76
    private const val D_GOLD = 96
    private const val D_EXP = 104
    private const val D_LEVELMAX = 16
    // Semua offset SystemData di bawah ini (+8 dari nilai lama) dikoreksi 2026-11-27 berdasarkan
    // dump manual: struct SystemData geser +8 byte menyeluruh gara-gara update game (kemungkinan ada
    // 1 field baru ~8 byte disisipkan game sebelum offset lama 696). Bukti dari dump (Set Level MATI):
    //  - S_LEVEL lama(696)=0x96395660 (sampah) -> baru(704)=3, PERSIS sama level akun asli di dump itu.
    //  - S_UID   lama(872)=0 (mustahil)        -> baru(880)=0x88cde0e4 (angka wajar buat UID).
    //  - S_ROOM  lama(856)=pointer NULL        -> baru(864)=0x741fb56f60 (pointer valid, pola cocok).
    //  - S_MSG   lama(1112)=pointer NULL       -> baru(1120)=0x6f46e6ddc0 (pointer valid).
    //  - S_ENTER lama(7680)=96 (aneh buat flag)-> baru(7688)=1 (wajar buat flag boolean).
    // QUICK_OFF & S_HANDLER TIDAK ikut digeser: QUICK_OFF (514 dst.) masih kebukti jalan normal di log
    // (tulis & baca balik cocok), dan S_HANDLER itu offset di DALAM objek lain (bukan di statics
    // SystemData ini), jadi gak kena pergeseran struct ini.
    private const val S_LEVEL = 704
    private const val S_ENTER = 7688
    private const val S_UID = 880
    private const val S_ROOM = 864
    private const val S_MSG = 1120
    private const val S_HANDLER = 136
    private const val S_HANDLER_FIELD = 16
    private const val P_BLOK = 3712
    private const val M_BLOK = 2368   // harus > M_GUARD (2352) + 4
    private const val M_TYPE = 2184
    private const val M_GUARD = 2352

    private val STATUS = Daftar.STATUS

    // ═══════════ Tabel posisi tower (dari skrip) ═══════════
    private fun v5(x: Float, y: Float, z: Float) = floatArrayOf(x, y, x, y, z)

    private val towerBIndexVec = arrayOf(
        v5(2.52044677734375f, -1.971832275390625f, 0f), v5(2.8099365234375f, -1.8802490234375f, 0f),
        v5(2.95745849609375f, -1.668182373046875f, 0f), v5(3.0517578125f, -1.80548095703125f, 0f)
    )
    private val towerBBrawlIndexVec = arrayOf(v5(12.048828125f, 0f, 0f), v5(21.09765625f, 0f, 0f), v5(32.5f, 0f, 0f))
    private val playerTowerPosB = towerBIndexVec
    private val playerTowerBrawlPosB = arrayOf(
        v5(10.912109375f, 0.10162353516f, 0.890625f), v5(20.1796875f, 0.11875915527f, 0.9375f),
        v5(29.8046875f, 0.98486328125f, 0.953125f)
    )
    private val towerAIndexVec = arrayOf(
        v5(-10.1796875f, 1.39990234375f, 0f), v5(-21.19921875f, 1.2998046875f, 0f),
        v5(-31.19921875f, 0f, 0f), v5(-41.21875f, 0f, 0f)
    )
    private val towerABrawlIndexVec = arrayOf(v5(-12.048828125f, 0f, 0f), v5(-21.09765625f, 0f, 0f), v5(-32.5f, 0f, 0f))
    private val playerTowerPosA = arrayOf(
        v5(-8.49609375f, 1.27368164062f, -0.96875f), v5(-19.41015625f, 1.44750976562f, -0.984375f),
        v5(-29.83984375f, -0.12489318848f, -0.90625f), v5(-38.703125f, -0.21624755859f, -0.984375f)
    )
    private val playerTowerBrawlPosA = arrayOf(
        v5(-10.44140625f, -0.36578369141f, -0.9375f), v5(-20.0078125f, 0.16821289062f, -0.96875f),
        v5(-30.2734375f, 0.51330566406f, -0.984375f)
    )
    private val towerMid = arrayOf(
        v5(2.568115234375f, -1.93499755859375f, 0f), v5(2.83123779296875f, -1.9224853515625f, 0f),
        v5(2.98748779296875f, 0f, 0f), v5(3.072021484375f, 0f, 0f)
    )
    private val vecBasePhase1 = v5(-16.23046875f, 0.33673095703f, 0.984375f)

    // ═══════════ Status sesi (per proses game) ═══════════
    private class Mon(val a: Long, val camp: Int, val tipe: Int, var b59: Int, val b72: Int, val guard: Int) {
        val menara: Boolean get() = b59 == 1 || b72 == 1 || tipe == 2
    }

    private class Op(val a: Long, val b: ByteArray)

    private var sh: GameShell? = null
    private var mem: Mem? = null
    private var sas: Sasaran? = null
    private var lbm = 0L
    private var scene = 0L
    private var terakhirCari = 0L

    private var teamP = ArrayList<Long>()
    private var enemyP = ArrayList<Long>()
    private var teamM = ArrayList<Mon>()
    private var enemyM = ArrayList<Mon>()
    private var userCamp = 0
    private var percobaanEntity = 0

    private var isApply = true
    private var isNeedRestore = false
    private var isExecute = false
    private var isChangeStat = true
    private var isCancelTeleport = false
    private var isCheckHuman = true
    private var holdStopMinion = ArrayList<Op>()
    private var updateShield = ArrayList<Op>()
    private var antiRes = ArrayList<Op>()
    private var holdFirstBlood = false
    private var lfd = 0L
    private var firstBloodId = 0L
    private var enemySoldier = LinkedHashSet<Long>()
    private var midTowerScript: List<Long> = emptyList()
    private var isBrawlTP = false
    private var loseClockMs = 0L
    private var autoEndLihat = 0L
    private var autoEndMulai = 0L
    private var autoEndTulis: ArrayList<Op>? = null
    private var quickAsli: ArrayList<Op>? = null
    private var quickTulis = ArrayList<Op>()
    private var dodTerpasang = false
    private var verifSisa = 4
    private var ujiAwalSelesai = false
    private var quickDiuji = false
    private var quickLogN = 0
    // CATATAN: update game terbaru menyisipkan 1 field baru (8 byte) di layout SystemData, di suatu
    // tempat ANTARA offset 2036 dan 4945. Semua field boolean SESUDAH titik sisip itu geser +8 byte.
    // Dikonfirmasi lewat dump mentah (bukan tebakan) untuk ketiganya:
    //  - 9576 -> 9584: diff sebelum/sesudah tap "Mulai Game" nunjukin byte yang biasa ditimpa game
    //    jadi 0 sekarang ada persis di +9584 (sebelumnya 1, sesudah tap jadi 0 — sama kayak di 9576 dulu).
    //  - 4945 -> 4953 dan 7680 -> 7688: di kedua offset LAMA sekarang ada potongan byte PERTAMA dari
    //    sebuah pointer (bukan boolean lagi), sedangkan persis +8 byte sesudahnya ada nilai 0 yang stabil
    //    di semua snapshot (150ms/300ms/1000ms/3000ms) — pola identik dengan kasus 9576->9584, jadi bukan
    //    kebetulan. Offset 514, 516, 2036 TIDAK ikut geser (masih valid di posisi lama), jadi titik sisipnya
    //    ada di antara 2036 dan 4945, bukan di awal struct.
    private val QUICK_OFF = intArrayOf(514, 516, 2036, 4953, 9584, 7688)

    // Nilai 6 field Quick Mode saat ini, untuk log
    private fun ringkasQuick(): String {
        val s = sas ?: return "-"
        val mm = mem ?: return "-"
        val sb = StringBuilder()
        for (o in QUICK_OFF) {
            val v = if (o == 2036) mm.r32(s.sdStatis + o) else mm.r8(s.sdStatis + o)
            sb.append(o).append('=').append(v ?: "?").append(' ')
        }
        return sb.toString().trim()
    }

    // ═══════════ Debug: dump area SystemData statics (buat re-kalibrasi offset sesudah update game) ═══════════
    // Dump byte mentah di sekitar offset QUICK_OFF (0..10000 dari sdStatis) ke berkas di Download/AutoUpLvl,
    // supaya bisa dibandingkan before/after suatu kejadian (mis. ketuk Mulai Game) untuk mencari offset baru.
    private const val DUMP_PANJANG = 10100
    private const val DUMP_MARGIN = 64  // sedikit sebelum offset 0 untuk konteks

    fun dumpQuickArea(label: String) {
        val s = sas
        val mm = mem
        val ctx = ctxApp
        if (s == null || mm == null || ctx == null) {
            log("Dump $label dilewati: game belum terhubung")
            return
        }
        val mulaiBaca = s.sdStatis - DUMP_MARGIN
        val data = mm.blok(mulaiBaca, DUMP_PANJANG)
        if (data == null) {
            log("Dump $label gagal: baca memori gagal")
            return
        }
        val t = System.currentTimeMillis()
        val dt = if (tapMulaiAt > 0) t - tapMulaiAt else -1L
        val namaBerkas = "quickdump-" + label + "-" +
            java.text.SimpleDateFormat("HHmmss-SSS", java.util.Locale.US).format(java.util.Date(t)) + ".txt"
        try {
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, namaBerkas)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/AutoUpLvl")
            }
            val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            val os = if (uri != null) ctx.contentResolver.openOutputStream(uri) else null
            if (os == null) {
                log("Dump $label gagal: tidak bisa buka berkas output")
                return
            }
            val sb = StringBuilder()
            sb.append("label=").append(label).append(" t=").append(t)
            if (dt >= 0) sb.append(" dt_sejak_tap_mulai=").append(dt).append("ms")
            sb.append('\n')
            sb.append("sdStatis=0x").append(java.lang.Long.toHexString(s.sdStatis))
            sb.append(" dumpMulaiPada=sdStatis-").append(DUMP_MARGIN)
            sb.append(" panjang=").append(DUMP_PANJANG).append('\n')
            sb.append("\nNilai QUICK_OFF (offset lama) saat ini:\n")
            for (o in QUICK_OFF) {
                val v8 = mm.r8(s.sdStatis + o)
                val v32 = mm.r32(s.sdStatis + o)
                sb.append("  off=").append(o).append("  byte=").append(v8).append("  int32=").append(v32).append('\n')
            }
            sb.append("\nHex dump (offset relatif ke sdStatis, per baris 32 byte):\n")
            var i = 0
            while (i < data.size) {
                val n = minOf(32, data.size - i)
                val offsetAsli = i - DUMP_MARGIN
                val hex = StringBuilder(n * 2)
                for (j in 0 until n) hex.append(String.format("%02x", data[i + j]))
                sb.append(String.format("off=%6d  %s\n", offsetAsli, hex))
                i += 32
            }
            os.write(sb.toString().toByteArray())
            os.flush()
            os.close()
            log("Dump $label disimpan ke Download/AutoUpLvl/$namaBerkas")
        } catch (e: Throwable) {
            log("Dump $label error: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════════════════════
    //  SELF-HEAL: resolusi offset pointer instance LogicBattleManager (lbm) OTOMATIS saat runtime
    // ═══════════════════════════════════════════════════════════════════════════════════════════
    // s.lbmGlobal sekarang = alamat MENTAH statics LogicBattleManager (sl), bukan field pointer-nya
    // langsung. Field di dalam statics ini yang berisi pointer ke instance match aktif bisa pindah
    // offset tiap game update (dulu +0x28, baru2 ini ketemu +0x650 lewat dump manual) — kalau
    // di-hardcode, bakal basi lagi pas update berikutnya dan semua fitur in-match mati total lagi
    // sampai saya sempat gali dump manual. Supaya TIDAK pernah meleset walau offset pindah lagi:
    //
    // 1. Coba dulu offset yang terakhir "dipelajari" (disimpan di Prefs, persis seperti cara kelas
    //    IL2CPP dipelajari di Pencari.kt) — cepat, 1 baca pointer per tick.
    // 2. Kalau itu gagal (hasil 0 atau bukan pointer valid), background thread (tidak memblokir
    //    tick utama) mengambil 2 snapshot are statics ini berjarak ~300ms, dan mencari SEMUA field
    //    8-byte yang nilainya 0 di snapshot pertama lalu berubah jadi pointer heap valid di snapshot
    //    kedua — itulah field yang baru saja diisi game (artinya: baru masuk match).
    // 3. Tiap kandidat divalidasi silang sebelum dipakai permanen: baca O_FRAME (frame counter) lewat
    //    kandidat itu 2x berjarak ~250ms — kalau nilainya naik, berarti kandidat itu BENAR instance
    //    LogicBattleManager yang hidup (frame counter cuma naik kalau match lagi berjalan). Kandidat
    //    yang lolos baru disimpan permanen ke Prefs; yang belum lolos dipakai sementara saja dan terus
    //    dicoba validasi ulang di scan berikutnya.
    // 4. Scan diulang otomatis tiap beberapa detik selama lbm masih 0 — tidak perlu tap/aksi manual
    //    apapun dari pengguna, dan jalan baik di Mode Cheat Only maupun mode auto biasa.
    private const val DEFAULT_LBM_INSTANCE_OFF = 0x650L
    private const val LBM_SCAN_PANJANG = 2560  // cakup lebih luas dari offset yang pernah ketemu (0x650=1616)
    private const val LBM_SCAN_JEDA_MS = 4000L // jangan scan tiap tick, cukup tiap beberapa detik
    private var lbmOff = 0L
    private var lbmOffTervalidasi = false
    @Volatile private var lbmScanBerjalan = false
    private var lbmScanTerakhir = 0L
    @Volatile private var lbmValidasiBerjalan = false
    private var lbmValidasiTerakhir = 0L
    // Watchdog (ditemukan dari log round-5 & round-6): offset +0x570 lolos validasi O_FRAME (frame-nya
    // emang naik) tapi ternyata BUKAN instance match yang beneran hidup — terbukti dari eState yang
    // kebaca di offset itu TETAP "Unknown" terus-menerus walau sudah ditunggu lama sesudah tap Mulai
    // Game, 2 sesi tes berturut-turut, dengan offset yang SAMA. Jadi validasi O_FRAME doang ternyata
    // tidak cukup — ada objek lain di statics struct yang kebetulan juga punya counter yang naik di
    // offset relatif yang sama. Sambil belum ada cara buat memvalidasi eState secara langsung (lih.
    // catatan di Daftar.STATUS: index 0 = "Unknown" itu SAH buat objek yang beneran, jadi gak bisa asal
    // tolak index 0 sebagai "pasti salah"), dikasih pengaman: kalau offset yang lagi "dipercaya" ternyata
    // gak pernah bikin status keluar dari Unknown dalam waktu lama, curigai offset itu & paksa cari ulang
    // dengan mengecualikan offset itu supaya scan berikutnya wajib coba kandidat lain.
    private const val LBM_CURIGA_UNKNOWN_MS = 25_000L
    private var lbmUnknownSejak = 0L
    private var lbmOffDikecualikan = 0L

    // Pointer heap di proses game ini (il2cpp managed heap) konsisten pakai ~5 byte signifikan dengan
    // byte ke-5 (bit 32-39) di rentang ini (teramati: 0x6f, 0x74, 0x79, 0x7a, dst). Dipakai buat
    // membedakan "pointer valid" dari byte sampah/angka biasa.
    private fun mirip64BitPointer(v: Long): Boolean {
        if (v == 0L) return false
        val byteKe5 = (v ushr 32) and 0xFFL
        return byteKe5 in 0x60L..0x85L
    }

    // CATATAN PENTING (bug yang diperbaiki): dulu kalau offset default/lama (+0x650) masih kebetulan
    // menunjuk ke suatu nilai yang BENTUKNYA mirip pointer (lolos mirip64BitPointer), nilai itu langsung
    // dipercaya & dipakai tanpa pernah divalidasi lewat O_FRAME — jadi kalau game update dan offset itu
    // sudah basi tapi "kebetulan" masih mirip pointer (nunjuk ke objek lain yang tidak hidup/match),
    // scan self-heal TIDAK PERNAH jalan sama sekali karena ambilLbm() keburu return duluan. Sekarang,
    // offset yang belum pernah tervalidasi WAJIB lolos cek O_FRAME (baca 2x, harus naik) dulu sebelum
    // dipercaya; kalau gagal, offset dibuang dan scan penuh dipaksa jalan dari awal.

    // Dipanggil tiap tick dari putaranUtama. HARUS cepat (tidak boleh blocking I/O berat di sini).
    private fun ambilLbm(mm: Mem, s: Sasaran): Long {
        if (lbmOff == 0L) {
            val belajar = Prefs.hintBelajar("lbmInstanceOff")
            if (belajar != 0L) {
                lbmOff = belajar
                lbmOffTervalidasi = true // offset ini sebelumnya SUDAH lolos validasi O_FRAME & disimpan
            } else {
                lbmOff = DEFAULT_LBM_INSTANCE_OFF
                lbmOffTervalidasi = false // offset bawaan/lama, belum tentu masih benar, wajib divalidasi dulu
            }
        }
        val p = mm.p(s.lbmGlobal + lbmOff)
        if (p != 0L && mirip64BitPointer(p)) {
            if (lbmOffTervalidasi) return p
            // Bentuknya mirip pointer, TAPI belum pernah dibuktikan hidup — jangan dipakai dulu buat fitur
            // apapun, validasi dulu di background (baca O_FRAME 2x, harus naik antar bacaan).
            cekValidasiLbm(mm, p)
            return 0L
        }

        // Offset saat ini lagi gak ngasih pointer valid sama sekali — kalau sebelumnya pernah tervalidasi
        // (misal baru keluar match / statics-nya sempat kosong), reset status supaya dicoba divalidasi
        // ulang nanti, dan paksa cari ulang dari nol.
        lbmOffTervalidasi = false
        lbmOff = 0L
        jadwalkanScanLbm(s, false)
        return 0L
    }

    private fun cekValidasiLbm(mm: Mem, ptr: Long) {
        val now = System.currentTimeMillis()
        if (lbmValidasiBerjalan || now - lbmValidasiTerakhir < LBM_SCAN_JEDA_MS) return
        lbmValidasiTerakhir = now
        lbmValidasiBerjalan = true
        val off = lbmOff
        Thread({
            try {
                val f1 = mm.d(ptr + O_FRAME)
                tidur(250L)
                val f2 = mm.d(ptr + O_FRAME)
                val valid = f2 > f1 && f1 in 0..50_000_000 && f2 in 0..50_000_000
                log("[Cheat] Validasi offset lbm +0x${java.lang.Long.toHexString(off)} (ptr=0x${java.lang.Long.toHexString(ptr)}): frame $f1->$f2 ${if (valid) "✓ VALID, dipercaya & disimpan" else "✗ TIDAK valid (basi), dibuang & dicari ulang"}")
                if (valid) {
                    lbmOffTervalidasi = true
                    Prefs.simpanHintBelajar("lbmInstanceOff", off)
                } else {
                    lbmOffTervalidasi = false
                    lbmOff = 0L
                    val sCopy = sas
                    if (sCopy != null) jadwalkanScanLbm(sCopy, true)
                }
            } catch (_: Throwable) {} finally { lbmValidasiBerjalan = false }
        }, "validasi-lbm").apply { isDaemon = true }.start()
    }

    private fun jadwalkanScanLbm(s: Sasaran, segera: Boolean) {
        val now = System.currentTimeMillis()
        if (!lbmScanBerjalan && (segera || now - lbmScanTerakhir > LBM_SCAN_JEDA_MS)) {
            lbmScanTerakhir = now
            lbmScanBerjalan = true
            Thread({
                try { scanLbmOffset(s) } catch (_: Throwable) {} finally { lbmScanBerjalan = false }
            }, "scan-lbm-off").apply { isDaemon = true }.start()
        }
    }

    // CATATAN PENTING (bug ke-2 yang diperbaiki, ditemukan dari log round-4): sebelumnya scan ini cuma
    // menganggap sebuah offset sebagai "kandidat" kalau nilainya 0 di bacaan pertama lalu BERUBAH jadi
    // pointer di bacaan kedua (300ms kemudian) — yaitu nangkap momen PERSIS field lbm baru keisi (match
    // baru mulai). Masalahnya: kalau scan ini baru kepanggil SETELAH field itu sudah keisi duluan (msl.
    // karena offset lama +0x650 masih "mirip pointer" jadi ambilLbm() sempat berjalan lewat jalur validasi
    // cekValidasiLbm dulu, baru nanti gagal & manggil scan ini), maka di KEDUA bacaan field itu sudah
    // sama-sama non-zero (bukan 0→pointer lagi) — jadi tidak pernah masuk daftar kandidat sama sekali,
    // dan scan ini diam-diam gagal terus-menerus tanpa pernah menemukan offset yang benar (persis yang
    // kejadian di log round-4: "Validasi offset lbm +0x650 ... dibuang & dicari ulang" berulang terus
    // tanpa SEKALIPUN ada log "Scan offset lbm: N kandidat ditemukan"). Sekarang kandidat diambil dari
    // SEMUA slot yang BENTUKNYA mirip pointer (apapun nilai sebelumnya), lalu satu-satunya yang menentukan
    // benar/tidaknya tetap O_FRAME (baca 2x, harus naik) — jadi tetap aman dari kebetulan "mirip pointer"
    // doang, tapi tidak lagi buta kalau field-nya sudah lama keisi sebelum scan sempat jalan. Validasi
    // O_FRAME untuk SEMUA kandidat juga digabung jadi 1x tunggu 250ms (bukan per-kandidat satu-satu) biar
    // scan-nya tidak jadi lambat walau kandidatnya banyak.
    private fun scanLbmOffset(s: Sasaran) {
        val mm = mem ?: return
        val a = mm.blok(s.lbmGlobal, LBM_SCAN_PANJANG) ?: return
        val dikecualikan = lbmOffDikecualikan
        lbmOffDikecualikan = 0L  // sekali pakai: jangan ngeban permanen, cuma dorong supaya coba kandidat lain dulu
        val kandidatOff = ArrayList<Long>()
        var i = 0
        while (i + 8 <= a.size) {
            var v = 0L
            for (j in 7 downTo 0) v = (v shl 8) or (a[i + j].toLong() and 0xFF)
            if (mirip64BitPointer(v) && i.toLong() != dikecualikan) kandidatOff.add(i.toLong())
            i += 8
        }
        if (kandidatOff.isEmpty()) return

        log("[Cheat] Scan offset lbm: ${kandidatOff.size} kandidat pointer ditemukan" +
            (if (dikecualikan != 0L) " (offset +0x${java.lang.Long.toHexString(dikecualikan)} dikecualikan dulu, dicurigai salah)" else "") +
            ", memvalidasi via O_FRAME...")
        val ptr0 = kandidatOff.map { off -> mm.p(s.lbmGlobal + off) }
        val f1 = ptr0.map { ptr -> if (ptr != 0L) mm.d(ptr + O_FRAME) else null }
        tidur(250L)
        val f2 = ptr0.map { ptr -> if (ptr != 0L) mm.d(ptr + O_FRAME) else null }
        for (idx in kandidatOff.indices) {
            val off = kandidatOff[idx]
            val ptr = ptr0[idx]
            val a1 = f1[idx]
            val a2 = f2[idx]
            if (ptr == 0L || a1 == null || a2 == null) continue
            val valid = a2 > a1 && a1 in 0..50_000_000 && a2 in 0..50_000_000
            log("[Cheat]   kandidat off=+0x${java.lang.Long.toHexString(off)} ptr=0x${java.lang.Long.toHexString(ptr)} frame $a1->$a2 ${if (valid) "✓ VALID" else "belum pasti"}")
            if (valid) {
                lbmOff = off
                lbmOffTervalidasi = true
                Prefs.simpanHintBelajar("lbmInstanceOff", off)
                log("[Cheat] Offset pointer instance LBM dipelajari & disimpan: +0x${java.lang.Long.toHexString(off)}")
                return
            }
        }
        // Belum ada yang lolos validasi frame (mungkin kepanggil pas transisi/loading) — pakai kandidat
        // pertama SEMENTARA (tidak disimpan permanen) supaya status & fitur bisa jalan duluan,
        // nanti scan berikutnya coba validasi ulang.
        if (!lbmOffTervalidasi) {
            lbmOff = kandidatOff[0]
            log("[Cheat] Pakai kandidat offset +0x${java.lang.Long.toHexString(lbmOff)} sementara (belum tervalidasi, akan dicoba ulang)")
        }
    }

    // ═══════════ Debug: dump area statics LogicBattleManager (manual, buat cek langsung kalau perlu) ═══════════
    private const val DUMP_LBM_PANJANG = 2560
    private const val DUMP_LBM_MARGIN = 64  // baca mulai sedikit sebelum offset 0 (statics base) untuk konteks

    fun dumpLbmArea(label: String) {
        val s = sas
        val mm = mem
        val ctx = ctxApp
        if (s == null || mm == null || ctx == null) {
            log("Dump LBM $label dilewati: game belum terhubung")
            return
        }
        val slBase = s.lbmGlobal  // sekarang sudah = statics base langsung (offset 0 = awal statics)
        val mulaiBaca = slBase - DUMP_LBM_MARGIN
        val data = mm.blok(mulaiBaca, DUMP_LBM_PANJANG)
        if (data == null) {
            log("Dump LBM $label gagal: baca memori gagal")
            return
        }
        val t = System.currentTimeMillis()
        val namaBerkas = "lbmdump-" + label + "-" +
            java.text.SimpleDateFormat("HHmmss-SSS", java.util.Locale.US).format(java.util.Date(t)) + ".txt"
        try {
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, namaBerkas)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/AutoUpLvl")
            }
            val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            val os = if (uri != null) ctx.contentResolver.openOutputStream(uri) else null
            if (os == null) {
                log("Dump LBM $label gagal: tidak bisa buka berkas output")
                return
            }
            val sb = StringBuilder()
            sb.append("label=").append(label).append(" t=").append(t).append('\n')
            sb.append("slBase(statics LBM)=0x").append(java.lang.Long.toHexString(slBase))
            sb.append(" dumpMulaiPada=slBase-").append(DUMP_LBM_MARGIN)
            sb.append(" panjang=").append(DUMP_LBM_PANJANG).append('\n')
            sb.append("offset aktif saat ini: lbmOff=+0x").append(java.lang.Long.toHexString(lbmOff))
                .append(" tervalidasi=").append(lbmOffTervalidasi)
                .append(" lbm(pointer hasil)=0x").append(java.lang.Long.toHexString(mm.p(slBase + lbmOff))).append('\n')
            sb.append("\nKandidat pointer (8 byte selaras, mirip pointer heap valid di proses ini):\n")
            var i = 0
            while (i + 8 <= data.size) {
                var v = 0L
                for (j in 7 downTo 0) v = (v shl 8) or (data[i + j].toLong() and 0xFF)
                if (mirip64BitPointer(v)) {
                    val offsetAsli = i - DUMP_LBM_MARGIN
                    sb.append("  off=").append(offsetAsli).append(" (0x").append(java.lang.Long.toHexString(offsetAsli.toLong()))
                        .append(")  val=0x").append(java.lang.Long.toHexString(v)).append('\n')
                }
                i += 8
            }
            sb.append("\nHex dump (offset relatif ke slBase, per baris 32 byte):\n")
            i = 0
            while (i < data.size) {
                val n = minOf(32, data.size - i)
                val offsetAsli = i - DUMP_LBM_MARGIN
                val hex = StringBuilder(n * 2)
                for (j in 0 until n) hex.append(String.format("%02x", data[i + j]))
                sb.append(String.format("off=%6d  %s\n", offsetAsli, hex))
                i += 32
            }
            os.write(sb.toString().toByteArray())
            os.flush()
            os.close()
            log("Dump LBM $label disimpan ke Download/AutoUpLvl/$namaBerkas")
        } catch (e: Throwable) {
            log("Dump LBM $label error: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    // ═══════════ Debug: dump logcat (cek apakah game CRASH beneran atau cuma koneksi putus biasa) ═══════════
    // Dipicu otomatis kalau status lompat dari Play LANGSUNG ke selain "waitEnd" pas Auto End lagi aktif
    // (match normal HARUS lewat Play -> waitEnd -> End -> Unknown; kalau lompat, kemungkinan besar proses
    // game-nya mati paksa/crash, bukan match selesai wajar - makanya "Pertandingan" di profil ga nambah).
    // Shizuku punya izin baca logcat tanpa root (sama kayak "adb shell logcat"), jadi gak perlu scan memori.
    fun dumpLogcat(label: String) {
        val ctx = ctxApp
        if (ctx == null) {
            log("Dump logcat $label dilewati: konteks app belum siap")
            return
        }
        if (!ShizukuHelper.hasPermission()) {
            log("Dump logcat $label dilewati: Shizuku belum punya izin")
            return
        }
        try {
            val (kode, out, err) = ShizukuHelper.run(arrayOf("sh", "-c", "logcat -b all -d -v threadtime -t 4000"))
            val isi = if (out.isNotEmpty()) out else err
            if (isi.isEmpty()) {
                log("Dump logcat $label gagal: keluaran kosong (rc=$kode)")
                return
            }
            val t = System.currentTimeMillis()
            val namaBerkas = "logcat-" + label + "-" +
                java.text.SimpleDateFormat("HHmmss-SSS", java.util.Locale.US).format(java.util.Date(t)) + ".txt"
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, namaBerkas)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/AutoUpLvl")
            }
            val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            val os = if (uri != null) ctx.contentResolver.openOutputStream(uri) else null
            if (os == null) {
                log("Dump logcat $label gagal: tidak bisa buka berkas output")
                return
            }
            val sb = StringBuilder()
            sb.append("label=").append(label).append(" t=").append(t).append(" rc=").append(kode).append('\n')
            // Ringkasan baris yang kemungkinan tanda crash/mati paksa, biar gampang dicek sekilas tanpa scroll semua.
            val kataKunci = listOf(
                "FATAL EXCEPTION", "Fatal signal", "AndroidRuntime", "tombstone", "libc", "signal 11",
                "lowmemorykiller", "Killed", "OutOfMemory", "top.niunaijun.blackbox", "ActivityManager: Process", "died"
            )
            val baris = isi.lines()
            val cocok = baris.filter { b -> kataKunci.any { k -> b.contains(k, ignoreCase = true) } }
            sb.append("\n=== Baris yang kemungkinan terkait crash/mati paksa (").append(cocok.size).append(" baris) ===\n")
            if (cocok.isEmpty()) sb.append("(tidak ada - kemungkinan BUKAN crash native, cek juga baris lengkap di bawah)\n")
            for (b in cocok) sb.append(b).append('\n')
            sb.append("\n=== Logcat lengkap (").append(baris.size).append(" baris terakhir) ===\n")
            sb.append(isi)
            os.write(sb.toString().toByteArray())
            os.flush()
            os.close()
            log("Dump logcat $label disimpan ke Download/AutoUpLvl/$namaBerkas (${cocok.size} baris mencurigakan ditemukan)")
        } catch (e: Throwable) {
            log("Dump logcat $label error: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    // Jadwalkan beberapa dump sesudah "Mulai Game" diketuk, untuk menangkap momen game menimpa nilai Quick Mode
    // (komentar lama: 9576 jadi 0, biasanya <150 ms sesudah tap). Jalan di thread sendiri, tidak memblokir Engine.
    fun jadwalkanDumpSesudahMulai() {
        Thread({
            try {
                tidur(150L); dumpQuickArea("150ms"); dumpLbmArea("150ms")
                tidur(150L); dumpQuickArea("300ms"); dumpLbmArea("300ms")
                tidur(700L); dumpQuickArea("1000ms"); dumpLbmArea("1000ms")
                tidur(2000L); dumpQuickArea("3000ms"); dumpLbmArea("3000ms")
            } catch (_: Throwable) {}
        }, "dump-quick").apply { isDaemon = true }.start()
    }

    private var lastState = ""
    // Timestamp transisi state terakhir, untuk log timing
    @Volatile var stateChangedAt = 0L
    // Timestamp tiap status penting, untuk analisis durasi tiap fase
    @Volatile var tsPlay = 0L
    @Volatile var tsWaitEnd = 0L
    @Volatile var tsEnd = 0L
    @Volatile var tcpKlaimTerkirim = false  // flag: TCP klaim sudah dikirim saat End
    private var lastBekuMs = 0L
    private var lastShieldMs = 0L
    private var lastSceneCari = 0L
    private var antiResTerpasang = false
    private var latestSd = 0L

    // tabel nilai KDA / Stat (indeks 0..3 untuk KDA: kill, death, assist, gold; 0..6 untuk Stat)
    private var tSelfKda: Array<Int?> = arrayOfNulls(4)
    private var tTeamKda = ArrayList<Array<Int?>>()
    private var tEnemyKda = ArrayList<Array<Int?>>()
    private var tSelfStat: Array<Int?> = arrayOfNulls(7)
    private var tTeamStat = ArrayList<Array<Int?>>()
    private var tEnemyStat = ArrayList<Array<Int?>>()

    // Mode kilat Quick Mode: dari saat Mulai Game diketuk, game menimpa nilai (9576 jadi 0). Penulisan ulang harus
    // secepat mungkin (log: <100 ms = tanpa select hero, >110 ms = select hero), jadi putaran dipercepat sementara.
    @Volatile private var tapMulaiAt = 0L
    @Volatile private var kilatSampai = 0L
    fun kilatQuick(ms: Long) {
        tapMulaiAt = System.currentTimeMillis()
        kilatSampai = tapMulaiAt + ms
    }
    private fun kilat(): Boolean = System.currentTimeMillis() < kilatSampai

    private fun tidur(ms: Long) {
        if (ms <= 0) return
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    // ═══════════ Penulisan dengan verifikasi ═══════════
    private fun m(): Mem = mem!!

    private fun flush(label: String) {
        val mm = mem ?: return
        if (!mm.adaAntrean) return
        if (verifSisa > 0) {
            val r = mm.siramDanCek(6)
            when {
                r == null -> {
                    log("$label: perintah tulis ke shell gagal")
                    verifSisa--
                }
                r.second == 0 -> log("$label: ditulis, tidak ada yang bisa dibaca ulang untuk dicek")
                r.first > 0 -> {
                    log("$label: tulis memori OK (${r.first} dari ${r.second} alamat terbaca sama)")
                    tulisTerbukti = true
                    verifSisa = 0
                }
                else -> {
                    log("$label: tulis TIDAK masuk (0 dari ${r.second} alamat berubah)")
                    verifSisa--
                }
            }
            if (verifSisa == 0 && tulisTerbukti != true) {
                tulisTerbukti = false
                log("TULIS KE MEMORI GAME TIDAK BERHASIL. Cek: Shizuku aktif, apk game (Clone up lvl) debuggable, SELinux menolak tulis ke /proc/pid/mem.")
            }
        } else {
            if (mm.siram() == null) log("$label: perintah tulis gagal")
        }
    }


    // Uji tulis: balik satu field di SystemData, baca ulang seketika, lalu kembalikan.
    // Kalau dd tidak berhasil, dicoba cara lain lewat scanner (pwrite / process_vm_writev / ptrace) dan hasil tiap cara dicatat.
    private fun ujiTulis(label: String) {
        val s = sas ?: return
        val mm = mem ?: return
        val sh = mm.sh
        val a = s.sdStatis + 2036          // m_iQuickMatchMaxRankIdInRank (4 byte)
        val asli = mm.blok(a, 4)
        if (asli == null) { log("$label: gagal membaca field uji"); return }
        val baru = asli.copyOf(); baru[0] = (baru[0].toInt() xor 1).toByte()
        fun hx(b: ByteArray): String { val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x.toInt() and 0xFF)); return sb.toString() }
        val tulisanSemula = sh.metodeTulis
        sh.metodeTulis = null
        val out = sh.diagDd(mm.pid, a, baru)
        sh.tulis(mm.pid, listOf(Pair(a, asli)))
        if (out == null) { log("$label: shell tidak menjawab (timeout)"); sh.metodeTulis = tulisanSemula; return }
        var baca = ""
        for (ln in out.lines()) {
            if (ln.isBlank()) continue
            if (ln.startsWith("baca:")) baca = ln.removePrefix("baca:").replace(" ", "").trim()
            log("$label │ $ln")
        }
        if (baca == hx(baru)) {
            log("$label: TULIS MEMORI TERBUKTI lewat dd (terbaca langsung sama dengan yang ditulis)")
            tulisTerbukti = true
            return
        }
        log("$label: dd: terbaca '$baca', ditulis '${hx(baru)}'. Mencoba cara lain lewat scanner…")
        val hasil = sh.jalankan("${sh.helperPath} ${mm.pid} wtest ${java.lang.Long.toHexString(a)} ${hx(baru)}", 15000)
        if (hasil == null) { log("$label: scanner tidak menjawab"); sh.metodeTulis = tulisanSemula; return }
        var pilih: String? = null
        var timpa: String? = null
        for (ln in hasil.lines()) {
            if (ln.isBlank()) continue
            log("$label │ $ln")
            val t = ln.trim()
            if (pilih == null && t.startsWith("OK ")) pilih = t.removePrefix("OK ").trim()
            if (timpa == null && t.startsWith("TIMPA ")) timpa = t.removePrefix("TIMPA ").substringBefore(' ')
        }
        sh.tulis(mm.pid, listOf(Pair(a, asli)))
        if (pilih != null) {
            sh.metodeTulis = pilih
            log("$label: cara tulis dipakai: $pilih")
            tulisTerbukti = true
        } else if (timpa != null) {
            sh.metodeTulis = timpa
            log("$label: tulis tidak ditolak, tetapi game menimpa field ini dengan cepat. Cara dipakai: $timpa")
            tulisTerbukti = true
        } else {
            sh.metodeTulis = tulisanSemula
            log("$label: SEMUA cara tulis gagal. Lihat pesan error di atas.")
            tulisTerbukti = false
        }
    }

    private fun kirimOps(l: List<Op>) {
        val mm = mem ?: return
        if (l.isEmpty()) return
        val p = ArrayList<Pair<Long, ByteArray>>(l.size)
        for (o in l) p.add(Pair(o.a, o.b))
        mm.sh.tulis(mm.pid, p)
    }

    private fun op1(l: MutableList<Op>, a: Long, v: Int) { l.add(Op(a, Mem.by1(v))) }
    private fun op4(l: MutableList<Op>, a: Long, v: Int) { l.add(Op(a, Mem.by4(v))) }
    private fun op8(l: MutableList<Op>, a: Long, v: Long) { l.add(Op(a, Mem.by8(v))) }
    private fun opF(l: MutableList<Op>, a: Long, v: Float) { l.add(Op(a, Mem.byF(v))) }

    // ═══════════ Loop utama ═══════════
    private fun utama() {
        log("Mesin skrip dimulai")
        var galatBeruntun = 0
        while (aktif) {
            try {
                if (!siapkanTarget()) {
                    tidur(1500)
                    continue
                }
                tick()
                galatBeruntun = 0
                tidur(if (kilat()) 3 else 60)
            } catch (e: InterruptedException) {
                break
            } catch (e: Throwable) {
                galatBeruntun++
                log("Galat putaran: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                if (galatBeruntun >= 3) {
                    sas = null
                    mem = null
                    galatBeruntun = 0
                }
                tidur(1000)
            }
        }
        try {
            sh?.tutup()
        } catch (e: Throwable) {
        }
        sh = null
        mem = null
        sas = null
        statusTeks = "Mati"
        log("Mesin skrip berhenti")
    }

    private fun siapkanTarget(): Boolean {
        val mm = mem
        if (mm != null && sas != null) {
            if (mm.gagalBaca >= 6) {
                log("Game tidak terbaca lagi, mencari ulang")
                resetSesi()
                return false
            }
            return true
        }
        val now = System.currentTimeMillis()
        if (now - terakhirCari < 4000) return false
        terakhirCari = now
        if (!ShizukuHelper.isRunning()) {
            statusTeks = "Shizuku belum aktif"
            return false
        }
        if (!ShizukuHelper.hasPermission()) {
            statusTeks = "Izin Shizuku belum diberikan"
            ShizukuHelper.requestPermission()
            return false
        }
        val pk = Prefs.pkg
        var s = sh
        if (s == null || !s.hidup) {
            s = GameShell(pk)
            if (!s.buka()) {
                statusTeks = "Shell run-as gagal"
                sh = null
                return false
            }
            sh = s
        }
        statusTeks = "Mencari data game"
        val ctx = ctxApp ?: return false
        Pencari.siapkanScanner(ctx, pk) { log(it) }
        val t = Pencari.cari(pk, s) { log(it) }
        if (t == null) {
            statusTeks = "Menunggu game"
            return false
        }
        sas = t
        mem = Mem(s, t.pid)
        s.helperPath = Pencari.pathScanner
        s.metodeTulis = null
        log(if (s.bukaNativo()) "Pembaca memori native aktif (cepat)" else "Pembaca memori native gagal dibuka, pakai dd (lambat)")
        log("Terhubung: " + t.ringkas)
        statusTeks = "Terhubung"
        resetSesi(false)
        ujiAwalSelesai = false
        quickDiuji = false
        quickLogN = 0
        return true
    }

    private fun resetSesi(buangTarget: Boolean = true) {
        if (buangTarget) {
            sas = null
            mem = null
            try {
                sh?.tutup()
            } catch (e: Throwable) {
            }
            sh = null
        }
        siapMain = false
        lbm = 0L
        scene = 0L
        isApply = true
        isNeedRestore = false
        isExecute = false
        isChangeStat = true
        dodTerpasang = false
        antiResTerpasang = false
        holdStopMinion = ArrayList()
        updateShield = ArrayList()
        antiRes = ArrayList()
        quickAsli = null
        quickTulis = ArrayList()
        mem?.lepasSemuaBeku()
        bersihkanMatch()
    }

    private fun bersihkanMatch() {
        teamP = ArrayList(); enemyP = ArrayList(); teamM = ArrayList(); enemyM = ArrayList()
        holdFirstBlood = false
        lfd = 0L
        enemySoldier = LinkedHashSet()
        midTowerScript = emptyList()
        isBrawlTP = false
        isCancelTeleport = false
        autoEndLihat = 0L; autoEndMulai = 0L; autoEndTulis = null
        percobaanEntity = 0
    }

    // ═══════════ Waktu game ═══════════
    private fun waktuRaw(): Int = m().d(lbm + O_FRAME)

    // getCurrentTime(true): dibatasi 60000..1200000
    private fun waktuKlem(): Int {
        val w = waktuRaw()
        return if (w > 1200000) 1200000 else if (w < 60000) 60000 else w
    }

    private fun skala(nilai: Int): Int = Math.floor(waktuKlem().toDouble() / 60000.0 * nilai).toInt()

    private fun setTime(paksa: Boolean, nilai: Int) {
        if (paksa) {
            m().t32(lbm + O_FRAME, nilai)
            flush("Waktu")
            return
        }
        val st = C.i("setTime") ?: return
        if (waktuKlem() < st * 60000) {
            m().t32(lbm + O_FRAME, st * 60000)
            flush("Waktu")
        }
    }

    // ═══════════ Entitas ═══════════
    private fun entriKamus(off: Int, berhentiDiNol: Boolean): List<Long> {
        val mm = m()
        val dic = mm.p(lbm + off)
        if (dic == 0L) return emptyList()
        val b = mm.p(dic + 24)
        if (b == 0L) return emptyList()
        val blok = mm.blok(b + 0x30, 0x12c0 - 0x30 + 8) ?: return emptyList()
        val h = ArrayList<Long>()
        var r = 0
        while (r <= 0x12c0 - 0x30) {
            val v = Daftar.le(blok, r, 8)
            r += 0x18
            if (v == 0L) {
                if (berhentiDiNol) break
                continue
            }
            h.add(v)
        }
        return h
    }

    private fun campSaya(): Int {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        return mm.d(diri + O_CAMP)
    }

    // callEntity
    private fun callEntity() {
        val mm = m()
        teamP = ArrayList(); enemyP = ArrayList(); teamM = ArrayList(); enemyM = ArrayList()
        val pemain = ArrayList<Long>()
        for (p in entriKamus(O_DIC_PLAYER, true)) {
            val b = mm.blok(p + 432, 64) ?: continue   // mencakup bSelf (440) dan camp (484)
            if ((b[440 - 432].toInt() and 0xFF) == 1) continue
            pemain.add(p)
        }
        userCamp = campSaya()
        for (p in pemain) {
            val camp = mm.d(p + O_CAMP)
            if (camp == userCamp) teamP.add(p) else enemyP.add(p)
        }
        for (a in entriKamus(O_DIC_MON, false)) {
            val b = mm.blok(a, M_BLOK) ?: continue
            val tipe = Daftar.le(b, M_TYPE, 4).toInt()
            var b59 = b[0x59].toInt() and 0xFF
            if (tipe == 2) {
                mm.t8(a + 0x59, 1)
                b59 = 1
            }
            val camp = Daftar.le(b, O_CAMP, 4).toInt()
            val mon = Mon(a, camp, tipe, b59, b[0x72].toInt() and 0xFF, Daftar.le(b, M_GUARD, 4).toInt())
            if (camp == userCamp) teamM.add(mon) else enemyM.add(mon)
        }
        flush("Tandai tower")
        if (teamP.isEmpty() || enemyP.isEmpty() || enemyM.isEmpty() || teamM.isEmpty()) {
            val jumlah = mm.d(lbm + O_REALCOUNT)
            if (jumlah > 1 && percobaanEntity != 4) {
                percobaanEntity++
                tidur(200)
                callEntity()
                return
            }
        }
        log("Entitas: tim ${teamP.size} pemain/${teamM.size} monster, musuh ${enemyP.size} pemain/${enemyM.size} monster")
    }

    // swapPlayerData
    private fun swapPlayerData() {
        val a = ArrayList<Long>(teamP)
        a.add(m().p(lbm + O_SELF))
        val b = ArrayList<Long>(enemyP)
        teamP = b
        enemyP = a
    }

    // ═══════════ Atribut ═══════════
    private fun logicAttribute() {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        val attr = mm.p(diri + O_ATTRCOMP)
        val dict = mm.p(attr + 56)
        var a = mm.p(mm.p(dict + 0x10) + 0x10)
        var cocok = false
        if (a > 0x60000000L) {
            val klas = mm.p(a)
            val nama = mm.teks(mm.p(klas + 0x10), 32)
            if (nama == "AttrIncrease[]") cocok = true
        }
        val b = mm.p(dict + 24)
        if (b == 0L) {
            log("Atribut: pointer atribut kosong")
            return
        }
        if (!cocok) a = 0L
        fun tulisA(offA: Int, offB: Int, v: Int) {
            mm.t32(b + offA, v)
            if (cocok) mm.t32(a + offB, v)
        }
        C.i("attribute.health")?.let { tulisA(312, 248, it) }
        if (C.b("attribute.godMode")) mm.t8(diri + O_CANTHURT, 1)
        C.i("attribute.movSpeed")?.let { tulisA(48, 36, it) }
        C.i("attribute.damage")?.let { d ->
            mm.t32(b + 92, d)
            mm.t32(b + 144, d)
            mm.t32(b + 148, d)
            if (cocok) {
                mm.t32(a + 68, d)
                mm.t32(a + 108, d)
            }
        }
        if (C.b("attribute.attSpeed")) tulisA(180, 140, 30000)
        tulisA(576, 440, 99999)
        mm.t32(b + 684, 99999)
        mm.t32(b + 688, 99999)
        flush("Atribut")
    }

    // ═══════════ Anti AFK ═══════════
    private fun setAntiAfk() {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        val semua = ArrayList<Long>()
        semua.add(diri)
        semua.addAll(teamP)
        for (p in semua) {
            for (j in 1..3) mm.beku32(p + O_WAITAI + (4 * j - 1), 214000000)
            val v0 = mm.p(p + O_OPMON)
            if (v0 == 0L) continue
            val v1 = mm.p(v0 + 0x18)
            if (v1 == 0L) continue
            val v2 = mm.p(v1 + 0x18)
            if (v2 == 0L) continue
            var j = 0x20
            while (j <= 0x48) {
                mm.beku32(v2 + j, -1)
                j += 8
            }
        }
        mm.tickBeku()
        lastBekuMs = System.currentTimeMillis()
        log("Anti AFK aktif untuk ${semua.size} pemain")
    }

    // ═══════════ Tower ═══════════
    private fun attrObj(entitas: Long): Long {
        val mm = m()
        val komp = mm.p(entitas + O_ATTRCOMP)
        if (komp == 0L) return 0L
        val dict = mm.p(komp + 56)
        if (dict == 0L) return 0L
        return mm.p(dict + 24)
    }

    // setHealthTower
    private fun setHealthTower(kalah: Boolean) {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        val camp = mm.d(diri + O_CAMP)
        val menara: Int
        if (camp == 1 || camp == 0) {
            menara = if (kalah) O_MAIN_A else O_MAIN_B
        } else if (camp == 2) {
            menara = if (kalah) O_MAIN_B else O_MAIN_A
        } else {
            log("Camp tidak terdeteksi")
            return
        }
        val daftarA = ArrayList<Long>()
        val daftarB = ArrayList<Long>()
        val daftarC = ArrayList<Long>()
        daftarC.add(mm.p(lbm + menara))
        val sumber = if (kalah) teamM else enemyM
        for (e in sumber) {
            val x = e.b59
            val y = e.b72
            val g = e.guard
            if (x == 1 && (g == -16777210 || g == -16777209 || g == -16777211 || g == -16777199 || g == -16777200 || g == -16777201)) {
                daftarB.add(e.a)
            } else if (x == 1 && y != 1) {
                daftarA.add(e.a)
            }
        }
        for (e in daftarB) {
            val c = attrObj(e)
            if (c == 0L) continue
            mm.t32(c + 200, 1); mm.t32(c + 204, 1); mm.t32(c + 684, 1); mm.t32(c + 688, 1)
            op4(updateShield, c + 0x280, 1); op4(updateShield, c + 0x284, 1)
            op4(updateShield, c + 684, 1); op4(updateShield, c + 688, 1)
        }
        for (e in daftarA) {
            val c = attrObj(e)
            if (c == 0L) continue
            mm.t32(c + 200, 1); mm.t32(c + 204, 1)
        }
        for (e in daftarC) {
            if (e == 0L) continue
            val c = attrObj(e)
            if (c == 0L) continue
            op4(updateShield, c + 200, 1); op4(updateShield, c + 204, 1)
        }
        flush("HP tower")
        log("Tower: ${daftarB.size} luar, ${daftarA.size} lain, ${daftarC.size} utama diset HP 1")
    }

    // ═══════════ KDA / Statistik ═══════════
    private fun acak(p: String): Int? {
        val r = C.r(p) ?: return null
        return if (r[0] > r[1]) r[0] else Random.nextInt(r[0], r[1] + 1)
    }

    private fun tabelKda(nama: String, rv: String): Array<Int?> {
        val t = arrayOfNulls<Int>(4)
        if (C.b("$nama.random")) {
            t[0] = acak("$rv.kill"); t[1] = acak("$rv.death"); t[2] = acak("$rv.assist"); t[3] = acak("$rv.gold")
        } else {
            t[0] = C.i("$nama.kill"); t[1] = C.i("$nama.death"); t[2] = C.i("$nama.assist"); t[3] = C.i("$nama.gold")
        }
        return t
    }

    private fun tabelStat(nama: String, rv: String): Array<Int?> {
        val t = arrayOfNulls<Int>(7)
        val k = arrayOf("dmgDealt", "towerDmg", "dmgRec", "dKill", "tKill", "maniac", "savage")
        for (i in 0..6) t[i] = if (C.b("$nama.random")) acak("$rv.${k[i]}") else C.i("$nama.${k[i]}")
        return t
    }

    // setAllValue
    private fun setAllValue() {
        tSelfKda = tabelKda("selfKda", "selfRandomValue")
        tTeamKda = ArrayList(); tEnemyKda = ArrayList()
        tTeamStat = ArrayList(); tEnemyStat = ArrayList()
        for (i in 1..5) {
            tTeamKda.add(tabelKda("teamKda", "teamRandomValue"))
            tEnemyKda.add(tabelKda("enemyKda", "enemyRandomValue"))
            tTeamStat.add(tabelStat("teamStat", "teamRandomValue"))
            tEnemyStat.add(tabelStat("enemyStat", "enemyRandomValue"))
        }
        tSelfStat = tabelStat("selfStat", "selfRandomValue")
    }

    private fun tulisKda(data: Long, pemain: Long, t: Array<Int?>, maxLevel: Boolean) {
        val mm = m()
        if (data == 0L) return
        if (maxLevel) {
            mm.t32(data + D_LEVELMAX, 15)
            mm.t32(data + D_EXP, 99999)
        }
        t[0]?.let { mm.t32(data + D_KILL, it) }
        t[1]?.let { mm.t32(data + D_DEAD, it) }
        t[2]?.let { mm.t32(data + D_ASSIST, it) }
        t[3]?.let {
            val g = skala(it)
            mm.t32(data + D_GOLD, g)
            mm.t32(pemain + O_TOTALGOLD, g)
        }
    }

    private fun logicSelfKDA() {
        val diri = m().p(lbm + O_SELF)
        tulisKda(m().p(diri + O_PLAYERDATA), diri, tSelfKda, C.b("selfKda.maxLevel"))
        flush("KDA diri")
    }

    private fun logicTeamKDA() {
        if (teamP.isEmpty()) return
        val random = C.b("teamKda.random")
        for ((i, p) in teamP.withIndex()) {
            val t = if (random) tTeamKda[minOf(i, tTeamKda.size - 1)] else tTeamKda[0]
            tulisKda(m().p(p + O_PLAYERDATA), p, t, C.b("teamKda.maxLevel"))
        }
        flush("KDA tim")
    }

    private fun logicEnemyKDA() {
        if (enemyP.isEmpty()) return
        val random = C.b("enemyKda.random")
        for ((i, p) in enemyP.withIndex()) {
            val t = if (random) tEnemyKda[minOf(i, tEnemyKda.size - 1)] else tEnemyKda[0]
            tulisKda(m().p(p + O_PLAYERDATA), p, t, C.b("enemyKda.maxLevel"))
        }
        flush("KDA musuh")
    }

    // Statistik: dmgDealt dan dmgRec(diri) dikali menit game, towerDmg mentah, nilai float
    private fun tulisStat(p: Long, t: Array<Int?>, legendary: Boolean, skalaRec: Boolean) {
        val mm = m()
        t[0]?.let { mm.tf(p + O_HURTHERO, skala(it).toFloat()) }
        t[1]?.let { mm.tf(p + O_HURTTOWER, it.toFloat()) }
        t[2]?.let { mm.tf(p + O_INJURED, (if (skalaRec) skala(it) else it).toFloat()) }
        t[3]?.let { mm.t32(p + O_DOUBLE, it) }
        t[4]?.let { mm.t32(p + O_TRIPLE, it) }
        t[5]?.let { mm.t32(p + O_QUADRA, it) }
        t[6]?.let { mm.t32(p + O_PENTA, it) }
        if (legendary) mm.beku32(p + O_MAXCONT, 8)
    }

    private fun logicSelfStat() {
        val diri = m().p(lbm + O_SELF)
        tulisStat(diri, tSelfStat, C.b("selfStat.legendary"), true)
        flush("Statistik diri")
    }

    private fun logicTeamStat() {
        if (teamP.isEmpty()) return
        val random = C.b("teamStat.random")
        for ((i, p) in teamP.withIndex()) {
            val t = if (random) tTeamStat[minOf(i, tTeamStat.size - 1)] else tTeamStat[0]
            tulisStat(p, t, C.b("teamStat.legendary"), false)
        }
        flush("Statistik tim")
    }

    private fun logicEnemyStat() {
        if (enemyP.isEmpty()) return
        val random = C.b("enemyStat.random")
        for ((i, p) in enemyP.withIndex()) {
            val t = if (random) tEnemyStat[minOf(i, tEnemyStat.size - 1)] else tEnemyStat[0]
            tulisStat(p, t, C.b("enemyStat.legendary"), false)
        }
        flush("Statistik musuh")
    }

    // setInvalid: Penta kill dibekukan -10 (Hilangkan History)
    private fun setInvalid() {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        mm.beku32(diri + O_PENTA, -10)
        for (p in teamP) mm.beku32(p + O_PENTA, -10)
        for (p in enemyP) mm.beku32(p + O_PENTA, -10)
        mm.tickBeku()
    }

    // ═══════════ Stop Minion ═══════════
    private fun cariScene(): Long {
        val s = sas ?: return 0L
        if (s.sceneGlobal == 0L) return 0L
        return m().p(s.sceneGlobal)
    }

    private fun stopMinion(henti: Boolean): Boolean {
        var tunggu = 0
        while (scene == 0L && tunggu < 20 && aktif) {
            scene = cariScene()
            if (scene != 0L) break
            tidur(500)
            tunggu++
        }
        if (scene == 0L) {
            log("Stop Minion: LogicBattleScene tidak ditemukan")
            return false
        }
        val mm = m()
        val a = mm.p(scene + 0x20)
        val b = mm.p(a) + 0xa8
        val c = mm.p(b) + 0x8
        if (c <= 8L) {
            log("Stop Minion: pointer kosong")
            return false
        }
        val nilai = if (henti) 0 else 1
        mm.beku8(c, nilai)
        mm.t8(c, nilai)
        flush("Stop Minion")
        holdStopMinion.add(Op(c, Mem.by1(nilai)))
        return true
    }

    // ═══════════ Pemain asli / bot ═══════════
    private class Kamar(val camp: Int, val pos: Int, val uid: Long, val robot: Int, val a: Long)

    private fun dataKamar(): List<Kamar>? {
        val mm = m()
        val s = sas ?: return null
        val a = mm.p(s.sdStatis + S_ROOM)
        if (a == 0L) return null
        val v = mm.p(a + 0x18)
        if (v == 0L) return null
        val c = mm.p(v + 0x30)
        if (c == 0L) return null
        val banyak = mm.d(c + 0x18)
        val isi = mm.p(c + 0x10)
        if (banyak <= 0 || banyak > 20 || isi == 0L) return null
        val h = ArrayList<Kamar>()
        for (i in 0 until banyak) {
            val p = mm.p(isi + 0x20 + 8L * i)
            if (p == 0L) continue
            val b = mm.blok(p + 32, 48) ?: continue
            h.add(Kamar(Daftar.le(b, 48 - 32, 4).toInt(), Daftar.le(b, 52 - 32, 4).toInt(), Daftar.le(b, 0, 8), b[72 - 32].toInt() and 0xFF, p))
        }
        return h
    }

    // checkPlayerIsOnline: daftar teks pemain asli yang sedang online
    private fun pemainOnline(): List<String> {
        val mm = m()
        val hasil = ArrayList<String>()
        if (mm.d(lbm + O_REALCOUNT) == 1) return hasil
        val kamar = dataKamar() ?: return hasil
        val bot = HashMap<Long, Int>()
        for (k in kamar) bot[k.uid] = k.robot
        fun cek(daftar: List<Long>, label: String) {
            for (p in daftar) {
                if (mm.r8(p + O_CONNECTED) == 1) {
                    val uid = mm.p(p + O_ACID)
                    if (bot[uid] == 0) hasil.add(Pahlawan.nama(mm.d(p + O_ID)) + " ( $label ) Is Online")
                }
            }
        }
        cek(teamP, "Team")
        cek(enemyP, "Enemy")
        return hasil
    }

    // CheckHuman: hasilnya ditulis ke log (di skrip berupa gg.alert)
    private fun cekHuman() {
        val mm = m()
        val s = sas ?: return
        val level = mm.d(s.sdStatis + S_LEVEL)
        // CATATAN: kalau fitur "Set Level" sedang Aktifkan, nilai di +696 ini SELALU sama dengan
        // target yang diisi user (mis. 999) karena loop Set Level nulis ulang tiap tick — jadi baca
        // balik di sini TIDAK bisa dipakai buat nebak apakah offset S_LEVEL masih benar atau tidak
        // (write lalu baca alamat yang sama pasti cocok, apapun offsetnya). Peringatan basi/geser
        // cuma masuk akal kalau Set Level sedang MATI, supaya nilai yang kebaca murni dari game.
        if (level > 200 && !C.b("isSetLevel")) {
            log("Cek Human: level akun kebaca $level (gak masuk akal) — kemungkinan offset S_LEVEL (+696) sudah basi gara-gara update game, bukan akun beneran level segitu. Hasil Cek Human di bawah ini jangan dipercaya dulu.")
        }
        if (level <= 6) {
            log("Cek Human: Semua adalah Bot (level akun $level)")
            return
        }
        val data = dataKamar()
        if (data == null) {
            log("Cek Human: data kamar belum ada (Start MatchMaking dulu)")
            return
        }
        val defineAcc = mm.d(s.sdStatis + S_UID).toLong() and 0xFFFFFFFFL
        var kampSaya = 0
        val hitung = arrayOf(HashMap<Int, String>(), HashMap<Int, String>())
        for (k in data) {
            if ((k.uid and 0xFFFFFFFFL) == defineAcc) {
                kampSaya = k.camp
            } else if (k.camp in 1..2) {
                val pos = if (k.pos > 5) k.pos - 5 else k.pos
                hitung[k.camp - 1][pos] = if (k.robot == 1) "Bot" else if (k.robot == 0) "Human" else "Unknown"
            }
        }
        var tim = hitung[0].values.count { it == "Human" }
        var musuh = hitung[1].values.count { it == "Human" }
        if (kampSaya == 2) {
            val x = tim; tim = musuh; musuh = x
        }
        if (tim == 0 && musuh == 0) log("Cek Human: Semua adalah Bot. Team : 0 Enemy : 0")
        else log("Cek Human: Terdapat ${tim + musuh} Player Aktif. Team : $tim Enemy : $musuh")
    }

    // ═══════════ Teleport ═══════════
    private class Menara2(val a: Long, val x: Float, val y: Float)

    private fun daftarTowerMusuh(): Pair<List<Menara2>, Long> {
        val mm = m()
        if (enemyM.isEmpty()) callEntity()
        val diri = mm.p(lbm + O_SELF)
        val hasil = ArrayList<Menara2>()
        for (e in enemyM) {
            if (!e.menara) continue
            val b = mm.blok(e.a + O_POS, O_DELET - O_POS + 4) ?: continue
            val del = b[O_DELET - O_POS].toInt() and 0xFF
            if (del == 1) continue
            hasil.add(Menara2(e.a, Daftar.pecahan(b, 0), Daftar.pecahan(b, O_POSV - O_POS)))
        }
        return Pair(hasil, diri)
    }

    private fun repetTower() {
        val mm = m()
        val (daftar, diri) = daftarTowerMusuh()
        if (daftar.isEmpty()) {
            isCancelTeleport = true
            return
        }
        val hx = mm.rf(diri + O_POS) ?: return
        val hy = mm.rf(diri + O_POSV) ?: return
        if (C.b("towerRelocation")) {
            var target: Menara2? = null
            var jarakMin = 1e9f
            for (t in daftar) {
                val j = (t.x - hx) * (t.x - hx) + (t.y - hy) * (t.y - hy)
                if (j < jarakMin) {
                    jarakMin = j; target = t
                }
            }
            if (target != null) {
                val ph = mm.blok(diri + O_POS, O_DPY - O_POS + 4) ?: return
                mm.tf(target.a + O_POS, Daftar.pecahan(ph, 0))
                mm.tf(target.a + O_POSV, Daftar.pecahan(ph, O_POSV - O_POS))
                mm.tf(target.a + O_DPX, Daftar.pecahan(ph, O_DPX - O_POS))
                mm.tf(target.a + O_DPY, Daftar.pecahan(ph, O_DPY - O_POS))
                flush("Relokasi tower")
            }
            return
        }
        var tx = 0f
        var ty = 0f
        var ada = false
        for ((idx, c) in towerMid.withIndex()) {
            var berdiri = false
            for (t in daftar) {
                var terdekatIdx = -1
                var terdekatJ = 1e9f
                for ((j2, c2) in towerMid.withIndex()) {
                    val dx = t.x - c2[0]
                    val dy = t.y - c2[1]
                    val jj = dx * dx + dy * dy
                    if (jj < terdekatJ) {
                        terdekatJ = jj; terdekatIdx = j2
                    }
                }
                if (terdekatIdx == idx && terdekatJ < 0.25f) {
                    berdiri = true
                    break
                }
            }
            if (berdiri) {
                tx = c[0]; ty = c[1]; ada = true
                break
            }
        }
        if (!ada) {
            isCancelTeleport = true
            return
        }
        mm.tf(diri + O_POS, tx); mm.tf(diri + O_POSV, ty)
        mm.tf(diri + O_DPX, tx); mm.tf(diri + O_DPY, ty)
        mm.tf(diri + O_POS3, tx); mm.tf(diri + O_POS3V, ty)
        flush("Teleport tower")
    }

    private fun tryTeleportBasePhase1() {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        mm.tf(diri + O_POS, vecBasePhase1[0]); mm.tf(diri + O_POSV, vecBasePhase1[1])
        mm.tf(diri + O_DPX, vecBasePhase1[2]); mm.tf(diri + O_DPY, vecBasePhase1[3])
        mm.tf(diri + O_MOVEDIR, vecBasePhase1[4])
        flush("Teleportasi fase 1")
    }

    // Soldier (mode kalah)
    private fun teleSoldierScript(): List<Long> {
        val mm = m()
        val camp = campSaya()
        val posIdx: Array<FloatArray>
        val towerReal: Array<FloatArray>
        val brawlPos: Array<FloatArray>
        val brawlTp: Array<FloatArray>
        if (camp == 1) {
            brawlPos = towerABrawlIndexVec; brawlTp = playerTowerBrawlPosA; towerReal = towerAIndexVec
        } else if (camp == 2) {
            brawlPos = towerBBrawlIndexVec; brawlTp = playerTowerBrawlPosB; towerReal = towerBIndexVec
        } else {
            log("Teleport soldier: camp error")
            C.setBool("teleSoldier", false)
            return emptyList()
        }
        posIdx = if (camp == 1) playerTowerPosA else playerTowerPosB
        val kandidat = ArrayList<Long>()
        for (e in teamM) {
            if (e.b59 == 1 || e.b72 == 1) kandidat.add(e.a)
        }
        val hasil = HashMap<Int, Long>()
        for (a in kandidat) {
            val x = mm.rf(a + O_POS) ?: continue
            for (j in towerReal.indices) if (abs(x - towerReal[j][0]) < 1e-4f) hasil[j] = a
            for (j in brawlPos.indices) if (abs(x - brawlPos[j][0]) < 1e-4f) hasil[j] = a
        }
        isBrawlTP = false
        val urut = hasil.keys.sorted().map { hasil[it]!! }
        return if (hasil.size == 4) {
            urut
        } else if (hasil.size == 3) {
            isBrawlTP = true
            urut
        } else emptyList()
    }

    private fun repetSoldier() {
        val mm = m()
        if (midTowerScript.isEmpty()) {
            midTowerScript = teleSoldierScript()
            if (midTowerScript.isEmpty()) {
                C.setBool("teleSoldier", false)
                log("Teleport soldier gagal")
                return
            }
        }
        val camp = campSaya()
        val vec: Array<FloatArray> = if (isBrawlTP) {
            if (camp == 1) playerTowerBrawlPosA else playerTowerBrawlPosB
        } else {
            if (camp == 1) playerTowerPosA else playerTowerPosB
        }
        for ((k, t) in midTowerScript.withIndex()) {
            val del = mm.r8(t + O_DELET) ?: 0
            if (del != 1) {
                val v = vec[minOf(k, vec.size - 1)]
                for (s in enemySoldier) {
                    mm.tf(s + O_POS, v[0]); mm.tf(s + O_POSV, v[1])
                    mm.tf(s + O_DPX, v[2]); mm.tf(s + O_DPY, v[3]); mm.tf(s + O_MOVEDIR, v[4])
                }
                flush("Teleport soldier")
                return
            }
        }
    }

    // ═══════════ Mode kalah: soldier ═══════════
    private fun soldierMode() {
        val mm = m()
        val a = mm.p(lbm + O_SOLDIER) + 0x10
        val b = mm.p(a) + 0x20
        val blok = mm.blok(b, 4008) ?: return
        userCamp = campSaya()
        var r = 0
        while (r <= 4000) {
            val v = Daftar.le(blok, r, 8)
            r += 8
            if (v > 0x600000000L) {
                val camp = mm.d(v + O_CAMP)
                if (camp == userCamp) {
                    mm.tf(v + O_POS, 129.8125f); mm.tf(v + O_POSV, -121.65625f)
                    mm.tf(v + O_DPX, 129.8125f); mm.tf(v + O_DPY, -121.65625f)
                    mm.tf(v + O_MOVEDIR, 0.75f); mm.t8(v + O_DELET, 1)
                } else {
                    if (C.b("godMinion")) mm.t8(v + O_CANTHURT, 1)
                    if (C.b("teleSoldier")) enemySoldier.add(v)
                }
            } else break
        }
        flush("Soldier")
    }

    // ═══════════ Auto End ═══════════
    private fun siapkanAutoEnd(): ArrayList<Op>? {
        val mm = m()
        if (enemyM.isEmpty()) return null
        val diri = mm.p(lbm + O_SELF)
        if (diri == 0L) return null
        val campKu = mm.d(diri + O_CAMP)
        val l = ArrayList<Op>()
        for (e in enemyM) {
            if (e.b59 == 1 && e.camp != campKu) {
                op4(l, e.a + 172, 0)
                op4(l, e.a + 492, 0)
            }
        }
        return if (l.isEmpty()) null else l
    }

    // ═══════════ Quick Mode ═══════════
    private fun siapkanQuickMode(): Boolean {
        val mm = m()
        val s = sas ?: return false
        val sd = s.sdStatis
        // (offset, lebar, nilai)
        val rancangan = arrayOf(
            intArrayOf(514, 1, 1), intArrayOf(516, 1, 1), intArrayOf(2036, 4, 0),
            intArrayOf(4953, 1, 1), intArrayOf(9584, 1, 1), intArrayOf(7688, 1, 1)
        )
        val asli = ArrayList<Op>()
        for (r in rancangan) {
            val v = if (r[1] == 1) mm.r8(sd + r[0]) else mm.r32(sd + r[0])
            if (v == null) return false
            if (r[1] == 1 && v != 0 && v != 1) {
                log("Quick Mode dibatalkan: field offset ${r[0]} berisi $v (harusnya 0 atau 1). Offset tidak cocok dengan versi game.")
                return false
            }
            if (r[1] == 1) op1(asli, sd + r[0], v) else op4(asli, sd + r[0], v)
        }
        if (quickAsli == null) quickAsli = asli
        val t = ArrayList<Op>()
        for (r in rancangan) if (r[1] == 1) op1(t, sd + r[0], r[2]) else op4(t, sd + r[0], r[2])
        quickTulis = t
        return true
    }

    private fun quickModeBolehTulis(statusNyata: String): Boolean {
        if (quickTulis.isEmpty()) return false
        if (statusNyata != "Unknown" && statusNyata != "End") return false
        val mm = m()
        for (o in quickTulis) {
            val now = mm.blok(o.a, o.b.size) ?: return true
            if (!now.contentEquals(o.b)) return true
        }
        return false
    }

    // ═══════════ DOD ═══════════
    private fun pasangDod(): Boolean {
        val mm = m()
        val s = sas ?: return false
        val pesan = mm.p(s.sdStatis + S_MSG) + S_HANDLER
        val handler = mm.p(pesan)
        if (handler == 0L) {
            log("DOD: handler belum ada (buka game sampai menu utama)")
            return false
        }
        mm.beku64(handler + S_HANDLER_FIELD, 0L)
        mm.tickBeku()
        log("DOD aktif")
        return true
    }

    // ═══════════ Stop Download Res ═══════════
    private fun pasangAntiRes(): Boolean {
        val mm = m()
        val s = sas ?: return false
        val kelas = Pencari.kelasHint(mm.sh, mm.pid, s.libBase, 0x649FF88L, "LoadResModuleMgr")
        if (kelas == null) {
            log("Stop Download Res: kelas LoadResModuleMgr tidak ditemukan")
            return false
        }
        val c = mm.p(kelas + 0xA8)
        if (c == 0L) return false
        mm.beku8(c + 241, 0)
        antiRes.add(Op(c + 241, Mem.by1(0)))
        mm.tickBeku()
        log("Stop Download Res aktif")
        return true
    }

    // ═══════════ Achievement / Epic Comeback (aksi manual) ═══════════
    private fun achievementUser(sinkronWaktu: Boolean, denganHero: Boolean) {
        val mm = m()
        if (sinkronWaktu) setTime(true, 540000)
        val diri = mm.p(lbm + O_SELF)
        achievementTulis(diri, denganHero)
    }

    private fun achievementTulis(p: Long, denganHero: Boolean) {
        val mm = m()
        if (denganHero) {
            mm.beku32(p + O_HURTHERO, 165000)
            mm.beku32(p + O_INJURED, 35000)
        }
        mm.beku32(p + O_WEEKKILL, 999)
        mm.beku32(p + O_TOTALGOLD, Math.floor(waktuKlem().toDouble() / 60000.0 * 1470).toInt())
        mm.beku32(p + O_KILLSHENGUI, 1500)
        mm.beku32(p + O_KILLLINGZHU, 1500)
        mm.beku32(p + O_KILLTOWER, 1500)
        mm.beku32(p + O_MAXCONT, 30)
    }

    private fun achievementSemua(tim: Boolean, musuh: Boolean, sinkronWaktu: Boolean, denganHero: Boolean) {
        if (sinkronWaktu) setTime(true, 540000)
        if (tim) for (p in teamP) achievementTulis(p, denganHero)
        if (musuh) for (p in enemyP) achievementTulis(p, denganHero)
    }

    private fun epicComeback() {
        val mm = m()
        if (scene == 0L) scene = cariScene()
        if (scene == 0L) {
            log("Inject Epic Comeback gagal: LogicBattleScene tidak ditemukan")
            return
        }
        val a = mm.p(scene + 0x30)
        mm.beku32(a + 520, 50)
        mm.tickBeku()
    }

    // ═══════════ Aksi manual dari Pengaturan ═══════════
    private fun prosesAksi(status: String) {
        while (true) {
            val a = aksi.poll() ?: break
            try {
                when (a) {
                    "terapkanSekarang" -> {
                        if (status == "Play") {
                            callEntity(); executeCore(); log("Diterapkan sekarang")
                        } else log("Terapkan sekarang: game belum di status Play ($status)")
                    }
                    "waktuSekarang" -> if (status == "Play") { setTime(false, 0); log("Waktu diterapkan sekarang") } else log("Terapkan waktu: game belum di status Play ($status)")
                    "fase1" -> if (status == "Play") tryTeleportBasePhase1() else log("Teleportasi fase 1: harus di status Play")
                    "cekHuman" -> cekHuman()
                    "epic" -> if (status == "Play") epicComeback() else log("Epic Comeback: harus di status Play")
                    "achSelf", "achSelfNoHero" -> if (status == "Play") achievementUser(false, a == "achSelf") else log("Achievement: harus di status Play")
                    "achTim" -> if (status == "Play") {
                        if (teamP.isEmpty()) callEntity(); achievementSemua(true, false, false, true)
                    }
                    "achMusuh" -> if (status == "Play") {
                        if (enemyP.isEmpty()) callEntity(); achievementSemua(false, true, false, true)
                    }
                    "setLevelSekarang" -> {
                        val s = sas
                        val lv = C.i("ucLevel")
                        if (s != null && lv != null) {
                            m().t32(s.sdStatis + S_LEVEL, lv); flush("Set level")
                        }
                    }
                    "diagnosa" -> {
                        val s = sas
                        if (s == null) {
                            log("Diagnosa: game belum terhubung ($statusTeks)")
                        } else {
                            log("── Diagnosa offset ──")
                            log("pid=${s.pid} lib=0x${java.lang.Long.toHexString(s.libBase)} sd=0x${java.lang.Long.toHexString(s.sdStatis)} lbmStatics=0x${java.lang.Long.toHexString(s.lbmGlobal)} scene=0x${java.lang.Long.toHexString(s.sceneGlobal)}")
                            log("Ringkas: ${s.ringkas}")
                            log("lbmOff=+0x${java.lang.Long.toHexString(lbmOff)} tervalidasi=$lbmOffTervalidasi")
                            log("Status game: $status | LBM=0x${java.lang.Long.toHexString(lbm)}")
                            if (lbm != 0L) {
                                log("eState=${m().d(lbm + O_STATE)} frame=${m().d(lbm + O_FRAME)} pemainNyata=${m().d(lbm + O_REALCOUNT)} self=0x${java.lang.Long.toHexString(m().p(lbm + O_SELF))}")
                            }
                            log("Tulis memori: " + when (tulisTerbukti) { true -> "terbukti masuk"; false -> "dicoba tapi tidak masuk"; null -> "belum dicoba" })
                            val setLevelOn = C.b("isSetLevel")
                            log("S_LEVEL(+696) raw=${m().d(s.sdStatis + S_LEVEL)}${if (setLevelOn) " (Set Level AKTIF - angka ini target yg diisi, BUKAN level asli dari game, matikan dulu buat cek offset)" else " (Set Level MATI, ini murni dari game - bandingkan ke level akun beneran yg keliatan di dalam game)"}")
                            log("── Selesai diagnosa ──")
                        }
                    }
                    "ujiTulis" -> ujiTulis("Uji tulis")
                    "dumpSd" -> {
                        if (sas == null) log("Dump offset: game belum terhubung")
                        else Thread({ dumpQuickArea("manual") }, "dump-quick-manual").apply { isDaemon = true }.start()
                    }
                    "dumpLbm" -> {
                        if (sas == null) log("Dump LBM: game belum terhubung")
                        else Thread({ dumpLbmArea("manual") }, "dump-lbm-manual").apply { isDaemon = true }.start()
                    }
                    "dumpLogcat" -> Thread({ dumpLogcat("manual") }, "dump-logcat-manual").apply { isDaemon = true }.start()
                    "dodUlang" -> dodTerpasang = false
                    "antiResUlang" -> antiResTerpasang = false
                    "quickMati" -> {
                        quickTulis = ArrayList()
                        quickAsli?.let { kirimOps(it) }
                        quickAsli = null
                        log("Quick Mode dikembalikan")
                    }
                }
            } catch (e: InterruptedException) {
                throw e
            } catch (e: Throwable) {
                log("Aksi $a gagal: ${e.message}")
            }
        }
    }

    // ═══════════ executeScript ═══════════
    // Satu fitur yang galat tidak boleh menghentikan fitur lain: galatnya dicatat lalu lanjut.
    private fun aman(nama: String, blok: () -> Unit) {
        val t0 = System.currentTimeMillis()
        try {
            blok()
            log("  ✓ $nama (${System.currentTimeMillis() - t0} ms)")
        } catch (e: InterruptedException) {
            throw e
        } catch (e: Throwable) {
            log("Fitur '$nama' galat: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    private fun executeScript() {
        val t0exec = System.currentTimeMillis()
        percobaanEntity = 0
        tidur((C.i("autoDelay") ?: 0).toLong())
        aman("Baca entitas") { callEntity() }
        if (C.b("checkPlayerOnline")) {
            var n = 0
            while (aktif) {
                val ol = pemainOnline()
                if (ol.isEmpty()) break
                log("Pemain asli online: " + ol.joinToString(", ") + " (menunggu)")
                tidur(4000)
                n++
                val st = STATUS.getOrNull(m().d(lbm + O_STATE)) ?: "Unknown"
                if (st != "Play" || n > 450) break
            }
        }
        val kalah = C.b("isIAmLose")
        if (C.b("isTeamStop") && kalah) {
            tidur((C.i("autoDelay") ?: 0).toLong())
            for (p in teamP) m().t8(p + O_DELET, 1)
            flush("Stop tim")
        }
        if (C.b("swapKdaStat") && kalah) swapPlayerData()
        if (kalah && C.b("autoSkipTime") && waktuRaw() < 10000) {
            setTime(true, 11220)
            tidur(2000)
        }
        executeCore()
    }

    // Bagian executeScript sesudah persiapan (juga dipakai "Terapkan Sekarang")
    private fun executeCore() {
        val kalah = C.b("isIAmLose")
        if (C.b("autoStopMinion")) {
            tidur(300)
            aman("Stop Minion") { stopMinion(true) }
        }
        tidur(20)
        aman("Anti AFK") { setAntiAfk() }
        if (C.b("autoSkipTime")) aman("Lompat Waktu") { setTime(false, 0) }
        if (C.b("attribute.autoAttr")) aman("Atribut") { logicAttribute() }
        if (C.b("cheatHealthTower")) aman("HP Tower") { setHealthTower(kalah) }
        if (tTeamKda.isEmpty()) aman("Nilai KDA/Statistik") { setAllValue() }
        if (C.b("selfKda.auto")) aman("KDA diri") { logicSelfKDA() }
        if (C.b("teamKda.auto")) aman("KDA tim") { logicTeamKDA() }
        if (C.b("enemyKda.auto")) aman("KDA musuh") { logicEnemyKDA() }
        if (C.b("selfStat.auto")) aman("Statistik diri") { logicSelfStat() }
        if (C.b("teamStat.auto")) aman("Statistik tim") { logicTeamStat() }
        if (C.b("enemyStat.auto")) aman("Statistik musuh") { logicEnemyStat() }
        aman("Tulis beku") { m().tickBeku() }
        if (C.b("autoInvalid")) aman("Invalid") { setInvalid() }
        aman("Scene") { if (scene == 0L) scene = cariScene() }
        if (scene != 0L && C.b("autoFirstBlood")) aman("First Blood") { pasangFirstBlood() }
        isApply = false
        isNeedRestore = true
        log("Selesai menerapkan fitur skrip")
    }

    private fun pasangFirstBlood() {
        val mm = m()
        val diri = mm.p(lbm + O_SELF)
        if (C.b("userAlwaysFirstBlood")) {
            firstBloodId = mm.p(diri + O_ACID)
            lfd = mm.p(scene + 48)
            holdFirstBlood = true
            return
        }
        val id = C.s("frstBloodKiller")?.toLongOrNull()
        if (id == null) {
            log("First Blood aktif tetapi ID pemain belum diisi")
            return
        }
        var cocok = mm.p(diri + O_ACID) == id
        for (p in teamP) if (mm.p(p + O_ACID) == id) cocok = true
        for (p in enemyP) if (mm.p(p + O_ACID) == id) cocok = true
        if (!cocok) {
            log("Auto Firstblood aktif, tetapi tidak ada satupun id yang cocok!")
        } else {
            firstBloodId = id
            lfd = mm.p(scene + 48)
            holdFirstBlood = true
        }
    }

    // ═══════════ putaranUtama ═══════════
    private fun tick() {
        val mm = m()
        val s = sas ?: return
        lbm = ambilLbm(mm, s)
        var state = if (lbm == 0L) "Unknown" else (STATUS.getOrNull(mm.d(lbm + O_STATE)) ?: "Unknown")
        if (state != lastState) {
            val skrg = System.currentTimeMillis()
            val durasi = if (stateChangedAt > 0) " (${lastState} berlangsung ${skrg - stateChangedAt} ms)" else ""
            log("Status game: $lastState -> $state$durasi")
            // Catat timestamp tiap fase penting
            when (state) {
                "Play" -> tsPlay = skrg
                "waitEnd" -> {
                    tsWaitEnd = skrg
                    if (tsPlay > 0) log("  ⏱ Play → waitEnd: ${skrg - tsPlay} ms")
                }
                "End" -> {
                    tsEnd = skrg
                    if (tsWaitEnd > 0) log("  ⏱ waitEnd → End: ${skrg - tsWaitEnd} ms")
                    if (tsPlay > 0) log("  ⏱ Total match (Play → End): ${skrg - tsPlay} ms")
                    // TCP otomatis saat End
                    try {
                        // 1. Kirim e399 Konfirmasi (biar server proses langsung)
                        val okKonf = PaketKirim.kirimKonfirmasi()
                        if (okKonf) log("  ✓ TCP e399 Konfirmasi terkirim saat End")
                        // 2. Kirim TCP klaim hadiah (hanya kalau featKlaimTcp ON)
                        if (Prefs.featKlaimTcp
                            && PaketKirim.capturedKlaimPost.isNotEmpty()
                            && PaketKirim.lastSeq > 0
                            && PaketKirim.gameServerIp.isNotEmpty()) {
                            val okKlaim = PaketKirim.kirimKlaimHadiah()
                            if (okKlaim) {
                                tcpKlaimTerkirim = true
                                log("  ✓ TCP Klaim terkirim saat End (skip klaim di lobby)")
                            }
                        }
                    } catch (e: Throwable) {
                        log("  ⚠ TCP saat End error: ${e.message}")
                    }
                }
                "Unknown" -> {
                    if (tsEnd > 0) log("  ⏱ End → Unknown: ${skrg - tsEnd} ms")
                    // Reset semua timestamp fase
                    tsPlay = 0; tsWaitEnd = 0; tsEnd = 0
                    // tcpKlaimTerkirim TIDAK direset di sini!
                    // Flag ini direset oleh Engine setelah dicek di klaimEvent.
                }
            }
            // Match wajar HARUS lewat Play -> waitEnd -> End -> Unknown (lihat blok "End" di atas: baru di situ
            // TCP e399 Konfirmasi dikirim ke server, yang bikin "Pertandingan" di profil nambah). Kalau status
            // lompat dari Play LANGSUNG ke state lain (skip waitEnd) pas Auto End lagi nyala, besar kemungkinan
            // proses game-nya mati paksa/crash (bukan match selesai beneran) - makanya TCP konfirmasi gak kekirim
            // dan match gak kehitung. Ambil logcat seketika itu juga buat bukti (sebelum buffer-nya ketimpa).
            if (lastState == "Play" && state != "waitEnd" && autoEndTulis != null) {
                log("⚠ Status lompat Play -> $state (lewatin waitEnd) pas Auto End aktif - dicurigai game crash, bukan match selesai wajar. Ambil logcat...")
                Thread({ dumpLogcat("autoend-lompat") }, "dump-logcat-autoend").apply { isDaemon = true }.start()
            }
            stateChangedAt = skrg
            if (C.b("isQuickMode") && lbm != 0L) log("  Quick Mode saat ini: " + ringkasQuick())
            lastState = state
        }
        statusGame = state
        // Watchdog offset lbm "salah tapi lolos validasi frame" (lih. catatan di deklarasi
        // lbmUnknownSejak di atas): kalau offset yang dipercaya sekarang gak pernah bikin status keluar
        // dari Unknown dalam waktu lama, curigai & paksa cari offset lain.
        // CATATAN (bug ditemukan dari log round-7: watchdog kepicu lagi pas Engine lagi di lobi/habis
        // match, di mana status "Unknown" itu MEMANG benar dan wajar bertahan lama — bukan tanda offset
        // salah). Sekarang dibatasi cuma boleh curiga selama Engine beneran nunggu/di dalam match
        // (Cheat.sedangTungguMatch), supaya gak buang-buang rescan atau malah ganti offset yang benar.
        if (lbm != 0L && lbmOffTervalidasi && state == "Unknown" && sedangTungguMatch) {
            val skrgWd = System.currentTimeMillis()
            if (lbmUnknownSejak == 0L) lbmUnknownSejak = skrgWd
            else if (skrgWd - lbmUnknownSejak > LBM_CURIGA_UNKNOWN_MS) {
                log("[Cheat] Curiga offset lbm +0x${java.lang.Long.toHexString(lbmOff)} SALAH: status tetap Unknown selama ${(skrgWd - lbmUnknownSejak) / 1000}s walau pointer tervalidasi (frame naik). Dicoba cari offset lain, yang ini dikecualikan dulu.")
                lbmOffDikecualikan = lbmOff
                lbmOffTervalidasi = false
                lbmOff = 0L
                lbmUnknownSejak = 0L
                jadwalkanScanLbm(s, true)
            }
        } else {
            lbmUnknownSejak = 0L
        }
        if (!ujiAwalSelesai) { ujiAwalSelesai = true; ujiTulis("Uji tulis awal") }
        prosesAksi(state)
        if (!siapMain && (!C.b("isAuto") || !C.b("isQuickMode") || (state != "Unknown" && state != "End"))) siapMain = true

        if (!C.b("isAuto")) {
            statusTeks = "Cheat otomatis mati"
            return
        }
        statusTeks = "Aktif"
        val statusNyata = state

        // DOD dan Stop Download Res dipasang sekali (dan dipasang ulang bila diminta)
        if (C.b("dodIndicator") && !dodTerpasang) dodTerpasang = pasangDod()
        if (C.b("stopResDownload") && !antiResTerpasang) antiResTerpasang = pasangAntiRes()

        // Auto detect game
        if (C.b("isUseAutoDetectGame") && state != "Play" && lbm != 0L) {
            val enter = mm.r8(s.sdStatis + S_ENTER)
            if (enter == 1) state = "Play"
            else if (enter == 0) {
                val t1 = waktuRaw()
                tidur(90)
                val t2 = waktuRaw()
                if (t1 > 0 && t2 > 0 && t1 < t2) state = "Play"
            }
        }

        val sekarang = System.currentTimeMillis()

        // Force End: paksa loncat dari waitEnd ke End (skip sisa animasi Victory)
        // Delay 5 detik agar animasi Victory sudah cukup jalan, baru paksa state=8 (End).
        // 3 detik terlalu cepat (game beku 16s). 7 detik stabil tapi kelamaan.
        if (state == "waitEnd" && lbm != 0L && stateChangedAt > 0) {
            val msWait = sekarang - stateChangedAt
            if (msWait >= 5000) {
                mm.t32(lbm + O_STATE, 8)
                mm.siram()
                if (msWait < 5200) log("⚡ Force End: tulis state=8 (End) ke memori (${msWait}ms setelah waitEnd)")
            }
        }

        // Force Lobby: setelah End + TCP selesai, paksa state=0 (Unknown) biar game reset ke lobby
        // Delay 2 detik setelah End biar TCP sempat terkirim dulu.
        // Hanya aktif kalau featKlaimTcp ON (karena butuh tcpKlaimTerkirim=true).
        if (Prefs.featKlaimTcp && state == "End" && lbm != 0L && stateChangedAt > 0 && tcpKlaimTerkirim) {
            val msEnd = sekarang - stateChangedAt
            if (msEnd >= 2000) {
                mm.t32(lbm + O_STATE, 0)
                mm.siram()
                if (msEnd < 2200) log("⚡ Force Lobby: tulis state=0 (Unknown) ke memori (${msEnd}ms setelah End, TCP sudah terkirim)")
            }
        }

        // Auto End
        if (C.b("autoEnd") && lbm != 0L) {
            if (statusNyata == "Play") {
                if (autoEndLihat == 0L) autoEndLihat = sekarang
                if (!isApply || sekarang - autoEndLihat >= 8000) {
                    if (autoEndMulai == 0L) autoEndMulai = sekarang
                    else {
                        val lewat = (sekarang - autoEndMulai) / 1000.0
                        if (lewat >= 0.3 && lewat <= 0.3 + 120) {
                            if (autoEndTulis == null) {
                                if (enemyM.isEmpty()) callEntity()
                                autoEndTulis = siapkanAutoEnd()
                                autoEndTulis?.let { log("Auto End: lepas proteksi ${it.size / 2} tower musuh") }
                            }
                            autoEndTulis?.let { kirimOps(it) }
                        }
                    }
                }
            } else {
                autoEndLihat = 0L; autoEndMulai = 0L; autoEndTulis = null
            }
        }

        // Mulai hook
        if (state == "Play" && isApply && lbm != 0L) {
            val dipakaiOn = C.b("isUseAutoOn") && C.s("autoOnScriptTime") != null
            if (dipakaiOn) {
                val batas = waktuAutoOn()
                if (batas > 0 && batas <= waktuRaw()) isExecute = true
            } else isExecute = true
            if (isExecute) {
                langkahTeks = "Mulai hook"
                log("Mulai Hook ...")
                val t0hook = System.currentTimeMillis()
                executeScript()
                log("Hook selesai dalam ${System.currentTimeMillis() - t0hook} ms")
                langkahTeks = ""
            }
        }

        if (state != "Play" && C.b("stopResDownload") && antiRes.isNotEmpty()) {
            kirimOps(antiRes)
            tidur(10)
        }

        // Quick mode
        if (C.b("isQuickMode") && (statusNyata == "Unknown" || statusNyata == "End")) {
            if (quickTulis.isEmpty()) {
                if (!siapkanQuickMode() && !quickDiuji) { quickDiuji = true; log("Quick Mode: gagal disiapkan (baca field SystemData gagal atau offset tidak cocok)") }
            }
            if (quickModeBolehTulis(statusNyata)) {
                if (quickLogN < 8) {
                    quickLogN++
                    val dt = System.currentTimeMillis() - tapMulaiAt
                    val ket = if (tapMulaiAt > 0 && dt in 0..8000) " [+$dt ms sesudah Mulai Game]" else ""
                    log("Quick Mode: nilai berubah ($statusNyata), ditulis ulang$ket. Sebelumnya: " + ringkasQuick())
                }
                kirimOps(quickTulis)
                if (!quickDiuji) {
                    quickDiuji = true
                    var cocok = 0
                    for (o in quickTulis) { val n = mm.blok(o.a, o.b.size); if (n != null && n.contentEquals(o.b)) cocok++ }
                    log("Quick Mode: ${quickTulis.size} field ditulis, $cocok terbaca sama sesudahnya")
                }
            }
            tidur(if (kilat()) 3 else 90)
            siapMain = true
        }

        // Cek human di waitReady
        if (state == "waitReady" && C.b("autoCheckHuman") && isCheckHuman) {
            tidur(30)
            cekHuman()
            isCheckHuman = false
        } else if (state != "waitReady" && !isCheckHuman) {
            isCheckHuman = true
        }

        val kalah = C.b("isIAmLose")

        // Teleport tower
        if (state == "Play" && !isApply && (C.b("teleportTower") || C.b("towerRelocation")) &&
            !kalah && !C.b("teleSoldier") && !isCancelTeleport && lbm != 0L
        ) {
            tidur(50)
            repetTower()
        }

        // Mode kalah: soldier
        if (kalah && state == "Play" && !isApply && sekarang - loseClockMs > 1700 && lbm != 0L) {
            soldierMode()
            loseClockMs = System.currentTimeMillis()
        }
        if (kalah && state == "Play" && C.b("teleSoldier") && !isApply && lbm != 0L) {
            tidur(60)
            repetSoldier()
        }

        // Tahan HP tower
        if (state == "Play" && !isApply && updateShield.isNotEmpty() && sekarang - lastShieldMs > 400) {
            tidur(50)
            kirimOps(updateShield)
            lastShieldMs = System.currentTimeMillis()
        }

        // First blood
        if (state == "Play" && holdFirstBlood && lfd != 0L) {
            tidur(60)
            m().t64(lfd + 488, firstBloodId)
            m().siram()
        }

        // Stop minion ditahan
        if (state == "Play" && !isApply && C.b("autoStopMinion") && holdStopMinion.isNotEmpty()) {
            tidur(10)
            kirimOps(holdStopMinion)
        }

        // Set level akun
        // CATATAN: tidak ada cara valid buat memvalidasi offset S_LEVEL (+696) di sini — begitu baris
        // di bawah nulis nilai target (mis. 999) ke alamat ini, baca balik di tick berikutnya PASTI
        // cocok dengan targetnya sendiri, apapun offsetnya (bukan bukti offset-nya benar). Validasi yang
        // benar harus dilakukan saat fitur ini MATI (lihat peringatan di cekHuman()), dengan membandingkan
        // nilai yang kebaca ke level akun yang SEBENARNYA terlihat di dalam game.
        // Dulu dibatasi cuma nulis pas state=="Unknown" (niatnya: cuma di lobby). Sekarang disamain kayak
        // script GG referensi (Ats-up-lvl.lua): nulis terus tiap tick tanpa syarat status, gak peduli lagi
        // di lobby atau di manapun — offset S_LEVEL ini murni field di SystemData (sdStatis), gak ada
        // hubungannya sama status battle (lbm/state) sama sekali.
        if (C.b("isSetLevel") && C.i("ucLevel") != null) {
            val targetLevel = C.i("ucLevel")!!
            val sebelumLevel = m().d(s.sdStatis + S_LEVEL)
            m().t32(s.sdStatis + S_LEVEL, targetLevel)
            m().siram()
            // Baca balik langsung sesudah tulis (dulu gak pernah dicek sama sekali). Ini buat misahin dua
            // kemungkinan kenapa "tampilan level" di dalam game gak berubah padahal log bilang sukses nulis:
            // (a) nilainya KETIMPA BALIK sama game sebelum sempat kebaca lagi di sini (field ini direcalculate
            //     terus tiap frame oleh game) -> baca balik bakal beda dari target, atau
            // (b) nilainya BENERAN nyangkut di memori (baca balik = target) tapi UI-nya (angka level yang
            //     keliatan di layar) memang gak nge-refresh otomatis dari field ini tiap frame — biasanya cuma
            //     disegarkan pas buka/pindah halaman (mis. halaman Growth/Profil). Di sini satu-satunya yang
            //     bisa dipastikan dari memori adalah (b) vs (a); kalau (b), coba buka-tutup halaman Growth/
            //     Profil di dalam game sesudah Set Level aktif buat lihat apa angkanya ikut berubah di sana.
            val sesudahLevel = m().d(s.sdStatis + S_LEVEL)
            // Log cuma kalau nilainya emang beda dari target (biar gak spam tiap tick), tapi ini
            // sekarang satu-satunya bukti di log bahwa fitur ini BENERAN jalan & nulis — sebelumnya
            // blok ini nulis diam-diam tanpa log sama sekali, jadi gak ketauan dari log apa fitur ini
            // aktif atau nggak.
            if (sebelumLevel != targetLevel) {
                val status = if (sesudahLevel == targetLevel) "nyangkut" else "KETIMPA BALIK jadi $sesudahLevel (dicurigai game nulis ulang field ini sendiri tiap frame)"
                log("Set Level: nilai sebelumnya $sebelumLevel, ditulis ulang jadi $targetLevel ($status)")
            }
            tidur(10)
        }

        // Tulis ulang nilai beku (padanan freeze GG)
        if (sekarang - lastBekuMs > 700 && mm.jumlahBeku() > 0 && state == "Play") {
            mm.tickBeku()
            lastBekuMs = System.currentTimeMillis()
        }

        // Keluar dari Play: pulihkan status (isApply dst)
        if (state != "Play" && isNeedRestore) {
            tidur(300)
            updateShield = ArrayList()
            isApply = true
            isExecute = false
            isNeedRestore = false
            isChangeStat = true
            tTeamKda = ArrayList()
            mm.lepasSemuaBeku()
            holdStopMinion = ArrayList()
            bersihkanMatch()
            scene = 0L
            val ringkasan = StringBuilder("Match selesai, siap untuk match berikutnya.")
            if (tsPlay > 0 && tsWaitEnd > 0) ringkasan.append(" Play=${tsWaitEnd - tsPlay}ms")
            if (tsWaitEnd > 0 && tsEnd > 0) ringkasan.append(" waitEnd=${tsEnd - tsWaitEnd}ms")
            log(ringkasan.toString())
        }
    }

    private fun waktuAutoOn(): Int {
        val t = C.s("autoOnScriptTime") ?: return 0
        val bagian = t.split(':', '.')
        val mnt = bagian.getOrNull(0)?.toIntOrNull() ?: return 0
        val dtk = bagian.getOrNull(1)?.toIntOrNull() ?: 0
        return (mnt * 60 + dtk) * 1000
    }
}
