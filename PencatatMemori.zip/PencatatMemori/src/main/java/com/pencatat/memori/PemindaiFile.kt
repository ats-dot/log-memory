package com.pencatat.memori

import android.content.Context
import java.io.File

// Mode cari file: ambil daftar berkas (ukuran + waktu ubah) sebelum match, bandingkan setelahnya.
// Folder 1: data pribadi Multi Run, dibaca lewat run-as.
// Folder 2: Android/data game di dalam Multi Run, dibaca lewat Shizuku (hak shell).
object PemindaiFile {

    class Info(val ukuran: Long, val waktu: Long)

    // jenis: BARU / DIUBAH / DIHAPUS
    class Perubahan(val jenis: String, val path: String, val ukuran: Long, val selisih: Long, val waktu: Long)

    @Volatile var awal: Map<String, Info>? = null
    @Volatile var waktuAwal = 0L
    @Volatile var sedang = false
    @Volatile var pesan = ""
    @Volatile var hasil: List<Perubahan> = emptyList()
    @Volatile var adaHasil = false
    @Volatile var runAs = true
    @Volatile var androidData = true

    private const val NAMA_AWAL = "daftar_awal.txt"
    private const val BATAS = 30000
    private const val GAME = "com.mobile.legends"

    // ---- simpan dan muat daftar awal (supaya tetap ada setelah aplikasi ditutup) ----

    fun muat(ctx: Context) {
        try {
            val f = File(ctx.filesDir, NAMA_AWAL)
            if (!f.exists()) return
            val peta = HashMap<String, Info>()
            var waktu = 0L
            for (baris in f.readLines()) {
                if (baris.startsWith("# ")) {
                    waktu = baris.substring(2).trim().toLongOrNull() ?: 0L
                } else {
                    urai(baris, peta)
                }
            }
            if (peta.isNotEmpty()) {
                awal = peta
                waktuAwal = waktu
            }
        } catch (e: Throwable) {
        }
    }

    private fun simpan(ctx: Context, peta: Map<String, Info>, waktu: Long) {
        try {
            val sb = StringBuilder()
            sb.append("# ").append(waktu).append('\n')
            for ((p, i) in peta) {
                sb.append(p).append('|').append(i.ukuran).append('|').append(i.waktu / 1000).append('\n')
            }
            File(ctx.filesDir, NAMA_AWAL).writeText(sb.toString())
        } catch (e: Throwable) {
        }
    }

    // ---- aksi ----

    fun ambilAwal(ctx: Context, paket: String) {
        if (sedang) return
        sedang = true
        pesan = "Memindai..."
        val app = ctx.applicationContext
        Thread {
            try {
                val peta = pindai(paket)
                if (peta != null) {
                    val t = System.currentTimeMillis()
                    awal = peta
                    waktuAwal = t
                    hasil = emptyList()
                    adaHasil = false
                    simpan(app, peta, t)
                    pesan = ""
                }
            } catch (e: Throwable) {
                pesan = "Gagal memindai: " + e.message
            }
            sedang = false
        }.start()
    }

    fun bandingkan(paket: String) {
        if (sedang) return
        val a = awal
        if (a == null) {
            pesan = "Ambil daftar awal dulu"
            return
        }
        sedang = true
        pesan = "Memindai..."
        Thread {
            try {
                val b = pindai(paket)
                if (b != null) {
                    hasil = hitung(a, b)
                    adaHasil = true
                    pesan = ""
                }
            } catch (e: Throwable) {
                pesan = "Gagal membandingkan: " + e.message
            }
            sedang = false
        }.start()
    }

    // ---- pemindaian ----

    private fun jalankan(perintah: String): String? = try {
        ShizukuHelper.run(arrayOf("sh", "-c", perintah)).second
    } catch (e: Throwable) {
        null
    }

    // Satu baris: path|ukuran|waktu(detik)
    private fun urai(baris: String, ke: MutableMap<String, Info>) {
        val l = baris.trim()
        val i2 = l.lastIndexOf('|')
        if (i2 <= 0) return
        val i1 = l.lastIndexOf('|', i2 - 1)
        if (i1 <= 0) return
        val ukuran = l.substring(i1 + 1, i2).toLongOrNull() ?: return
        val detik = l.substring(i2 + 1).toLongOrNull() ?: return
        ke[l.substring(0, i1)] = Info(ukuran, detik * 1000)
    }

    private fun pindai(paket: String): Map<String, Info>? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) {
            pesan = "Nama paket tidak valid"
            return null
        }
        if (!ShizukuHelper.hasPermission()) {
            pesan = "Shizuku belum diizinkan"
            return null
        }
        if (!runAs && !androidData) {
            pesan = "Pilih minimal satu folder"
            return null
        }
        val peta = HashMap<String, Info>()
        if (runAs) {
            val r = jalankan(
                "run-as $paket find /data/data/$paket -type f -exec stat -c '%n|%s|%Y' {} + 2>/dev/null | head -n $BATAS"
            )
            if (r != null) {
                for (b in r.lines()) urai(b, peta)
            }
        }
        if (androidData) {
            val dasar = "/storage/emulated/0/Android/data/$paket"
            var lokasi = "$dasar/hzby/storage/emulated/1/Android/data/$GAME"
            val ada = jalankan("[ -d '$lokasi' ] && echo ada")
            if (ada == null || !ada.contains("ada")) {
                val cari = jalankan("find '$dasar' -maxdepth 8 -type d -name $GAME 2>/dev/null | head -n 1")
                if (cari != null && cari.trim().isNotEmpty()) lokasi = cari.trim().lines()[0]
            }
            val r = jalankan("find '$lokasi' -type f -exec stat -c '%n|%s|%Y' {} + 2>/dev/null | head -n $BATAS")
            if (r != null) {
                for (b in r.lines()) urai(b, peta)
            }
        }
        if (peta.isEmpty()) {
            pesan = "Tidak ada berkas yang terbaca (folder kosong atau tidak bisa dibuka)"
            return null
        }
        return peta
    }

    private fun hitung(a: Map<String, Info>, b: Map<String, Info>): List<Perubahan> {
        val hasil = ArrayList<Perubahan>()
        for ((p, nb) in b) {
            val na = a[p]
            if (na == null) {
                hasil.add(Perubahan("BARU", p, nb.ukuran, nb.ukuran, nb.waktu))
            } else if (na.ukuran != nb.ukuran || na.waktu != nb.waktu) {
                hasil.add(Perubahan("DIUBAH", p, nb.ukuran, nb.ukuran - na.ukuran, nb.waktu))
            }
        }
        val sekarang = System.currentTimeMillis()
        for ((p, na) in a) {
            if (!b.containsKey(p)) hasil.add(Perubahan("DIHAPUS", p, na.ukuran, -na.ukuran, sekarang))
        }
        hasil.sortByDescending { it.waktu }
        return hasil
    }

    // Teks untuk dibagikan
    fun laporan(): String {
        val sb = StringBuilder()
        sb.append("# Pencatat Memori, hasil Cari file\n")
        sb.append("# berkas pada daftar awal: ").append(awal?.size ?: 0).append("\n")
        for (p in hasil) {
            sb.append(p.jenis).append(' ').append(p.path).append("  ukuran=").append(p.ukuran)
            sb.append(" selisih=").append(p.selisih).append(" waktu=").append(p.waktu / 1000).append('\n')
        }
        return sb.toString()
    }
}
