package com.pencatat.memori

// Lapisan akses memori game untuk fitur skrip. Padanan gg.getValues / gg.setValues / freeze di GameGuardian.
// Baca = dd dari /proc/<pid>/mem. Tulis = dd ke /proc/<pid>/mem (lihat GameShell.tulis).
// Tulisan dikumpulkan dulu di antrean lalu dikirim sekaligus (siram), supaya tidak ada satu shell per alamat.
class Mem(val sh: GameShell, val pid: Int) {

    @Volatile
    var gagalBaca = 0

    private val antrean = ArrayList<Pair<Long, ByteArray>>()
    private val beku = LinkedHashMap<Long, ByteArray>()

    // ── Baca ──
    fun blok(a: Long, n: Int): ByteArray? {
        if (a <= 0L) return null
        val b = sh.baca(pid, a, n)
        if (b == null) gagalBaca++ else gagalBaca = 0
        return b
    }

    fun r8(a: Long): Int? = blok(a, 1)?.let { it[0].toInt() and 0xFF }
    fun r32(a: Long): Int? = blok(a, 4)?.let { Daftar.le(it, 0, 4).toInt() }
    fun r64(a: Long): Long? = blok(a, 8)?.let { Daftar.le(it, 0, 8) }
    fun rf(a: Long): Float? = r32(a)?.let { java.lang.Float.intBitsToFloat(it) }

    // Pointer: 0 kalau gagal baca (sama dengan gg.getValues yang mengembalikan 0)
    fun p(a: Long): Long = r64(a) ?: 0L
    fun d(a: Long): Int = r32(a) ?: 0

    // Baca string C (untuk nama kelas)
    fun teks(a: Long, maks: Int = 64): String? = sh.bacaTeks(pid, a, maks)

    // ── Tulis (masuk antrean) ──
    private fun b4(v: Int) = Mem.by4(v)
    private fun b8(v: Long) = Mem.by8(v)

    fun t8(a: Long, v: Int) { if (a > 0L) antrean.add(Pair(a, byteArrayOf(v.toByte()))) }
    fun t32(a: Long, v: Int) { if (a > 0L) antrean.add(Pair(a, b4(v))) }
    fun t64(a: Long, v: Long) { if (a > 0L) antrean.add(Pair(a, b8(v))) }
    fun tf(a: Long, v: Float) { if (a > 0L) antrean.add(Pair(a, b4(java.lang.Float.floatToRawIntBits(v)))) }

    val adaAntrean: Boolean get() = antrean.isNotEmpty()

    // Kirim semua tulisan di antrean. Mengembalikan daftar yang dikirim (untuk verifikasi) atau null kalau shell gagal.
    fun siram(): List<Pair<Long, ByteArray>>? {
        if (antrean.isEmpty()) return emptyList()
        val kirim = ArrayList(antrean)
        antrean.clear()
        return if (sh.tulis(pid, kirim)) kirim else null
    }

    // Tulis langsung (satu kelompok) lalu verifikasi sebagian lewat baca ulang.
    // Hasil: (jumlah cocok, jumlah dicek). Cocok = isi memori sama dengan yang ditulis.
    fun siramDanCek(maksCek: Int = 6): Pair<Int, Int>? {
        val kirim = siram() ?: return null
        if (kirim.isEmpty()) return Pair(0, 0)
        // Hanya cek alamat terakhir yang ditulis per alamat (kalau ada beberapa tulisan ke alamat sama)
        val terakhir = LinkedHashMap<Long, ByteArray>()
        for ((a, b) in kirim) terakhir[a] = b
        var cek = 0
        var cocok = 0
        for ((a, b) in terakhir) {
            if (cek >= maksCek) break
            val now = sh.baca(pid, a, b.size) ?: continue
            cek++
            if (now.contentEquals(b)) cocok++
        }
        return Pair(cocok, cek)
    }

    // ── Freeze (gg.addListItems freeze=true): ditulis ulang tiap tickBeku() ──
    fun beku8(a: Long, v: Int) { if (a > 0L) beku[a] = byteArrayOf(v.toByte()) }
    fun beku32(a: Long, v: Int) { if (a > 0L) beku[a] = b4(v) }
    fun beku64(a: Long, v: Long) { if (a > 0L) beku[a] = b8(v) }

    fun lepasSemuaBeku() { beku.clear() }
    fun jumlahBeku(): Int = beku.size

    fun tickBeku(): Boolean {
        if (beku.isEmpty()) return true
        val l = ArrayList<Pair<Long, ByteArray>>()
        for ((a, b) in beku) l.add(Pair(a, b))
        return sh.tulis(pid, l)
    }

    companion object {
        fun by1(v: Int) = byteArrayOf(v.toByte())
        fun by4(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
        fun by8(v: Long): ByteArray {
            val r = ByteArray(8)
            for (i in 0 until 8) r[i] = (v shr (8 * i)).toByte()
            return r
        }
        fun byF(v: Float) = by4(java.lang.Float.floatToRawIntBits(v))
    }
}
