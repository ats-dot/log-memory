package com.pencatat.memori

// Pemantau jaringan ringan (tanpa isi paket): satu shell Shizuku yang terus membaca /proc/net/dev (total byte
// perangkat) dan /proc/net/{tcp,tcp6,udp,udp6} (koneksi milik uid game), lalu mencatat
//   - lonjakan trafik (byte keluar/masuk, lamanya, selisih waktu dari ketukan bot dan perubahan layar)
//   - koneksi game yang baru/hilang (alamat tujuan)
// Selain itu, Clone mencatat SEMUA paket socket game dengan isi lengkap. Semuanya (paket + baris log bot + ketukan)
// digabung urut waktu ke satu berkas di Download/AutoUpLvl/ supaya bisa dianalisis. Log utama hanya memuat ringkasan.
object NetMon {
    private fun log(m: String) = AppLog.add("[Net] $m")

    @Volatile private var jalan = false
    @Volatile private var sesi = 0          // naik tiap mulai(); thread sesi lama berhenti sendiri
    @Volatile private var proses: Process? = null
    private var thread: Thread? = null

    // Ditulis Engine supaya log jaringan bisa menyebut selisih waktunya
    @Volatile var terakhirKetuk = 0L
    @Volatile var terakhirKetukLabel = ""
    @Volatile var terakhirLayarBerubah = 0L

    private const val JEDA = "0.25"
    private const val AMBANG_BYTE = 1500L   // di bawah ini dianggap noise latar
    private const val JEDA_AKHIR_MS = 600L  // lonjakan dianggap selesai sesudah sepi sekian ms

    @Volatile private var ctxApp: android.content.Context? = null
    private val antre = java.util.concurrent.LinkedBlockingQueue<String>(300000)

    // Dipanggil AppLog untuk tiap baris log bot, supaya masuk ke berkas gabungan
    fun gabung(baris: String) {
        if (jalan) antre.offer(baris)
    }

    // Tandai satu ketukan (dipanggil Engine)
    fun ketuk(label: String) {
        val t = System.currentTimeMillis()
        terakhirKetuk = t
        terakhirKetukLabel = label
        if (jalan) antre.offer(waktu(t) + " ★ ketuk " + label)
    }

    fun mulai(ctx: android.content.Context, paket: String) {
        if (jalan) return
        ctxApp = ctx.applicationContext
        if (!ShizukuHelper.hasPermission()) { log("Shizuku belum siap, pemantau jaringan tidak dijalankan"); return }
        val uid = Pencari.uidPaket(paket)
        if (uid == null) { log("Paket $paket tidak ditemukan, pemantau jaringan tidak dijalankan"); return }
        jalan = true
        sesi++
        val s0 = sesi
        antre.clear()
        val t = Thread({ loop(uid, s0) }, "netmon")
        t.isDaemon = true
        thread = t
        t.start()
        val t2 = Thread({ bacaLogClone(paket, s0) }, "netmon-clone")
        t2.isDaemon = true
        t2.start()
        val t3 = Thread({ tulisBerkas(s0) }, "netmon-berkas")
        t3.isDaemon = true
        t3.start()
    }

    // Penulis berkas gabungan di Download/AutoUpLvl (berganti berkas tiap ±10 MB)
    private fun tulisBerkas(s0: Int) {
        val ctx = ctxApp ?: return
        var out: java.io.OutputStream? = null
        var ukuran = 0L
        var terakhirFlush = System.currentTimeMillis()
        val tgl = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US)
        var bagian = 0
        fun buka() {
            try { out?.flush(); out?.close() } catch (_: Throwable) {}
            out = null; ukuran = 0L; bagian++
            val nama = "auto-up-lvl-jaringan-" + tgl.format(java.util.Date()) + (if (bagian > 1) "-$bagian" else "") + ".txt"
            try {
                val cv = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, nama)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/AutoUpLvl")
                }
                val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                val os = if (uri != null) ctx.contentResolver.openOutputStream(uri) else null
                if (os != null) {
                    out = java.io.BufferedOutputStream(os, 65536)
                    log("Tangkapan jaringan lengkap disimpan ke Download/AutoUpLvl/$nama")
                }
            } catch (e: Throwable) {
                log("Berkas tangkapan jaringan gagal dibuat: ${e.javaClass.simpleName} ${e.message}")
            }
        }
        try {
            while (s0 == sesi && (jalan || antre.isNotEmpty())) {
                val l = antre.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS)
                val now = System.currentTimeMillis()
                if (l != null) {
                    if (out == null && bagian == 0) buka()
                    if (out != null && ukuran > 10L * 1024 * 1024) buka()
                    val b = (l + "\n").toByteArray()
                    try { out?.write(b); ukuran += b.size } catch (_: Throwable) {}
                }
                if (now - terakhirFlush > 1000) {
                    try { out?.flush() } catch (_: Throwable) {}
                    terakhirFlush = now
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            try { out?.flush(); out?.close() } catch (_: Throwable) {}
        }
    }

    @Volatile private var prosesClone: Process? = null

    // Log lalu lintas socket dari dalam Clone (netlog.txt di data aplikasi Clone), dibaca lewat run-as
    private fun bacaLogClone(paket: String, s0: Int) {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return
        var pLokal: Process? = null
        try {
            val p = ShizukuHelper.start(arrayOf("sh", "-c",
                "run-as $paket sh -c 'mkdir -p files; : > files/netlog.txt; tail -n 0 -F files/netlog.txt'"))
            pLokal = p
            prosesClone = p
            log("Pembaca log socket Clone jalan")
            val r = p.inputStream.bufferedReader()
            while (jalan && s0 == sesi) {
                val baris = r.readLine() ?: break
                laporBarisClone(baris)
            }
        } catch (e: Throwable) {
            if (jalan) log("Pembaca log socket Clone berhenti: ${e.javaClass.simpleName} ${e.message}")
        } finally {
            try { pLokal?.destroy() } catch (_: Throwable) {}
            if (s0 == sesi) prosesClone = null
        }
    }

    // ms|pid|op|fd|tujuan|panjang|tag|hex|ascii
    // Baris lengkap -> berkas gabungan. Log utama hanya memuat awal proses dan koneksi baru.
    private fun laporBarisClone(baris: String) {
        val f = baris.split('|')
        if (f.size < 9) return
        val ms = f[0].toLongOrNull() ?: return
        val op = f[2]
        val jam = waktu(ms)
        val ket = terakhirKetuk
        val relatif = if (ket > 0 && ms - ket in 0..3000) " (+${ms - ket} ms sesudah ketukan ${terakhirKetukLabel})" else ""
        when (op) {
            "START" -> log("Clone: pencatat socket aktif di proses ${f[1]}")
            "CONN" -> {
                log("sambung ${f[4]} (fd=${f[3]}, hasil=${f[5]})")
                antre.offer("$jam NET SAMBUNG ${f[4]} fd=${f[3]} hasil=${f[5]} pid=${f[1]}")
            }
            "SEND" -> {
                val hex = f[7]
                val byteLen = f[5].toIntOrNull() ?: 0
                // Decode opcode untuk log yang mudah dibaca
                val opLabel = if (hex.length >= 16) {
                    when (hex.substring(8, 16)) {
                        "7000974f" -> " [MATCHMAKING]"
                        "7000984f" -> " [MATCH_ACK]"
                        "7000bbea" -> if (byteLen >= 40) " [KLAIM_HADIAH]" else " [BUKA_HALAMAN]"
                        "7000b3ea" -> " [QUERY_STATUS]"
                        "7000b0ff" -> " [QUERY_LANJUTAN]"
                        "7000bcea" -> " [ACK_KLAIM]"
                        "7000e399" -> " [KONFIRMASI]"
                        "7000a14e" -> " [TELEMETRY]"
                        "7000a74e" -> " [BATTLE_CONN]"
                        "7000cb94" -> " [PRE_BATTLE_1]"
                        "7000cc94" -> " [PRE_BATTLE_2]"
                        else -> ""
                    }
                } else ""
                antre.offer("$jam NET KIRIM ${f[4]} fd=${f[3]} pid=${f[1]} $byteLen byte ${f[6]}$opLabel hex=$hex asc=\"${f[8]}\"$relatif")
                val dest = f[4]
                if (dest.contains(":10003")) {
                    PaketKirim.lacakSeq(hex, dest)
                    // Tangkap payload klaim asli: paket bbea >= 40 byte ke game server
                    // HANYA tangkap saat Engine sudah set siapTangkap=true (sebelum UI klaim)
                    // Ini mencegah salah tangkap paket bbea lain saat lobby loading
                    if (PaketKirim.siapTangkap
                        && byteLen >= 40 && hex.length >= 24
                        && hex.substring(8, 16) == "7000bbea"
                        && PaketKirim.capturedKlaimPost.isEmpty()) {
                        val postSeq = hex.substring(24)
                        if (postSeq.isNotEmpty()) {
                            PaketKirim.tangkapKlaim(postSeq)
                            log("Klaim payload tertangkap dari paket game ($byteLen byte)")
                        }
                    }
                }
            }
            "RECV" -> {
                val hexR = f[7]
                val byteLenR = f[5].toIntOrNull() ?: 0
                val opLabelR = if (hexR.length >= 16) {
                    when (hexR.substring(8, 16)) {
                        "7000984f" -> " [MATCH_RESP]"
                        "7000bcea" -> " [ACK_KLAIM]"
                        "7000a14e" -> " [TELEMETRY]"
                        "7000a74e" -> " [BATTLE_INFO]"
                        "7000cb94" -> " [PRE_BATTLE_1]"
                        "7000cc94" -> " [PRE_BATTLE_2]"
                        "7000974f" -> " [MATCHMAKING]"
                        else -> ""
                    }
                } else ""
                antre.offer("$jam NET TERIMA ${f[4]} fd=${f[3]} pid=${f[1]} $byteLenR byte ${f[6]}$opLabelR hex=$hexR asc=\"${f[8]}\"$relatif")
            }
            "CMD" -> {
                log("CMD terkirim ke ${f[4]} (${f[5]} byte)")
                antre.offer("$jam NET CMD ${f[4]} fd=${f[3]} pid=${f[1]} ${f[5]} byte")
            }
            else -> return
        }
    }

    fun henti() {
        jalan = false
        try { proses?.destroy() } catch (_: Throwable) {}
        proses = null
        try { prosesClone?.destroy() } catch (_: Throwable) {}
        prosesClone = null
    }

    private fun loop(uid: Int, s0: Int) {
        var pLokal: Process? = null
        val skrip = "while :; do echo @@B; cat /proc/net/dev; echo @@C; " +
            "cat /proc/net/tcp /proc/net/tcp6 /proc/net/udp /proc/net/udp6 2>/dev/null; echo @@E; sleep $JEDA; done"
        try {
            val p = ShizukuHelper.start(arrayOf("sh", "-c", skrip))
            pLokal = p
            proses = p
            log("Pemantau jaringan jalan (uid $uid, tiap ${JEDA}s)")
            val r = p.inputStream.bufferedReader()
            val dev = ArrayList<String>()
            val sock = ArrayList<String>()
            var bagian = 0
            var prevRx = -1L
            var prevTx = -1L
            var prevT = 0L

            // keadaan lonjakan
            var lonjakMulai = 0L
            var lonjakTx = 0L
            var lonjakRx = 0L
            var terakhirRamai = 0L
            var ketukSaatMulai = 0L
            var ketukLabelMulai = ""
            var layarSaatMulai = 0L

            var koneksiLama = emptySet<String>()
            var koneksiTerbaca = false

            while (jalan && s0 == sesi) {
                val baris = r.readLine() ?: break
                when {
                    baris == "@@B" -> { dev.clear(); sock.clear(); bagian = 1 }
                    baris == "@@C" -> bagian = 2
                    baris == "@@E" -> {
                        val t = System.currentTimeMillis()
                        val (rx, tx) = jumlahByte(dev)
                        if (prevRx >= 0 && rx >= prevRx && tx >= prevTx) {
                            val dRx = rx - prevRx
                            val dTx = tx - prevTx
                            if (dRx + dTx >= AMBANG_BYTE) {
                                if (lonjakMulai == 0L) {
                                    lonjakMulai = prevT
                                    lonjakTx = 0; lonjakRx = 0
                                    ketukSaatMulai = terakhirKetuk
                                    ketukLabelMulai = terakhirKetukLabel
                                    layarSaatMulai = terakhirLayarBerubah
                                }
                                lonjakTx += dTx
                                lonjakRx += dRx
                                terakhirRamai = t
                            } else if (lonjakMulai != 0L && t - terakhirRamai >= JEDA_AKHIR_MS) {
                                laporLonjakan(lonjakMulai, terakhirRamai, lonjakTx, lonjakRx, ketukSaatMulai, ketukLabelMulai, layarSaatMulai)
                                lonjakMulai = 0L
                            }
                        }
                        prevRx = rx; prevTx = tx; prevT = t

                        val k = koneksiUid(sock, uid)
                        if (koneksiTerbaca) {
                            val baru = k - koneksiLama
                            val hilang = koneksiLama - k
                            if (baru.isNotEmpty() || hilang.isNotEmpty()) {
                                val sb = StringBuilder("koneksi game")
                                if (baru.isNotEmpty()) sb.append(" +").append(baru.sorted().joinToString(" +"))
                                if (hilang.isNotEmpty()) sb.append(" -").append(hilang.sorted().joinToString(" -"))
                                log(sb.toString())
                            }
                        } else if (k.isNotEmpty()) {
                            log("koneksi game awal: " + k.sorted().joinToString(", "))
                        }
                        koneksiLama = k
                        koneksiTerbaca = true
                        bagian = 0
                    }
                    bagian == 1 -> dev.add(baris)
                    bagian == 2 -> sock.add(baris)
                }
            }
            if (lonjakMulai != 0L) laporLonjakan(lonjakMulai, terakhirRamai, lonjakTx, lonjakRx, ketukSaatMulai, ketukLabelMulai, layarSaatMulai)
        } catch (e: Throwable) {
            if (jalan) log("Pemantau jaringan berhenti: ${e.javaClass.simpleName} ${e.message}")
        } finally {
            try { pLokal?.destroy() } catch (_: Throwable) {}
            if (s0 == sesi) {
                jalan = false
                proses = null
            }
        }
    }

    private val fmtJam = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
    private fun waktu(t: Long): String = synchronized(fmtJam) { fmtJam.format(java.util.Date(t)) }

    private fun laporLonjakan(mulai: Long, akhir: Long, tx: Long, rx: Long, ketuk: Long, ketukLabel: String, layar: Long) {
        val sb = StringBuilder("lonjakan trafik ")
        sb.append(waktu(mulai)).append("–").append(waktu(akhir))
        sb.append(" (").append(akhir - mulai).append(" ms): keluar ").append(kb(tx)).append(", masuk ").append(kb(rx))
        if (ketuk > 0) {
            val d = mulai - ketuk
            sb.append("; ").append(if (d >= 0) "$d ms sesudah" else "${-d} ms sebelum").append(" ketukan terakhir")
            if (ketukLabel.isNotEmpty()) sb.append(" (").append(ketukLabel).append(")")
        }
        if (layar > 0) {
            val d = mulai - layar
            sb.append("; ").append(if (d >= 0) "$d ms sesudah" else "${-d} ms sebelum").append(" layar berubah")
        }
        log(sb.toString())
    }

    private fun kb(b: Long): String = if (b >= 1048576) String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
    else String.format(java.util.Locale.US, "%.1f KB", b / 1024.0)

    // Jumlah byte semua antarmuka jaringan nyata (wlan/rmnet/ccmni/eth); v4-* disaring karena menggandakan
    private fun jumlahByte(dev: List<String>): Pair<Long, Long> {
        var rx = 0L
        var tx = 0L
        for (l in dev) {
            val i = l.indexOf(':')
            if (i < 0) continue
            val nama = l.substring(0, i).trim()
            if (!(nama.startsWith("wlan") || nama.startsWith("rmnet") || nama.startsWith("ccmni") || nama.startsWith("eth"))) continue
            val f = l.substring(i + 1).trim().split(Regex("\\s+"))
            if (f.size < 9) continue
            rx += f[0].toLongOrNull() ?: 0L
            tx += f[8].toLongOrNull() ?: 0L
        }
        return Pair(rx, tx)
    }

    // Tujuan koneksi (bukan loopback) milik uid game. TCP: hanya ESTABLISHED; UDP: yang sudah punya tujuan.
    private fun koneksiUid(sock: List<String>, uid: Int): Set<String> {
        val hasil = HashSet<String>()
        for (l in sock) {
            val f = l.trim().split(Regex("\\s+"))
            if (f.size < 8) continue
            if (f[7] != uid.toString()) continue
            val rem = f[2]
            val st = f[3]
            val c = rem.indexOf(':')
            if (c < 0) continue
            val alamat = rem.substring(0, c)
            val port = rem.substring(c + 1).toIntOrNull(16) ?: continue
            if (port == 0) continue
            val ip = ip(alamat) ?: continue
            if (ip.startsWith("127.") || ip == "::1") continue
            if (st != "01" && st != "07") continue
            hasil.add("$ip:$port")
        }
        return hasil
    }

    // Alamat heksa /proc/net/*: tiap 4 byte ditulis little-endian
    private fun ip(h: String): String? {
        try {
            if (h.length == 8) {
                val v = java.lang.Long.parseLong(h, 16)
                return "${v and 255}.${(v shr 8) and 255}.${(v shr 16) and 255}.${(v shr 24) and 255}"
            }
            if (h.length == 32) {
                val w = (0 until 4).map { java.lang.Long.parseLong(h.substring(it * 8, it * 8 + 8), 16) }
                fun le(v: Long) = longArrayOf(v and 255, (v shr 8) and 255, (v shr 16) and 255, (v shr 24) and 255)
                if (w[0] == 0L && w[1] == 0L && w[2] == 0xFFFF0000L) {
                    val b = le(w[3])
                    return "${b[0]}.${b[1]}.${b[2]}.${b[3]}"
                }
                if (w[0] == 0L && w[1] == 0L && w[2] == 0L && w[3] == 0x01000000L) return "::1"
                val o = ArrayList<String>()
                for (x in w) {
                    val b = le(x)
                    o.add(String.format("%02x%02x", b[0], b[1]))
                    o.add(String.format("%02x%02x", b[2], b[3]))
                }
                return o.joinToString(":")
            }
        } catch (_: Throwable) {}
        return null
    }
}
