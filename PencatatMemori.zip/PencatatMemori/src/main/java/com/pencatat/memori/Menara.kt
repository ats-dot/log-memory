package com.pencatat.memori

class Menara(val alamat: Long) {
    var x = 0f
    var y = 0f
    var label = ""
    var ketPos = ""
    var posTahu = false
    var cobaPos = 0
    var attr = 0L
    var cekAttrMs = 0L

    @Volatile
    var hidup = true
}

// Mencari tower musuh lewat kamus monster di LogicBattleManager, dengan cara yang sama
// seperti getAllMonster + daftarTowerMusuh + convertToAttr di script GG.
object PencariMenara {

    private val bukanMenara = HashSet<Long>()
    private val dikenal = LinkedHashMap<Long, Menara>()
    private var urut = 0

    // Entri baru yang diperiksa per penyegaran (supaya tidak ada lonjakan beban)
    private const val BATAS_BARU = 40

    fun reset() {
        bukanMenara.clear()
        dikenal.clear()
        urut = 0
    }

    // Alamat objek atribut sebuah entitas:
    // a = [entitas + m_AttrComp] + m_dictIncreaseAttrs ; b = [a] + geserB ; c = [b]
    fun alamatAttr(sh: GameShell, pid: Int, entitas: Long): Long {
        val komponen = sh.bacaLong(pid, entitas + Daftar.OFF_ATTR_COMP.toLong()) ?: return 0L
        if (komponen == 0L) return 0L
        val kamus = sh.bacaLong(pid, komponen + Daftar.OFF_ATTR_DICT.toLong()) ?: return 0L
        if (kamus == 0L) return 0L
        return sh.bacaLong(pid, kamus + Daftar.GESER_B.toLong()) ?: 0L
    }

    // Telusuri kamus monster, periksa alamat baru, kembalikan tower musuh yang masih ada.
    // null = gagal membaca (coba lagi nanti).
    fun segarkan(sh: GameShell, pid: Int, lbm: Long, campSaya: Int): List<Menara>? {
        val kamus = sh.bacaLong(pid, lbm + Daftar.OFF_DIC_MONSTER.toLong()) ?: return null
        if (kamus == 0L) return null
        val b = sh.bacaLong(pid, kamus + Daftar.GESER_KAMUS.toLong()) ?: return null
        if (b == 0L) return null

        val panjang = Daftar.ENTRI_AKHIR - Daftar.ENTRI_AWAL + 8
        val blok = sh.baca(pid, b + Daftar.ENTRI_AWAL.toLong(), panjang) ?: return null

        val ada = HashSet<Long>()
        val baru = ArrayList<Menara>()
        var diperiksa = 0
        var r = 0
        while (r <= Daftar.ENTRI_AKHIR - Daftar.ENTRI_AWAL) {
            val p = Daftar.le(blok, r, 8)
            r += Daftar.ENTRI_LANGKAH
            if (p == 0L) continue
            ada.add(p)
            if (bukanMenara.contains(p) || dikenal.containsKey(p)) continue
            if (diperiksa >= BATAS_BARU) continue
            diperiksa++
            val e = sh.baca(pid, p, Daftar.PANJANG_KLASIFIKASI) ?: continue
            // Sama dengan daftarTowerMusuh: byte 0x59 = 1, byte 0x72 = 1, atau m_MonsterType = 2
            val tower = (e[Daftar.OFF_IS_TOWER].toInt() == 1) ||
                (e[Daftar.OFF_IS_MAIN].toInt() == 1) ||
                (Daftar.le(e, Daftar.OFF_MONSTER_TYPE, 4).toInt() == 2)
            if (!tower) {
                bukanMenara.add(p)
                continue
            }
            val camp = Daftar.le(e, Daftar.OFF_CAMP, 4).toInt()
            if (camp == campSaya) {
                bukanMenara.add(p)
                continue
            }
            val m = Menara(p)
            m.x = Daftar.pecahan(e, Daftar.POS_X)
            m.y = Daftar.pecahan(e, Daftar.POS_Y)
            // Tepat setelah match mulai posisi tower sering masih 0,0: dibaca ulang nanti (segarkanPosisi)
            if (adaPosisi(m.x, m.y)) isiPosisi(m, m.x, m.y)
            baru.add(m)
        }

        // Tower baru diberi nama berurutan menurut posisi (x lalu y)
        baru.sortWith(compareBy({ it.x }, { it.y }))
        for (m in baru) {
            urut++
            m.label = "T$urut"
            dikenal[m.alamat] = m
        }
        // Yang tidak ada lagi di kamus dianggap hancur
        for (m in dikenal.values) {
            if (!ada.contains(m.alamat)) m.hidup = false
        }
        val hasil = ArrayList<Menara>()
        for (m in dikenal.values) {
            if (m.hidup) hasil.add(m)
        }
        return hasil
    }

    private fun adaPosisi(x: Float, y: Float): Boolean =
        !x.isNaN() && !y.isNaN() && !x.isInfinite() && !y.isInfinite() && (x != 0f || y != 0f)

    private fun isiPosisi(m: Menara, x: Float, y: Float) {
        m.x = x
        m.y = y
        m.posTahu = true
        m.ketPos = Daftar.namaMid(x, y)
    }

    // Baca ulang posisi tower yang belum terisi (maksimal 90 percobaan per tower).
    // Mengembalikan tower yang posisinya BARU terbaca.
    fun segarkanPosisi(sh: GameShell, pid: Int, daftar: List<Menara>): List<Menara> {
        val baru = ArrayList<Menara>()
        for (m in daftar) {
            if (m.posTahu || !m.hidup || m.cobaPos >= 90) continue
            m.cobaPos++
            val b = sh.baca(pid, m.alamat + Daftar.POS_X.toLong(), 12) ?: continue
            val x = Daftar.pecahan(b, 0)
            val y = Daftar.pecahan(b, Daftar.POS_Y - Daftar.POS_X)
            if (!adaPosisi(x, y)) continue
            isiPosisi(m, x, y)
            baru.add(m)
        }
        return baru
    }

    // Tower yang baru ditemukan pada pemanggilan terakhir (untuk dicatat)
    fun semua(): List<Menara> = ArrayList(dikenal.values)
}
