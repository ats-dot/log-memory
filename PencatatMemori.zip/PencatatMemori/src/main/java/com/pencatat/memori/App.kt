package com.pencatat.memori

import android.app.ActivityManager
import android.app.Application
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)

        // Catat penyebab crash ke log (tersimpan di berkas)
        val lama = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                AppLog.tambahSinkron("CRASH di thread ${t.name}: " + Log.getStackTraceString(e).take(1800))
            } catch (_: Throwable) {}
            lama?.uncaughtException(t, e)
        }

        // Catat alasan proses sebelumnya berhenti (crash, dimatikan sistem, dsb.)
        try {
            val sp = getSharedPreferences("auto_up_lvl", MODE_PRIVATE)
            val terlihat = sp.getLong("exitSeen", 0L)
            val am = getSystemService(ActivityManager::class.java)
            val daftar = am.getHistoricalProcessExitReasons(packageName, 0, 6).filter { it.timestamp > terlihat }
            val f = SimpleDateFormat("HH:mm:ss", Locale.US)
            for (r in daftar.reversed()) {
                AppLog.add("Proses sebelumnya berhenti (" + f.format(Date(r.timestamp)) + "): " + alasan(r.reason) + " · " + (r.description ?: "-"))
            }
            if (daftar.isNotEmpty()) sp.edit().putLong("exitSeen", daftar.maxOf { it.timestamp }).apply()
        } catch (_: Throwable) {}
    }

    private fun alasan(k: Int): String = when (k) {
        ApplicationExitInfo_EXIT_SELF -> "keluar sendiri"
        2 -> "dibunuh sinyal"
        3 -> "memori sistem habis"
        4 -> "crash"
        5 -> "crash native"
        6 -> "ANR"
        7 -> "gagal inisialisasi"
        8 -> "izin diubah"
        9 -> "pemakaian sumber daya berlebih"
        10 -> "dihentikan pengguna"
        11 -> "dihentikan pengguna (paksa)"
        12 -> "ketergantungan mati"
        14 -> "dibekukan sistem"
        else -> "lainnya ($k)"
    }

    private companion object {
        const val ApplicationExitInfo_EXIT_SELF = 1
    }
}
