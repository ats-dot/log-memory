package com.pencatat.memori

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle

// Kirim hasil ke aplikasi "Catatan Cabang": server mana yang sudah di-up dan jadi level 20, keterangan "Biasa".
object CatatanLink {
    private const val PKG = "com.catatan.cabang"
    private val URI = Uri.parse("content://com.catatan.cabang.bukti")

    // Hasil: teks status untuk log
    fun kirim(ctx: Context, akun: String, server: String, level: Int, ket: String): String {
        val id = akun.filter { it.isDigit() }
        val sv = server.filter { it.isDigit() }
        if (id.length < 6) return "ID akun belum terbaca, tidak dikirim"
        if (sv.isEmpty()) return "kode server tidak terbaca, tidak dikirim"
        // 1) Lewat pintu data (andal: ikut membangunkan aplikasi Catatan Cabang)
        try {
            val b = Bundle()
            b.putString("server", sv)
            b.putString("level", level.toString())
            b.putString("keterangan", ket)
            val r = ctx.contentResolver.call(URI, "server", id, b)
            if (r != null && r.getBoolean("ok", false)) return "terkirim"
        } catch (e: Exception) {
        }
        // 2) Cadangan: siaran langsung ke aplikasinya
        return try {
            val i = Intent("com.catatan.cabang.UPDATE_SERVER")
            i.setPackage(PKG)
            i.putExtra("id", id)
            i.putExtra("server", sv)
            i.putExtra("level", level.toString())
            i.putExtra("keterangan", ket)
            i.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            ctx.sendBroadcast(i)
            "dikirim lewat siaran (belum ada konfirmasi)"
        } catch (e: Exception) {
            "gagal: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
