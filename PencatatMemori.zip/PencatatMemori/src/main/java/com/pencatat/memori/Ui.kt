package com.pencatat.memori

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// Warna mengikuti mockup (gelap dan terang).
class Pal(val gelap: Boolean) {
    val bg = if (gelap) 0xFF0D1117.toInt() else 0xFFF4F6F8.toInt()
    val surf = if (gelap) 0xFF151B23.toInt() else 0xFFFFFFFF.toInt()
    val surf2 = if (gelap) 0xFF1C242E.toInt() else 0xFFEEF1F4.toInt()
    val bd = if (gelap) 0xFF2A3441.toInt() else 0xFFD9DFE6.toInt()
    val tx = if (gelap) 0xFFE8EDF3.toInt() else 0xFF11161C.toInt()
    val mu = if (gelap) 0xFF9AA7B6.toInt() else 0xFF566170.toInt()
    val acc = if (gelap) 0xFF2DD4BF.toInt() else 0xFF0F766E.toInt()
    val onAcc = if (gelap) 0xFF04211D.toInt() else 0xFFFFFFFF.toInt()
    val ambBg = if (gelap) 0xFF3A2E10.toInt() else 0xFFFEF3C7.toInt()
    val ambTx = if (gelap) 0xFFFBBF24.toInt() else 0xFF92400E.toInt()
    val bluBg = if (gelap) 0xFF1E3A5F.toInt() else 0xFFDCEBFF.toInt()
    val bluTx = if (gelap) 0xFF9CC9FF.toInt() else 0xFF0B4A99.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bentuk(isi: Int, radiusDp: Int, garis: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(isi)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (garis != 0) g.setStroke(dp(1), garis)
    return g
}

fun Context.teks(s: String, ukuranSp: Float, warna: Int, tebal: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, ukuranSp)
    t.setTextColor(warna)
    if (tebal) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

// gaya: 0 = utama (terisi), 1 = bergaris, 2 = pilihan
fun Context.tombol(label: String, pal: Pal, gaya: Int, klik: () -> Unit): Button {
    val b = Button(this)
    b.text = label
    b.isAllCaps = false
    b.stateListAnimator = null
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    b.typeface = Typeface.DEFAULT_BOLD
    when (gaya) {
        0 -> {
            b.background = bentuk(pal.acc, 14)
            b.setTextColor(pal.onAcc)
        }
        1 -> {
            b.background = bentuk(0, 14, pal.bd)
            b.setTextColor(pal.tx)
        }
        else -> {
            b.background = bentuk(pal.surf2, 12)
            b.setTextColor(pal.tx)
        }
    }
    b.minHeight = dp(48)
    b.minimumHeight = dp(48)
    b.setOnClickListener { klik() }
    return b
}

fun lp(
    lebar: Int = ViewGroup.LayoutParams.MATCH_PARENT,
    tinggi: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
    bobot: Float = 0f,
    kiri: Int = 0,
    atas: Int = 0,
    kanan: Int = 0,
    bawah: Int = 0
): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(lebar, tinggi, bobot)
    p.setMargins(kiri, atas, kanan, bawah)
    return p
}
