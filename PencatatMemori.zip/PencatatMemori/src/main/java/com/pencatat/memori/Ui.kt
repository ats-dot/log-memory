package com.pencatat.memori

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView

// Warna mengikuti mockup (gelap dan terang).
class Pal(val gelap: Boolean) {
    val bg = if (gelap) 0xFF0D1117.toInt() else 0xFFF4F6F8.toInt()
    val surf = if (gelap) 0xFF151B23.toInt() else 0xFFFFFFFF.toInt()
    val surf2 = if (gelap) 0xFF1C242E.toInt() else 0xFFEEF1F4.toInt()
    val bd = if (gelap) 0xFF2A3441.toInt() else 0xFFD9DFE6.toInt()
    val tx = if (gelap) 0xFFE8EDF3.toInt() else 0xFF11161C.toInt()
    val mu = if (gelap) 0xFF9AA7B6.toInt() else 0xFF566170.toInt()
    val acc = if (gelap) 0xFF2DD4BF.toInt() else 0xFF0F766E.toInt()
    val onAcc = if (gelap) 0xFF04211D.toInt() else 0xFFFFFFFF.toInt()
    val ambBg = if (gelap) 0xFF3A2E10.toInt() else 0xFFFEF3C7.toInt()
    val ambTx = if (gelap) 0xFFFBBF24.toInt() else 0xFF92400E.toInt()
    val bluBg = if (gelap) 0xFF1E3A5F.toInt() else 0xFFDCEBFF.toInt()
    val bluTx = if (gelap) 0xFF9CC9FF.toInt() else 0xFF0B4A99.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bentuk(isi: Int, radiusDp: Int, garis: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(isi)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (garis != 0) g.setStroke(dp(1), garis)
    return g
}

fun Context.teks(s: String, ukuranSp: Float, warna: Int, tebal: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, ukuranSp)
    t.setTextColor(warna)
    if (tebal) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

// gaya: 0 = utama (terisi), 1 = bergaris, 2 = pilihan, 3 = kartu (isi surf + garis)
fun Context.tombol(label: String, pal: Pal, gaya: Int, ikon: Int = 0, klik: () -> Unit): Button {
    val b = Button(this)
    b.text = label
    b.isAllCaps = false
    b.stateListAnimator = null
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    b.typeface = Typeface.DEFAULT_BOLD
    when (gaya) {
        0 -> {
            b.background = bentuk(pal.acc, 14)
            b.setTextColor(pal.onAcc)
        }
        1 -> {
            b.background = bentuk(0, 14, pal.bd)
            b.setTextColor(pal.tx)
        }
        3 -> {
            b.background = bentuk(pal.surf, 12, pal.bd)
            b.setTextColor(pal.tx)
        }
        else -> {
            b.background = bentuk(pal.surf2, 12)
            b.setTextColor(pal.tx)
        }
    }
    b.minHeight = dp(48)
    b.minimumHeight = dp(48)
    if (ikon != 0) pasangIkon(b, ikon, b.currentTextColor)
    b.setOnClickListener { klik() }
    return b
}

fun Context.pasangIkon(b: Button, ikon: Int, warna: Int) {
    if (ikon == 0) {
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
        return
    }
    val d = getDrawable(ikon)?.mutate()
    d?.setTint(warna)
    b.setCompoundDrawablesRelativeWithIntrinsicBounds(d, null, null, null)
    b.compoundDrawablePadding = dp(8)
}

fun Context.garisBawah(pal: Pal): View {
    val v = View(this)
    v.setBackgroundColor(pal.bd)
    v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    return v
}

fun Context.kartu(pal: Pal, padBawahDp: Int = 14): LinearLayout {
    val k = LinearLayout(this)
    k.orientation = LinearLayout.VERTICAL
    k.background = bentuk(pal.surf, 16, pal.bd)
    k.setPadding(dp(16), dp(14), dp(16), dp(padBawahDp))
    return k
}

// gaya: 0 = akun, 1 = biru (pertandingan, hero, tower), 2 = amber (tanda, BARU),
//       3 = dikenal (transparan bergaris), 4 = otomatis
fun Context.chipTeks(pal: Pal, isi: String, gaya: Int): TextView {
    val t = TextView(this)
    t.text = isi
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
    t.typeface = Typeface.DEFAULT_BOLD
    t.setPadding(dp(7), dp(2), dp(7), dp(2))
    when (gaya) {
        1 -> {
            t.setTextColor(pal.bluTx)
            t.background = bentuk(pal.bluBg, 6)
        }
        2 -> {
            t.setTextColor(pal.ambTx)
            t.background = bentuk(pal.ambBg, 6)
        }
        3 -> {
            t.setTextColor(pal.mu)
            t.background = bentuk(0, 6, pal.bd)
        }
        4 -> {
            t.setTextColor(pal.acc)
            t.background = bentuk(pal.surf2, 6, pal.bd)
        }
        else -> {
            t.setTextColor(pal.tx)
            t.background = bentuk(pal.surf2, 6, pal.bd)
        }
    }
    return t
}

fun Context.barisCentang(
    pal: Pal,
    label: String,
    ket: String,
    nyala: Boolean,
    aktif: Boolean,
    ubah: (Boolean) -> Unit
): LinearLayout {
    val baris = LinearLayout(this)
    baris.orientation = LinearLayout.HORIZONTAL
    baris.gravity = Gravity.CENTER_VERTICAL
    baris.minimumHeight = dp(48)
    val cb = CheckBox(this)
    cb.isChecked = nyala
    cb.isEnabled = aktif
    cb.buttonTintList = ColorStateList.valueOf(if (aktif) pal.acc else pal.mu)
    cb.setOnCheckedChangeListener { _, ok -> ubah(ok) }
    baris.addView(cb)
    baris.addView(teks(label, 14f, if (aktif) pal.tx else pal.mu), lp(lebar = 0, bobot = 1f))
    baris.addView(teks(ket, 12f, pal.mu))
    return baris
}

fun lp(
    lebar: Int = ViewGroup.LayoutParams.MATCH_PARENT,
    tinggi: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
    bobot: Float = 0f,
    kiri: Int = 0,
    atas: Int = 0,
    kanan: Int = 0,
    bawah: Int = 0
): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(lebar, tinggi, bobot)
    p.setMargins(kiri, atas, kanan, bawah)
    return p
}
