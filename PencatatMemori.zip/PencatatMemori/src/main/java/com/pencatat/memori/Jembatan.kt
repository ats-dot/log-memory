package com.pencatat.memori

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

// Jembatan antara tampilan (HTML di WebView) dan mesin. Semua method dipanggil dari thread WebView, bukan thread utama.
class Jembatan(private val a: MainActivity) {

    private val ctx: Context get() = a.applicationContext

    @JavascriptInterface
    fun state(): String {
        val o = JSONObject()
        val jalan = Engine.running
        o.put("run", jalan)
        o.put("status", Engine.status)
        o.put("total", if (Engine.total > 0) Engine.total else Prefs.serverTotal)
        o.put("done", Engine.doneCount)
        o.put("acct", Prefs.accountsDoneToday().size)
        o.put("freeze", Engine.freezeCount)
        val t0 = Engine.startedAt
        o.put("dur", if (t0 == 0L) 0L else (if (jalan) System.currentTimeMillis() else Engine.endedAt.takeIf { it > 0 } ?: System.currentTimeMillis()) - t0)

        val svc = JSONArray()
        svc.put(JSONArray().put("Aksesibilitas").put(if (AutoService.inst != null) "Aktif" else "Mati").put(if (AutoService.inst != null) "ok" else "er"))
        val shz = try {
            if (!ShizukuHelper.isRunning()) arrayOf("Tidak jalan", "er")
            else if (!ShizukuHelper.hasPermission()) arrayOf("Belum diizinkan", "wa")
            else arrayOf("Siap", "ok")
        } catch (e: Throwable) { arrayOf("Tidak jalan", "er") }
        svc.put(JSONArray().put("Shizuku").put(shz[0]).put(shz[1]))
        svc.put(JSONArray().put("Penjaga latar").put(if (jalan) "Berjalan" else "Diam").put(if (jalan) "ok" else "dm"))
        val tm = Cheat.tulisTerbukti
        svc.put(JSONArray().put("Tulis memori").put(if (tm == true) "Terbukti masuk" else if (tm == false) "Tidak masuk" else "Belum dicoba").put(if (tm == true) "ok" else if (tm == false) "er" else "dm"))
        val game = if (!Cheat.aktif) "-" else (if (Cheat.statusGame != "-" && Cheat.statusGame.isNotBlank()) Cheat.statusGame else Cheat.statusTeks)
        svc.put(JSONArray().put("Game").put(game).put(if (game == "Play") "ok" else if (game == "-") "dm" else "wa"))
        o.put("svc", svc)

        val f = JSONArray()
        for (x in Prefs.activeFeatures()) f.put(x)
        o.put("feat", f)
        return o.toString()
    }

    @JavascriptInterface
    fun toggleRun() {
        a.runOnUiThread {
            if (Engine.running) {
                Engine.stop()
            } else {
                try {
                    if (ShizukuHelper.isRunning() && !ShizukuHelper.hasPermission()) ShizukuHelper.requestPermission()
                } catch (_: Throwable) {}
                Engine.start(a)
            }
        }
    }

    // ── Log ──
    @JavascriptInterface
    fun logSince(seq: String, epoch: Int): String {
        val o = JSONObject()
        val reset = epoch != AppLog.epoch
        val dari = if (reset) 0L else (seq.toLongOrNull() ?: 0L)
        val (sq, baris) = AppLog.sejak(dari)
        val ambil = if (baris.size > 400) baris.takeLast(400) else baris
        o.put("epoch", AppLog.epoch)
        o.put("seq", sq)
        val arr = JSONArray()
        for (x in ambil) arr.put(x)
        o.put("lines", arr)
        return o.toString()
    }

    @JavascriptInterface
    fun archives(): String {
        val arr = JSONArray()
        val l = AppLog.getArchives()
        for (i in l.indices.reversed()) {
            val x = l[i]
            val galat = x.lines.count { Regex("crash|galat|gagal|error|exception", RegexOption.IGNORE_CASE).containsMatchIn(it) }
            arr.put(JSONObject().put("i", i).put("t", "Server " + x.serverName).put("s", "${x.timestamp} · ${x.lines.size} baris · $galat galat"))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun archive(i: Int): String {
        val x = AppLog.getArchive(i) ?: return "[]"
        val arr = JSONArray()
        for (s in x.lines) arr.put(s)
        return arr.toString()
    }

    @JavascriptInterface
    fun copyLog(mode: Int, idx: Int): String {
        val t = if (mode == 0) AppLog.text() else if (idx >= 0) AppLog.archiveText(idx) else AppLog.archiveSummary()
        a.runOnUiThread {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", t))
        }
        return "Log disalin"
    }

    @JavascriptInterface
    fun clearLog(mode: Int) {
        if (mode == 0) AppLog.clear() else AppLog.clearArchives()
    }

    // ── Konfigurasi cheat ──
    @JavascriptInterface
    fun cfg(): String = CheatCfg.json()

    @JavascriptInterface
    fun setCfg(path: String, kind: String, v: String) {
        when (kind) {
            "b" -> CheatCfg.setBool(path, v == "1")
            "i" -> CheatCfg.set(path, v.trim().toIntOrNull())
            "s" -> CheatCfg.set(path, if (v.isBlank()) null else v.trim())
            "r" -> {
                val p = v.split(',')
                CheatCfg.setRentang(path, p.getOrNull(0)?.trim()?.toIntOrNull(), p.getOrNull(1)?.trim()?.toIntOrNull())
            }
        }
        CheatCfg.simpan()
    }

    // ── Pengaturan aplikasi ──
    @JavascriptInterface
    fun prefs(): String {
        val o = JSONObject()
        o.put("pkg", Prefs.pkg); o.put("mlLabel", Prefs.mlLabel); o.put("launchCmd", Prefs.launchCmd)
        o.put("serverTotal", Prefs.serverTotal); o.put("idMin", Prefs.idMin); o.put("idMax", Prefs.idMax)
        o.put("afterDone", Prefs.afterDone); o.put("scrollDir", Prefs.scrollDir)
        o.put("swipeHardMs", Prefs.swipeHardMs); o.put("swipeStart", Prefs.swipeStart); o.put("swipeEnd", Prefs.swipeEnd); o.put("swipeX", Prefs.swipeX)
        o.put("swipeSlowMs", Prefs.swipeSlowMs); o.put("swipeSlowStart", Prefs.swipeSlowStart); o.put("swipeSlowEnd", Prefs.swipeSlowEnd)
        o.put("swipeBackMs", Prefs.swipeBackMs); o.put("swipeBackStart", Prefs.swipeBackStart); o.put("swipeBackEnd", Prefs.swipeBackEnd)
        o.put("stepMs", Prefs.stepMs); o.put("lobbyWait", Prefs.lobbyWait); o.put("lobbyCalm", Prefs.lobbyCalm); o.put("serverMaxLevel", Prefs.serverMaxLevel); o.put("lagSec", Prefs.lagSec)
        o.put("ocrScale", Prefs.ocrScale); o.put("dotAuto", Prefs.dotAuto); o.put("turretTaps", Prefs.turretTaps)
        o.put("featLevelCheck", Prefs.featLevelCheck); o.put("featPlayGame", Prefs.featPlayGame)
        o.put("featClaimEvent", Prefs.featClaimEvent); o.put("featKlaimTcp", Prefs.featKlaimTcp); o.put("featSwitchServer", Prefs.featSwitchServer)
        o.put("featCheatOnly", Prefs.featCheatOnly)
        return o.toString()
    }

    @JavascriptInterface
    fun setPref(k: String, v: String) {
        val n = v.trim().toIntOrNull()
        val b = v == "1" || v == "true"
        when (k) {
            "pkg" -> Prefs.pkg = v.trim()
            "mlLabel" -> Prefs.mlLabel = v.trim()
            "launchCmd" -> Prefs.launchCmd = v.trim()
            "serverTotal" -> if (n != null) Prefs.serverTotal = n
            "idMin" -> Prefs.idMin = n ?: 0
            "idMax" -> Prefs.idMax = n ?: 0
            "afterDone" -> if (n != null) Prefs.afterDone = n
            "scrollDir" -> if (n != null) Prefs.scrollDir = n
            "swipeHardMs" -> if (n != null) Prefs.swipeHardMs = n
            "swipeStart" -> if (n != null) Prefs.swipeStart = n
            "swipeEnd" -> if (n != null) Prefs.swipeEnd = n
            "swipeX" -> if (n != null) Prefs.swipeX = n
            "swipeSlowMs" -> if (n != null) Prefs.swipeSlowMs = n
            "swipeSlowStart" -> if (n != null) Prefs.swipeSlowStart = n
            "swipeSlowEnd" -> if (n != null) Prefs.swipeSlowEnd = n
            "swipeBackMs" -> if (n != null) Prefs.swipeBackMs = n
            "swipeBackStart" -> if (n != null) Prefs.swipeBackStart = n
            "swipeBackEnd" -> if (n != null) Prefs.swipeBackEnd = n
            "stepMs" -> if (n != null) Prefs.stepMs = n.toLong()
            "lobbyWait" -> if (n != null) Prefs.lobbyWait = n
            "lobbyCalm" -> if (n != null) Prefs.lobbyCalm = n
            "serverMaxLevel" -> if (n != null) Prefs.serverMaxLevel = n
            "lagSec" -> if (n != null) Prefs.lagSec = n
            "ocrScale" -> if (n != null) Prefs.ocrScale = n.coerceIn(20, 100)
            "turretTaps" -> if (n != null) Prefs.turretTaps = n
            "dotAuto" -> Prefs.dotAuto = b
            "featLevelCheck" -> Prefs.featLevelCheck = b
            "featPlayGame" -> Prefs.featPlayGame = b
            "featClaimEvent" -> Prefs.featClaimEvent = b
            "featKlaimTcp" -> Prefs.featKlaimTcp = b
            "featSwitchServer" -> Prefs.featSwitchServer = b
            "featCheatOnly" -> Prefs.featCheatOnly = b
        }
    }

    // ── Template ──
    @JavascriptInterface
    fun templates(): String {
        val arr = JSONArray()
        for (n in CheatCfg.daftarTemplate()) arr.put(n)
        return arr.toString()
    }

    @JavascriptInterface
    fun tplSave(nama: String): Boolean = CheatCfg.simpanTemplate(nama)

    @JavascriptInterface
    fun tplUse(nama: String): Boolean = CheatCfg.terapkanTemplate(nama)

    @JavascriptInterface
    fun tplDel(nama: String) = CheatCfg.hapusTemplate(nama)

    @JavascriptInterface
    fun tplDefault() = CheatCfg.kembalikanBawaan()

    // ── Tindakan ──
    @JavascriptInterface
    fun act(nama: String): String {
        when (nama) {
            "diagMultiRun" -> { Engine.diagnosaMultiRun(ctx); return "Hasilnya ada di tab Log" }
            "ujiGeser" -> {
                if (!Engine.running) { Engine.ujiGeser(ctx); return "Uji dimulai, lihat tab Log" }
                return "Berhentikan otomasi dulu"
            }
            "ujiTitik" -> {
                if (!Engine.running) { Engine.ujiTitik(ctx); return "Uji dimulai, pindah ke game, hasil di tab Log" }
                return "Berhentikan otomasi dulu"
            }
            "resetSwipe" -> { Prefs.resetSwipe(); return "Angka geser dikembalikan" }
            "aksesOtomatis" -> {
                val app = ctx
                Thread {
                    val ok = AutoAccess.siapkan(app, 8000) { AppLog.add(it) }
                    AppLog.add(if (ok) "Aksesibilitas menyala" else "Aksesibilitas belum berhasil dinyalakan")
                }.apply { isDaemon = true; start() }
                return "Menyalakan, lihat tab Log"
            }
            "izinShizuku" -> {
                return try {
                    if (!ShizukuHelper.isRunning()) "Shizuku belum jalan"
                    else { a.runOnUiThread { ShizukuHelper.requestPermission() }; "Izin diminta" }
                } catch (e: Throwable) { "Shizuku tidak tersedia" }
            }
            "bukaAkses" -> {
                a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                return "Membuka"
            }
            else -> {
                if (!Cheat.aktif && nama != "dodUlang" && nama != "antiResUlang") {
                    Cheat.minta(nama)
                    return "Diminta, tapi mesin cheat belum jalan. Tekan MULAI dulu"
                }
                Cheat.minta(nama)
                return "Diminta"
            }
        }
    }
}
