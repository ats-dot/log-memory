package com.pencatat.memori

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Satu baris hasil Mode cari
class Hasil(
    val kategori: Int,        // 0 = berubah sekali, 1 = seperti penghitung
    val area: String,         // AKUN, PERTANDINGAN, HERO, TOWER
    val kodeOff: String,      // "" atau "E" / "A" (khusus tower)
    val offset: Int,          // offset kata 4-byte
    val nama: String?,        // nama field kalau dikenal
    val lama: String,
    val baru: String,
    val waktuMs: Long,
    val gameMs: Long,         // waktu game saat itu (ms), -1 = belum ada
    val ket: String?,
    val tagBaru: Boolean,     // true = belum ada di tabel script
    val skor: Long,           // makin kecil makin mirip flag
    var centang: Boolean
)

// Statistik per kata 4-byte untuk satu objek
class StatArea(
    val area: String,
    val kodeOff: String,
    val alamat: Long,
    val label: String?,
    panjang: Int
) {
    val n = panjang / 4
    val awal = IntArray(n)
    val prev = IntArray(n)
    val jumlah = IntArray(n)
    val tPertama = LongArray(n)
    val tAkhir = LongArray(n)
    val gPertama = LongArray(n)
    val gAkhir = LongArray(n)
    val arah = ByteArray(n)        // bit 0 = pernah naik, bit 1 = pernah turun
    var terisi = false
}

// Mode cari: membaca objek penuh berulang-ulang, mengumpulkan statistik perubahan tiap kata,
// lalu memisahkan nilai yang berubah satu kali / seperti penghitung dari gangguan.
object Penelusur {

    private val stat = LinkedHashMap<String, StatArea>()

    @Volatile var sampel = 0
    @Volatile var berubah = 0
    @Volatile var gangguan = 0
    @Volatile var siap = false
    @Volatile var hasil: List<Hasil> = emptyList()
    @Volatile var mulaiWall = 0L
    @Volatile var akhirWall = 0L
    @Volatile var akhirMs = 0L
    @Volatile var jumlahTower = 0

    @Synchronized
    fun reset() {
        stat.clear()
        sampel = 0
        berubah = 0
        gangguan = 0
        siap = false
        hasil = emptyList()
        mulaiWall = System.currentTimeMillis()
        akhirWall = 0L
        akhirMs = 0L
        jumlahTower = 0
    }

    // LBM berganti (match baru): objek lama tidak bisa dibandingkan dengan yang baru
    @Synchronized
    fun buangObjek() {
        val buang = ArrayList<String>()
        for (k in stat.keys) {
            if (!k.startsWith("AKUN|")) buang.add(k)
        }
        for (k in buang) stat.remove(k)
    }

    @Synchronized
    fun serap(area: String, kodeOff: String, alamat: Long, label: String?, blok: ByteArray, tMs: Long, gMs: Long) {
        val kunci = area + "|" + kodeOff + "|" + alamat
        var s = stat[kunci]
        if (s == null || s.n != blok.size / 4) {
            s = StatArea(area, kodeOff, alamat, label, blok.size)
            stat[kunci] = s
            if (area == "TOWER" && kodeOff == "E") jumlahTower++
        }
        val n = s.n
        if (!s.terisi) {
            for (i in 0 until n) {
                val v = Daftar.le32(blok, i * 4)
                s.awal[i] = v
                s.prev[i] = v
            }
            s.terisi = true
            return
        }
        for (i in 0 until n) {
            val v = Daftar.le32(blok, i * 4)
            val p = s.prev[i]
            if (v != p) {
                if (s.jumlah[i] == 0) {
                    s.tPertama[i] = tMs
                    s.gPertama[i] = gMs
                    berubah++
                }
                s.jumlah[i]++
                s.tAkhir[i] = tMs
                s.gAkhir[i] = gMs
                s.arah[i] = (s.arah[i].toInt() or (if (v > p) 1 else 2)).toByte()
                s.prev[i] = v
            }
        }
    }

    fun mmss(ms: Long): String {
        val d = ms / 1000
        return String.format(Locale.US, "%02d:%02d", d / 60, d % 60)
    }

    // -1 = gangguan (disembunyikan), 0 = berubah sekali, 1 = seperti penghitung
    private fun kategori(s: StatArea, i: Int): Int {
        val j = s.jumlah[i]
        if (j == 1) return 0
        val diam = akhirMs - s.tAkhir[i] >= 3000
        if (!diam) return -1
        val campur = s.arah[i].toInt() == 3
        if (!campur) return 1
        if (j <= 4) return 0
        return -1
    }

    private fun daftarKenal(area: String, kodeOff: String): List<Bidang> = when (area) {
        "AKUN" -> Daftar.AKUN
        "PERTANDINGAN" -> Daftar.MATCH
        "HERO" -> Daftar.HERO
        else -> if (kodeOff == "A") Daftar.TOWER_A else Daftar.TOWER_E
    }

    private fun fmtKata(k: Bidang?, off: Int, v: Int): String {
        if (k != null && k.off == off) {
            if (k.jenis == 2) return Daftar.fmt(k, v.toLong())
            if (k.jenis == 1) return "0x" + Integer.toHexString(v)
        }
        return v.toString()
    }

    private fun urutArea(a: String): Int = when (a) {
        "PERTANDINGAN" -> 0
        "AKUN" -> 1
        "HERO" -> 2
        else -> 3
    }

    private fun bentuk(s: StatArea, i: Int, kat: Int, jumlahTower: Int): Hasil {
        val off = i * 4
        val k = Daftar.kenal(daftarKenal(s.area, s.kodeOff), off)
        val lama = fmtKata(k, off, s.awal[i])
        val baru = fmtKata(k, off, s.prev[i])
        val j = s.jumlah[i]
        var ket: String? = null
        if (kat == 0 && j > 1) ket = "kedip " + j + "x"
        if (jumlahTower > 0) {
            val t = "$jumlahTower tower"
            ket = if (ket == null) t else "$t, $ket"
        }
        val skor = maxOf(Math.abs(s.awal[i].toLong()), Math.abs(s.prev[i].toLong()))
        val waktu = if (kat == 1) s.tAkhir[i] else s.tPertama[i]
        val gw = if (kat == 1) s.gAkhir[i] else s.gPertama[i]
        var nama: String? = null
        if (k != null) nama = if (k.off == off) k.nama else k.nama + "*"
        return Hasil(kat, s.area, s.kodeOff, off, nama, lama, baru, waktu, gw, ket, k == null, skor, true)
    }

    // Hitung hasil akhir (dipanggil sekali saat pencarian dihentikan)
    @Synchronized
    fun selesai(tMs: Long) {
        akhirMs = tMs
        akhirWall = System.currentTimeMillis()
        val daftar = ArrayList<Hasil>()
        var ganggu = 0
        // Tower digabung per (E/A, kata): satu baris untuk semua tower
        val menara = LinkedHashMap<String, ArrayList<Pair<StatArea, Int>>>()
        for (s in stat.values) {
            for (i in 0 until s.n) {
                if (s.jumlah[i] == 0) continue
                if (s.area == "TOWER") {
                    val key = s.kodeOff + "|" + i
                    var l = menara[key]
                    if (l == null) {
                        l = ArrayList()
                        menara[key] = l
                    }
                    l.add(Pair(s, i))
                    continue
                }
                val kat = kategori(s, i)
                if (kat < 0) ganggu++ else daftar.add(bentuk(s, i, kat, 0))
            }
        }
        for (l in menara.values) {
            var wakil = l[0]
            for (pr in l) {
                if (pr.first.tPertama[pr.second] < wakil.first.tPertama[wakil.second]) wakil = pr
            }
            val kat = kategori(wakil.first, wakil.second)
            if (kat < 0) ganggu++ else daftar.add(bentuk(wakil.first, wakil.second, kat, l.size))
        }
        daftar.sortWith(compareBy({ it.kategori }, { it.skor }, { urutArea(it.area) }, { it.offset }))
        hasil = daftar
        gangguan = ganggu
        siap = true
    }

    fun namaOffset(h: Hasil): String = (if (h.kodeOff.isEmpty()) "" else h.kodeOff) + "+" + h.offset

    // Teks laporan lengkap (untuk berkas yang dibagikan)
    fun laporan(): String {
        val tgl = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val sb = StringBuilder()
        sb.append("# Pencatat Memori, hasil Mode cari\n")
        sb.append("# mulai ").append(tgl.format(Date(mulaiWall))).append(", selesai ").append(tgl.format(Date(akhirWall))).append("\n")
        sb.append("# sampel=").append(sampel).append(" alamat_berubah=").append(berubah)
        sb.append(" gangguan_disembunyikan=").append(gangguan).append(" tower=").append(jumlahTower).append("\n")
        sb.append("# offset = kata 4-byte; E = objek tower, A = objek atribut tower; nilai desimal (bertanda)\n")
        sb.append("# @mm:ss = jam sejak pencarian dimulai; g = waktu game (detik, dari m_uiFrameTime)\n")
        for (kat in 0..1) {
            sb.append(if (kat == 0) "\n== BERUBAH SEKALI ==\n" else "\n== SEPERTI PENGHITUNG (berubah lalu diam) ==\n")
            for (h in hasil) {
                if (h.kategori != kat) continue
                sb.append(h.area).append(' ').append(namaOffset(h)).append(' ')
                sb.append(h.nama ?: "(belum dikenal)").append("  ").append(h.lama).append(" -> ").append(h.baru)
                sb.append(if (kat == 1) "  diam sejak @" else "  @").append(mmss(h.waktuMs))
                if (h.gameMs >= 0) sb.append(" g=").append(String.format(Locale.US, "%.1f", h.gameMs / 1000.0))
                if (h.ket != null) sb.append("  (").append(h.ket).append(')')
                sb.append(if (h.tagBaru) "  [BARU]" else "  [DIKENAL]").append('\n')
            }
        }
        return sb.toString()
    }
}
