package com.pencatat.memori

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private lateinit var sp: SharedPreferences
    private val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.US)

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("auto_up_lvl", Context.MODE_PRIVATE)
    }

    // Offset slot kelas game yang terakhir ditemukan scan (dipelajari otomatis, dipakai sebagai hint cepat)
    fun hintBelajar(nama: String): Long = try { sp.getLong("hint_$nama", 0L) } catch (e: Throwable) { 0L }
    fun simpanHintBelajar(nama: String, v: Long) { try { sp.edit().putLong("hint_$nama", v).apply() } catch (_: Throwable) {} }

    // ── Paket game ──
    var pkg: String
        get() = sp.getString("pkg", "com.dong.multirun") ?: "com.dong.multirun"
        set(v) = sp.edit().putString("pkg", v).apply()

    // ── Buka game lewat Multi Run ──
    // Perintah shell opsional untuk membuka ML langsung (mis. "am start -n paket/.Activity"). Kosong = ketuk entri otomatis.
    var launchCmd: String
        get() = sp.getString("launchCmd", "") ?: ""
        set(v) = sp.edit().putString("launchCmd", v).apply()

    // Teks entri ML di daftar Multi Run (regex, tidak peka huruf besar-kecil)
    var mlLabel: String
        get() = sp.getString("mlLabel", "mobile legends|mlbb") ?: "mobile legends|mlbb"
        set(v) = sp.edit().putString("mlLabel", v).apply()

    // ── Server ──
    // Jumlah server di daftar (termasuk server yang sedang dipakai)
    var serverTotal: Int
        get() = sp.getInt("serverTotal", 10)
        set(v) = sp.edit().putInt("serverTotal", v.coerceIn(1, 200)).apply()

    val serverCount: Int get() = serverTotal

    // Rentang nomor server yang sah (0 = semua nomor 4-6 digit diterima)
    var idMin: Int
        get() = sp.getInt("idMin", 0)
        set(v) = sp.edit().putInt("idMin", v.coerceAtLeast(0)).apply()

    var idMax: Int
        get() = sp.getInt("idMax", 0)
        set(v) = sp.edit().putInt("idMax", v.coerceAtLeast(0)).apply()

    // ── Timing ──
    var stepMs: Long
        get() = sp.getLong("stepMs", 400L)
        set(v) = sp.edit().putLong("stepMs", v).apply()

    // Jeda di lobi (ms): lama menunggu popup muncul setelah lobi terlihat, sebelum langkah berikutnya (sama seperti claim-vg)
    var lobbyCalm: Int
        get() = sp.getInt("lobbyCalm", 3000)
        set(v) = sp.edit().putInt("lobbyCalm", v.coerceIn(0, 30000)).apply()

    // Server dengan level akun di atas angka ini dilewati (level dibaca dari kolom kanan daftar karakter)
    var serverMaxLevel: Int
        get() = sp.getInt("serverMaxLevel", 3)
        set(v) = sp.edit().putInt("serverMaxLevel", v.coerceIn(1, 999)).apply()

    var lobbyWait: Int
        get() = sp.getInt("lobbyWait", 180)
        set(v) = sp.edit().putInt("lobbyWait", v).apply()

    // ── Geser daftar server (persen tinggi/lebar layar, 0 di atas, 100 di bawah) — nilai bawaan sama dengan claim-vg ──
    var swipeHardMs: Int
        get() = sp.getInt("swipe_hard_ms", 50)
        set(v) = sp.edit().putInt("swipe_hard_ms", v.coerceIn(40, 400)).apply()
    var swipeStart: Int
        get() = sp.getInt("swipe_start", 55)
        set(v) = sp.edit().putInt("swipe_start", v.coerceIn(20, 95)).apply()
    var swipeEnd: Int
        get() = sp.getInt("swipe_end", 10)
        set(v) = sp.edit().putInt("swipe_end", v.coerceIn(0, 60)).apply()
    var swipeX: Int
        get() = sp.getInt("swipe_x", 77)
        set(v) = sp.edit().putInt("swipe_x", v.coerceIn(10, 95)).apply()
    var swipeSlowMs: Int
        get() = sp.getInt("swipe_slow_ms", 170)
        set(v) = sp.edit().putInt("swipe_slow_ms", v.coerceIn(100, 1000)).apply()
    var swipeSlowStart: Int
        get() = sp.getInt("swipe_slow_start", 58)
        set(v) = sp.edit().putInt("swipe_slow_start", v.coerceIn(0, 100)).apply()
    var swipeSlowEnd: Int
        get() = sp.getInt("swipe_slow_end", 45)
        set(v) = sp.edit().putInt("swipe_slow_end", v.coerceIn(0, 100)).apply()
    var swipeBackStart: Int
        get() = sp.getInt("swipe_back_start", 45)
        set(v) = sp.edit().putInt("swipe_back_start", v.coerceIn(0, 100)).apply()
    var swipeBackEnd: Int
        get() = sp.getInt("swipe_back_end", 58)
        set(v) = sp.edit().putInt("swipe_back_end", v.coerceIn(0, 100)).apply()
    var swipeBackMs: Int
        get() = sp.getInt("swipe_back_ms", 200)
        set(v) = sp.edit().putInt("swipe_back_ms", v.coerceIn(100, 1000)).apply()

    fun resetSwipe() {
        swipeHardMs = 50; swipeStart = 55; swipeEnd = 10; swipeX = 77
        swipeSlowMs = 170; swipeSlowStart = 58; swipeSlowEnd = 45
        swipeBackStart = 45; swipeBackEnd = 58; swipeBackMs = 200
    }

    // ── Titik melayang (supaya OCR cepat saat aplikasi di latar) ──
    // 0 tanpa, 1 putih 14dp, 2 putih 2dp, 3 putih transparan 5%, 4 1 piksel tanpa warna, 5 14dp tanpa warna
    var dotStyle: Int
        get() = sp.getInt("dot_style", 5)
        set(v) = sp.edit().putInt("dot_style", v).apply()

    var dotAuto: Boolean
        get() = sp.getBoolean("dot_auto", true)
        set(v) = sp.edit().putBoolean("dot_auto", v).apply()

    // ── Lag detection ──
    var lagSec: Int
        get() = sp.getInt("lagSec", 60)
        set(v) = sp.edit().putInt("lagSec", v).apply()

    // ── OCR ──
    var ocrScale: Int
        get() = sp.getInt("ocrScale", 60)
        set(v) = sp.edit().putInt("ocrScale", v).apply()

    // ── Avatar position ──
    var avatarX: Float
        get() = sp.getFloat("avatarX", 0.06f)
        set(v) = sp.edit().putFloat("avatarX", v).apply()

    var avatarY: Float
        get() = sp.getFloat("avatarY", 0.056f)
        set(v) = sp.edit().putFloat("avatarY", v).apply()

    // ── Lobby keys ──
    var lobbyKeys: String
        get() = sp.getString("lobbyKeys", "mulairank,classic,brawl,peringkat") ?: "mulairank,classic,brawl,peringkat"
        set(v) = sp.edit().putString("lobbyKeys", v).apply()

    val lobbyKeyList: List<String> get() = lobbyKeys.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    // ── Turret taps ──
    var turretTaps: Int
        get() = sp.getInt("turretTaps", 5)
        set(v) = sp.edit().putInt("turretTaps", v).apply()

    // ── After done ──
    var afterDone: Int
        get() = sp.getInt("afterDone", 1)
        set(v) = sp.edit().putInt("afterDone", v).apply()

    // ── Feature toggles (automation steps) ──
    var featLevelCheck: Boolean
        get() = sp.getBoolean("featLevelCheck", true)
        set(v) = sp.edit().putBoolean("featLevelCheck", v).apply()

    var featPlayGame: Boolean
        get() = sp.getBoolean("featPlayGame", true)
        set(v) = sp.edit().putBoolean("featPlayGame", v).apply()

    var featClaimEvent: Boolean
        get() = sp.getBoolean("featClaimEvent", true)
        set(v) = sp.edit().putBoolean("featClaimEvent", v).apply()

    // Klaim via TCP (kirim paket langsung, skip navigasi UI Event).
    // Default OFF — pakai UI klaim. ON — pakai full TCP klaim.
    var featKlaimTcp: Boolean
        get() = sp.getBoolean("featKlaimTcp", false)
        set(v) = sp.edit().putBoolean("featKlaimTcp", v).apply()

    var featSwitchServer: Boolean
        get() = sp.getBoolean("featSwitchServer", true)
        set(v) = sp.edit().putBoolean("featSwitchServer", v).apply()

    // Mode Cheat Only: semua langkah otomatis mati, hanya cheat yang aktif saat masuk lobby
    var featCheatOnly: Boolean
        get() = sp.getBoolean("featCheatOnly", false)
        set(v) = sp.edit().putBoolean("featCheatOnly", v).apply()

    // ── Scroll direction ──
    var scrollDir: Int
        get() = sp.getInt("scrollDir", 0)
        set(v) = sp.edit().putInt("scrollDir", v).apply()

    fun activeFeatures(): List<String> {
        val C = CheatCfg
        val l = mutableListOf<String>()
        if (C.b("isAuto")) l.add("Cheat Otomatis")
        if (C.b("dodIndicator")) l.add("DOD")
        if (C.b("attribute.autoAttr")) l.add("Attribut")
        if (C.b("selfKda.auto") || C.b("teamKda.auto") || C.b("enemyKda.auto")) l.add("Kill Death Assist")
        if (C.b("selfStat.auto") || C.b("teamStat.auto") || C.b("enemyStat.auto")) l.add("Statistik")
        if (C.b("autoSkipTime")) l.add("Lompat Waktu")
        if (C.b("autoEnd")) l.add("Auto end")
        if (C.b("autoStopMinion")) l.add("Stop Minion")
        if (C.b("cheatHealthTower")) l.add("HP Tower")
        if (C.b("teleportTower")) l.add("Teleport Tower")
        if (C.b("isIAmLose")) l.add("Set Ke Kalah")
        if (C.b("isQuickMode")) l.add("Quick Mode")
        return l
    }

    // ── Progress tracking ──
    private fun today(): String = dayFmt.format(Date())

    fun doneToday(acct: String): Set<String> {
        val key = "done_${today()}_$acct"
        return sp.getStringSet(key, emptySet()) ?: emptySet()
    }

    fun addDone(server: String, acct: String) {
        val key = "done_${today()}_$acct"
        val set = HashSet(doneToday(acct))
        set.add(server)
        sp.edit().putStringSet(key, set).apply()
    }

    fun removeDone(server: String, acct: String) {
        val key = "done_${today()}_$acct"
        val set = HashSet(doneToday(acct))
        set.remove(server)
        sp.edit().putStringSet(key, set).apply()
    }

    fun markAccountDone(acct: String) {
        val key = "acctDone_${today()}"
        val set = HashSet(sp.getStringSet(key, emptySet()) ?: emptySet())
        set.add(acct)
        sp.edit().putStringSet(key, set).apply()
    }

    fun accountsDoneToday(): Set<String> {
        return sp.getStringSet("acctDone_${today()}", emptySet()) ?: emptySet()
    }

    fun purgeOld() {
        val td = today()
        val ed = sp.edit()
        for (k in sp.all.keys) {
            if ((k.startsWith("done_") || k.startsWith("acctDone_")) && !k.contains(td)) {
                ed.remove(k)
            }
        }
        ed.apply()
    }

    fun fmt(n: Int): String {
        val s = n.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) sb.append('.')
            sb.append(s[i])
        }
        return sb.toString()
    }
}
