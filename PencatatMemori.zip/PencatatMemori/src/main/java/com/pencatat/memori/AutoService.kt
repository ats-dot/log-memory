package com.pencatat.memori

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.View
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class AutoService : AccessibilityService() {

    companion object {
        @Volatile var inst: AutoService? = null
    }

    // Callback screenshot diproses di thread sendiri, bukan thread utama
    private val shotExec = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() {
        inst = this
        AppLog.add("Accessibility Service terhubung")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        inst = null
        AppLog.add("Accessibility Service terputus")
        super.onDestroy()
    }

    // ── Screenshot (disalin dari claim-vg) ──
    // Alasan kegagalan terakhir (kosong = berhasil)
    @Volatile var lastShotError: String = ""

    private fun errName(code: Int): String = when (code) {
        1 -> "kesalahan internal sistem"
        2 -> "tidak ada akses aksesibilitas"
        3 -> "terlalu cepat setelah screenshot sebelumnya"
        4 -> "layar tidak valid"
        5 -> "jendela tidak valid"
        6 -> "jendela dilindungi (FLAG_SECURE)"
        else -> "kode tidak dikenal"
    }

    fun shot(): Bitmap? {
        val t0 = System.currentTimeMillis()
        val latch = CountDownLatch(1)
        val out = AtomicReference<Bitmap?>(null)
        val err = AtomicReference<String?>(null)
        val abandoned = AtomicBoolean(false)
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                shotExec,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val hb = result.hardwareBuffer
                        try {
                            if (abandoned.get()) {
                                AppLog.add("Screenshot datang TERLAMBAT (" + (System.currentTimeMillis() - t0) + " ms), dibuang")
                            } else {
                                val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                                if (hw == null) {
                                    err.set("hasil screenshot tidak bisa dibaca (wrapHardwareBuffer null)")
                                } else {
                                    out.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                    hw.recycle()
                                }
                            }
                        } catch (e: Throwable) {
                            err.set("gagal mengolah hasil: " + e.javaClass.simpleName + " " + e.message)
                        } finally {
                            try { hb.close() } catch (_: Throwable) {}
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        err.set("kode " + errorCode + " (" + errName(errorCode) + ")")
                        latch.countDown()
                    }
                }
            )
        } catch (e: Throwable) {
            lastShotError = "takeScreenshot melempar " + e.javaClass.simpleName + ": " + e.message
            AppLog.add("Screenshot GAGAL: " + lastShotError)
            return null
        }
        val got = latch.await(3, TimeUnit.SECONDS)
        val ms = System.currentTimeMillis() - t0
        if (!got) {
            abandoned.set(true)
            lastShotError = "sistem tidak menjawab dalam 3000 ms"
            AppLog.add("Screenshot GAGAL: " + lastShotError)
            return null
        }
        val b = out.get()
        if (b == null) {
            lastShotError = (err.get() ?: "hasil kosong") + " (" + ms + " ms)"
            AppLog.add("Screenshot GAGAL: " + lastShotError)
            return null
        }
        lastShotError = ""
        return b
    }

    // Titik kecil di pojok kiri bawah (tanpa tulisan, tidak bisa disentuh) supaya sistem menganggap
    // aplikasi ini punya jendela yang terlihat dan tidak menahan prosesnya saat berjalan di latar (OCR jauh lebih cepat).
    // style: 0 hapus, 1 putih 14dp, 2 putih kecil 2dp, 3 hampir transparan (5%), 4 1 piksel tanpa warna, 5 14dp tanpa warna.
    private val ui = Handler(Looper.getMainLooper())
    private var dotView: View? = null

    fun dot(style: Int) {
        ui.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val old = dotView
                if (old != null) {
                    try { wm.removeView(old) } catch (_: Throwable) {}
                    dotView = null
                }
                if (style >= 1) {
                    val d = resources.displayMetrics.density
                    val v = View(this)
                    if (style <= 3) {
                        val bg = GradientDrawable()
                        bg.shape = GradientDrawable.OVAL
                        bg.setColor(Color.WHITE)
                        bg.setStroke(maxOf(1, d.toInt()), Color.BLACK)
                        v.background = bg
                    }
                    val sz = when (style) {
                        2 -> maxOf(2, (2 * d).toInt())
                        4 -> 1
                        else -> (14 * d).toInt()
                    }
                    val lp = WindowManager.LayoutParams(
                        sz, sz,
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT
                    )
                    lp.gravity = Gravity.BOTTOM or Gravity.START
                    if (style == 3) lp.alpha = 0.05f
                    if (style >= 4) lp.alpha = 0f
                    wm.addView(v, lp)
                    dotView = v
                }
            } catch (e: Throwable) {
                AppLog.add("Titik melayang gagal: " + e.javaClass.simpleName + " " + e.message)
            }
        }
    }

    // ── Gestures ──
    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        return gestureStroke(stroke)
    }

    // Ketukan sangat singkat (25 ms) untuk ketuk beruntun
    fun tapCepat(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return gestureStroke(GestureDescription.StrokeDescription(path, 0, 25))
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, ms.coerceAtLeast(20))
        return gestureStroke(stroke)
    }

    // Cari teks di jendela aktif lalu klik elemen yang bisa diklik (atau induknya). true = ada yang diklik.
    fun clickText(re: Regex): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            clickDfs(root, re, 0)
        } catch (_: Throwable) { false }
    }

    private fun clickDfs(n: android.view.accessibility.AccessibilityNodeInfo, re: Regex, depth: Int): Boolean {
        if (depth > 40) return false
        val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        if (t.isNotBlank() && re.containsMatchIn(t)) {
            var c: android.view.accessibility.AccessibilityNodeInfo? = n
            var up = 0
            while (c != null && up < 6) {
                if (c.isClickable && c.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)) return true
                c = c.parent
                up++
            }
            // Tidak ada induk yang bisa diklik: ketuk titik tengah elemen
            val r = android.graphics.Rect()
            n.getBoundsInScreen(r)
            if (!r.isEmpty) return tap(r.exactCenterX(), r.exactCenterY())
        }
        for (i in 0 until n.childCount) {
            val ch = n.getChild(i) ?: continue
            if (clickDfs(ch, re, depth + 1)) return true
        }
        return false
    }

    // Semua teks di jendela aktif (untuk diagnosa)
    fun dumpTexts(maks: Int = 60): List<String> {
        val h = ArrayList<String>()
        val root = rootInActiveWindow ?: return h
        fun dfs(n: android.view.accessibility.AccessibilityNodeInfo, d: Int) {
            if (d > 40 || h.size >= maks) return
            val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
            if (t.isNotBlank()) h.add(t.trim() + " [" + (n.className?.toString()?.substringAfterLast('.') ?: "") + (if (n.isClickable) ",klik" else "") + "]")
            for (i in 0 until n.childCount) n.getChild(i)?.let { dfs(it, d + 1) }
        }
        try { dfs(root, 0) } catch (_: Throwable) {}
        return h
    }

    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun home() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun recents() { performGlobalAction(GLOBAL_ACTION_RECENTS) }

    private fun gestureStroke(stroke: GestureDescription.StrokeDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val desc = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(desc, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }

    // ── Banner overlay ──
    private var bannerView: TextView? = null

    fun banner(text: String, ms: Long = 5000L, notify: Boolean = true) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            removeBanner(wm)
            val tv = TextView(this).apply {
                this.text = text
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xCC000000.toInt())
                setPadding(24, 12, 24, 12)
                textSize = 13f
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 48 }
            wm.addView(tv, lp)
            bannerView = tv
            tv.postDelayed({ removeBanner(wm) }, ms)
            if (notify) AppLog.add(text)
        } catch (_: Throwable) {}
    }

    private fun removeBanner(wm: WindowManager) {
        try { bannerView?.let { wm.removeView(it) } } catch (_: Throwable) {}
        bannerView = null
    }
}
