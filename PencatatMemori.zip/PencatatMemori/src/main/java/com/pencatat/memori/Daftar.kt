package com.pencatat.memori

enum class Tipe(val n: Int) { B1(1), I4(4), L8(8) }

// jenis: 0 = angka biasa, 1 = pointer (tampil hex), 2 = status match (tampil nama)
class Bidang(val area: String, val nama: String, val off: Int, val tipe: Tipe, val jenis: Int = 0)

// Semua nama dan angka offset di bawah diambil dari tabel offset di script GG
// (offsetStatic, offsetBattle, offsetStatic2, offsetPos).
object Daftar {

    // Sama dengan namaState di script (indeks 0 = Unknown)
    val STATUS = arrayOf(
        "Unknown", "waitConnect", "waitReady", "selectHero",
        "waitLoading", "Loading", "Play", "waitEnd", "End"
    )

    const val PANJANG_AKUN = 9560
    const val PANJANG_MATCH = 4096
    const val PANJANG_HERO = 1904

    const val POS_X = 604
    const val POS_Y = 612

    // Data akun (SystemData): 22 field
    val AKUN = listOf(
        Bidang("AKUN", "LoginID", 2240, Tipe.L8),
        Bidang("AKUN", "_strRoleName", 2392, Tipe.L8, 1),
        Bidang("AKUN", "_ucLevel", 696, Tipe.B1),
        Bidang("AKUN", "_uiCreateTime", 3344, Tipe.I4),
        Bidang("AKUN", "m_AbnormalityDistanceReportCount", 1296, Tipe.I4),
        Bidang("AKUN", "m_AbnormalityLvReportCount", 1288, Tipe.I4),
        Bidang("AKUN", "m_BattleReceiveMessage", 1112, Tipe.L8, 1),
        Bidang("AKUN", "m_RoomPlayerInfo", 856, Tipe.L8, 1),
        Bidang("AKUN", "m_bEnterBattle", 7656, Tipe.B1),
        Bidang("AKUN", "m_bLockRobotGuide", 3630, Tipe.B1),
        Bidang("AKUN", "m_dicReportSwitches", 2080, Tipe.L8, 1),
        Bidang("AKUN", "m_hook_time", 676, Tipe.L8),
        Bidang("AKUN", "m_sClientLocalVersion", 1160, Tipe.L8, 1),
        Bidang("AKUN", "m_sCreateRoleCountry", 2800, Tipe.L8, 1),
        Bidang("AKUN", "m_uiCreateTimeStr", 1128, Tipe.L8, 1),
        Bidang("AKUN", "m_uiID", 872, Tipe.I4),
        Bidang("AKUN", "m_bOpenQuickMatch", 514, Tipe.B1),
        Bidang("AKUN", "bOpenQuickMatch_Part2", 515, Tipe.B1),
        Bidang("AKUN", "bOpenQuickMatch_Part3", 516, Tipe.B1),
        Bidang("AKUN", "bQuickMatchUseNewBattleSettle", 4929, Tipe.B1),
        Bidang("AKUN", "m_iQuickMatchMaxRankIdInRank", 2036, Tipe.I4),
        Bidang("AKUN", "m_isSelectQuickMatch", 9552, Tipe.B1)
    )

    // Data pertandingan (LogicBattleManager): 11 field
    val MATCH = listOf(
        Bidang("PERTANDINGAN", "_m_eState", 288, Tipe.I4, 2),
        Bidang("PERTANDINGAN", "m_CampAMainTower", 112, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_CampAPlayerList", 160, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_CampBMainTower", 120, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_RealSelfPlayer", 416, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_SoldierList", 200, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_dicMonsterLogic", 80, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_dicPlayerLogic", 72, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_iRealPlayerCount", 412, Tipe.I4),
        Bidang("PERTANDINGAN", "m_uiFrameTime", 316, Tipe.I4),
        Bidang("PERTANDINGAN", "m_BattleSocketMsgHandler", 136, Tipe.L8, 1)
    )

    // Hero sendiri (objek di m_RealSelfPlayer). Posisi (float) ditangani terpisah.
    val HERO = listOf(
        Bidang("HERO", "m_bCantBeHurt", 1888, Tipe.B1),
        Bidang("HERO", "m_bDelet", 1840, Tipe.B1),
        Bidang("HERO", "m_AttrComp", 1296, Tipe.L8, 1)
    )

    // ---- Tower musuh ----
    // E = objek tower (entity), A = objek atribut (HP dkk). Offset dari tabel script:
    // offsetPos (m_bDelet, m_bCantBeHurt, m_AttrComp), offsetAttrHP (health, shield).
    val TOWER_E = listOf(
        Bidang("TOWER", "m_bDelet", 1840, Tipe.B1),
        Bidang("TOWER", "m_bCantBeHurt", 1888, Tipe.B1),
        // Kandidat penanda proteksi tower (belum dikenal artinya). Di Mode cari lama (Hasil_cari_5/9) berubah serentak
        // tepat saat proteksi ~22,7 dtk berakhir. Hanya dibaca, tidak pernah ditulis.
        Bidang("TOWER", "kand_E172", 172, Tipe.I4),    // 1 -> 0 di 6 tower
        Bidang("TOWER", "kand_E216", 216, Tipe.I4),    // 100 -> 0
        Bidang("TOWER", "kand_E488", 488, Tipe.I4),    // 256 -> 257
        Bidang("TOWER", "kand_E492", 492, Tipe.I4),    // 269516800 -> 2097152 di 6 tower (mirip bitfield)
        Bidang("TOWER", "kand_E592", 592, Tipe.I4),    // 0 -> 256
        Bidang("TOWER", "kand_E844", 844, Tipe.I4),    // 1 -> 0
        Bidang("TOWER", "kand_E1536", 1536, Tipe.I4),  // -16777207 -> 0 (nilainya pindah ke E1736)
        Bidang("TOWER", "kand_E1736", 1736, Tipe.I4)   // 0 -> -16777207
    )
    val TOWER_A = listOf(
        Bidang("TOWER", "health", 200, Tipe.I4),
        Bidang("TOWER", "hpSaatIni", 204, Tipe.I4),
        Bidang("TOWER", "shield", 684, Tipe.I4),
        Bidang("TOWER", "kand_A648", 648, Tipe.I4),    // 0 -> 114
        Bidang("TOWER", "kand_A652", 652, Tipe.I4),    // 0 -> -1
        Bidang("TOWER", "kand_A656", 656, Tipe.I4),    // 0 -> 114
        Bidang("TOWER", "kand_A660", 660, Tipe.I4),    // 0 -> 114
        Bidang("TOWER", "kand_A664", 664, Tipe.I4)     // 0 -> 3100 (mirip perisai)
    )
    const val PANJANG_TOWER_E = 1904
    const val PANJANG_KLASIFIKASI = 2304    // cukup sampai m_MonsterType (2184)
    const val PANJANG_TOWER_A = 704

    // Ukuran blok saat Mode cari (dibaca penuh)
    const val CARI_AKUN = 16384
    const val CARI_MATCH = 4096
    const val CARI_HERO = 4096
    const val CARI_TOWER_E = 4096
    const val CARI_TOWER_A = 1024

    // Rantai pointer kamus monster (sama dengan getAllMonster di script)
    const val OFF_DIC_MONSTER = 80          // offsetBattle.m_dicMonsterLogic
    const val GESER_KAMUS = 24
    const val ENTRI_AWAL = 0x30
    const val ENTRI_AKHIR = 0x12c0
    const val ENTRI_LANGKAH = 0x18
    const val OFF_IS_TOWER = 0x59           // offsetPlayer2.IsTower = 89
    const val OFF_IS_MAIN = 0x72            // offsetPlayer2.IsMainTower = 114
    const val OFF_MONSTER_TYPE = 2184       // offsetMonster.m_MonsterType
    const val OFF_CAMP = 484                // offsetPlayer2.m_EntityCampType
    const val OFF_FRAME_TIME = 316          // offsetBattle.m_uiFrameTime (waktu game, ms)
    const val OFF_DELET = 1840              // offsetPos.m_bDelet
    const val OFF_ATTR_COMP = 1296          // offsetPos.m_AttrComp
    const val OFF_ATTR_DICT = 56            // offsetAttr.m_dictIncreaseAttrs
    const val GESER_B = 24

    // Koordinat tower mid (sisi B), urut luar ke dalam; SAMA dengan tabel towerMid di script
    val TOWER_MID = arrayOf(
        floatArrayOf(2.568115234375f, -1.93499755859375f),
        floatArrayOf(2.83123779296875f, -1.9224853515625f),
        floatArrayOf(2.98748779296875f, 0f),
        floatArrayOf(3.072021484375f, 0f)
    )

    // "mid-1" sampai "mid-4" bila posisi cocok dengan koordinat tower mid (selisih < 0,05), selain itu kosong
    fun namaMid(x: Float, y: Float): String {
        for (i in TOWER_MID.indices) {
            if (Math.abs(x - TOWER_MID[i][0]) < 0.05f && Math.abs(y - TOWER_MID[i][1]) < 0.05f) return "mid-" + (i + 1)
        }
        return ""
    }

    // Field dikenal yang bersinggungan dengan kata 4-byte di [kata, kata+4)
    fun kenal(daftar: List<Bidang>, kata: Int): Bidang? {
        for (f in daftar) {
            if (f.off < kata + 4 && f.off + f.tipe.n > kata) return f
        }
        return null
    }

    // Nilai sebuah field dari blok yang dibaca mulai dari offset [awal]
    fun nilai(b: ByteArray, f: Bidang, awal: Int): Long {
        val v = le(b, f.off - awal, f.tipe.n)
        return if (f.tipe == Tipe.I4) v.toInt().toLong() else v
    }

    fun indeks(daftar: List<Bidang>, nama: String): Int {
        for (i in daftar.indices) {
            if (daftar[i].nama == nama) return i
        }
        return -1
    }

    fun le32(b: ByteArray, off: Int): Int = le(b, off, 4).toInt()

    // Baca bilangan little-endian sebanyak n byte
    fun le(b: ByteArray, off: Int, n: Int): Long {
        var v = 0L
        for (i in n - 1 downTo 0) {
            v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        }
        return v
    }

    fun nilai(b: ByteArray, f: Bidang): Long {
        val v = le(b, f.off, f.tipe.n)
        return if (f.tipe == Tipe.I4) v.toInt().toLong() else v
    }

    fun fmt(f: Bidang, v: Long): String = when (f.jenis) {
        1 -> "0x" + java.lang.Long.toHexString(v)
        2 -> if (v in 0L..8L) STATUS[v.toInt()] else "?$v"
        else -> v.toString()
    }

    fun pecahan(b: ByteArray, off: Int): Float =
        java.lang.Float.intBitsToFloat(le(b, off, 4).toInt())
}
