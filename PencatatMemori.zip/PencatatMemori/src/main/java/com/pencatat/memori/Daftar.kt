package com.pencatat.memori

enum class Tipe(val n: Int) { B1(1), I4(4), L8(8) }

// jenis: 0 = angka biasa, 1 = pointer (tampil hex), 2 = status match (tampil nama)
class Bidang(val area: String, val nama: String, val off: Int, val tipe: Tipe, val jenis: Int = 0)

// Semua nama dan angka offset di bawah diambil dari tabel offset di script GG
// (offsetStatic, offsetBattle, offsetStatic2, offsetPos).
object Daftar {

    // Sama dengan namaState di script (indeks 0 = Unknown)
    val STATUS = arrayOf(
        "Unknown", "waitConnect", "waitReady", "selectHero",
        "waitLoading", "Loading", "Play", "waitEnd", "End"
    )

    const val PANJANG_AKUN = 9520
    const val PANJANG_MATCH = 512
    const val PANJANG_HERO = 1904

    const val POS_X = 604
    const val POS_Y = 612

    // Data akun (SystemData): 22 field
    val AKUN = listOf(
        Bidang("AKUN", "LoginID", 2232, Tipe.L8),
        Bidang("AKUN", "_strRoleName", 2384, Tipe.L8, 1),
        Bidang("AKUN", "_ucLevel", 696, Tipe.B1),
        Bidang("AKUN", "_uiCreateTime", 3336, Tipe.I4),
        Bidang("AKUN", "m_AbnormalityDistanceReportCount", 1296, Tipe.I4),
        Bidang("AKUN", "m_AbnormalityLvReportCount", 1288, Tipe.I4),
        Bidang("AKUN", "m_BattleReceiveMessage", 1112, Tipe.L8, 1),
        Bidang("AKUN", "m_RoomPlayerInfo", 856, Tipe.L8, 1),
        Bidang("AKUN", "m_bEnterBattle", 7624, Tipe.B1),
        Bidang("AKUN", "m_bLockRobotGuide", 3622, Tipe.B1),
        Bidang("AKUN", "m_dicReportSwitches", 2080, Tipe.L8, 1),
        Bidang("AKUN", "m_hook_time", 676, Tipe.L8),
        Bidang("AKUN", "m_sClientLocalVersion", 1160, Tipe.L8, 1),
        Bidang("AKUN", "m_sCreateRoleCountry", 2792, Tipe.L8, 1),
        Bidang("AKUN", "m_uiCreateTimeStr", 1128, Tipe.L8, 1),
        Bidang("AKUN", "m_uiID", 872, Tipe.I4),
        Bidang("AKUN", "m_bOpenQuickMatch", 514, Tipe.B1),
        Bidang("AKUN", "bOpenQuickMatch_Part2", 515, Tipe.B1),
        Bidang("AKUN", "bOpenQuickMatch_Part3", 516, Tipe.B1),
        Bidang("AKUN", "bQuickMatchUseNewBattleSettle", 4921, Tipe.B1),
        Bidang("AKUN", "m_iQuickMatchMaxRankIdInRank", 2036, Tipe.I4),
        Bidang("AKUN", "m_isSelectQuickMatch", 9512, Tipe.B1)
    )

    // Data pertandingan (LogicBattleManager): 11 field
    val MATCH = listOf(
        Bidang("PERTANDINGAN", "_m_eState", 288, Tipe.I4, 2),
        Bidang("PERTANDINGAN", "m_CampAMainTower", 112, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_CampAPlayerList", 160, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_CampBMainTower", 120, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_RealSelfPlayer", 416, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_SoldierList", 200, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_dicMonsterLogic", 80, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_dicPlayerLogic", 72, Tipe.L8, 1),
        Bidang("PERTANDINGAN", "m_iRealPlayerCount", 412, Tipe.I4),
        Bidang("PERTANDINGAN", "m_uiFrameTime", 316, Tipe.I4),
        Bidang("PERTANDINGAN", "m_BattleSocketMsgHandler", 136, Tipe.L8, 1)
    )

    // Hero sendiri (objek di m_RealSelfPlayer). Posisi (float) ditangani terpisah.
    val HERO = listOf(
        Bidang("HERO", "m_bCantBeHurt", 1888, Tipe.B1),
        Bidang("HERO", "m_bDelet", 1840, Tipe.B1),
        Bidang("HERO", "m_AttrComp", 1296, Tipe.L8, 1)
    )

    fun indeks(daftar: List<Bidang>, nama: String): Int {
        for (i in daftar.indices) {
            if (daftar[i].nama == nama) return i
        }
        return -1
    }

    // Baca bilangan little-endian sebanyak n byte
    fun le(b: ByteArray, off: Int, n: Int): Long {
        var v = 0L
        for (i in n - 1 downTo 0) {
            v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        }
        return v
    }

    fun nilai(b: ByteArray, f: Bidang): Long {
        val v = le(b, f.off, f.tipe.n)
        return if (f.tipe == Tipe.I4) v.toInt().toLong() else v
    }

    fun fmt(f: Bidang, v: Long): String = when (f.jenis) {
        1 -> "0x" + java.lang.Long.toHexString(v)
        2 -> if (v in 0L..8L) STATUS[v.toInt()] else "?$v"
        else -> v.toString()
    }

    fun pecahan(b: ByteArray, off: Int): Float =
        java.lang.Float.intBitsToFloat(le(b, off, 4).toInt())
}
