package com.pencatat.memori

import android.content.ContentValues
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log dengan arsip sesi per server. */
object AppLog {
    private val buf = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    // Penghitung baris absolut dan "zaman" (naik tiap log dihapus) supaya tampilan bisa mengambil baris baru saja
    @Volatile var seq = 0L
        private set
    @Volatile var epoch = 0
        private set

    private var berkas: java.io.File? = null
    private var appCtx: android.content.Context? = null

    // Log dianggap panjang kalau sudah sebanyak ini (±100 KB); otomatis disimpan ke Download/AutoUpLvl
    // dan layar log dikosongkan, supaya aplikasi tidak menyimpan/menampilkan ribuan baris.
    const val BATAS_PANJANG = 1000
    private val tglFmt = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
    private val penulis = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "logfile").apply { isDaemon = true } }

    // Log disimpan ke berkas supaya tidak hilang saat proses aplikasi mati (mis. crash)
    @Synchronized
    fun init(ctx: android.content.Context) {
        appCtx = ctx.applicationContext
        if (berkas != null) return
        val f = java.io.File(ctx.filesDir, "log.txt")
        berkas = f
        try {
            if (f.exists()) {
                val l = f.readLines()
                val akhir = if (l.size > 400) l.takeLast(400) else l
                if (l.size > 400) f.writeText(akhir.joinToString("\n") + "\n")
                if (akhir.isNotEmpty()) {
                    for (x in akhir) { buf.add(x); seq++ }
                    buf.add(fmt.format(Date()) + " ── sesi baru dimulai ──"); seq++
                }
            }
        } catch (_: Throwable) {}
    }

    // Ambil baris yang lebih baru dari seq tertentu
    @Synchronized
    fun sejak(dari: Long): Pair<Long, List<String>> {
        val n = (seq - dari).toInt()
        if (n <= 0) return Pair(seq, emptyList())
        val m = minOf(n, buf.size)
        return Pair(seq, ArrayList(buf.subList(buf.size - m, buf.size)))
    }

    // Tulis sinkron (dipakai saat crash, thread penulis mungkin tidak sempat jalan)
    fun tambahSinkron(m: String) {
        val baris = fmt.format(Date()) + " " + m.replace('\n', ' ')
        synchronized(this) { buf.add(baris); seq++ }
        try { berkas?.appendText(baris + "\n") } catch (_: Throwable) {}
    }

    // Arsip sesi: setiap 1 server selesai di-up, log saat itu di-snapshot ke arsip
    data class SessionArchive(val serverName: String, val timestamp: String, val lines: List<String>)
    private val archives = ArrayList<SessionArchive>()
    private val dateFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(m: String) {
        val baris = fmt.format(Date()) + " " + m
        buf.add(baris)
        seq++
        NetMon.gabung("$baris")
        while (buf.size > 8000) buf.removeAt(0)
        val f = berkas
        if (f != null) {
            try { penulis.execute { try { f.appendText(baris + "\n") } catch (_: Throwable) {} } } catch (_: Throwable) {}
        }
        if (buf.size >= BATAS_PANJANG && appCtx != null) {
            val snap = ArrayList(buf)
            buf.clear(); epoch++; seq = 0
            if (f != null) try { penulis.execute { try { f.writeText("") } catch (_: Throwable) {} } } catch (_: Throwable) {}
            unduh(snap, "")
        }
    }

    // Simpan banyak baris ke berkas di Download/AutoUpLvl (tanpa izin tambahan), lalu catat hasilnya di log.
    private fun unduh(baris: List<String>, label: String) {
        val ctx = appCtx ?: return
        val nama = "auto-up-lvl-log-" + tglFmt.format(Date()) + (if (label.isNotEmpty()) "-" + label.replace(Regex("[^A-Za-z0-9_-]"), "_") else "") + ".txt"
        try {
            penulis.execute {
                val teks = baris.joinToString("\n") + "\n"
                var lokasi: String? = null
                try {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, nama)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/AutoUpLvl")
                    }
                    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(teks.toByteArray()) }
                        lokasi = "Download/AutoUpLvl/$nama"
                    }
                } catch (_: Throwable) {}
                if (lokasi == null) {
                    try {
                        val d = ctx.getExternalFilesDir(null)
                        if (d != null) {
                            val f = java.io.File(d, nama)
                            f.writeText(teks)
                            lokasi = "Android/data/${ctx.packageName}/files/$nama"
                        }
                    } catch (_: Throwable) {}
                }
                val kb = teks.length / 1024
                if (lokasi != null) add("📥 Log panjang (${baris.size} baris, $kb KB) sudah terunduh: $lokasi")
                else add("⚠ Log panjang (${baris.size} baris) gagal disimpan ke berkas, isinya dibuang")
            }
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun text(): String = if (buf.isEmpty()) "Belum ada log." else buf.joinToString("\n")

    @Synchronized
    fun clear() {
        buf.clear(); epoch++; seq = 0
        val f = berkas
        if (f != null) try { penulis.execute { try { f.writeText("") } catch (_: Throwable) {} } } catch (_: Throwable) {}
    }

    /** Arsipkan log saat ini sebagai sesi server. Dipanggil setiap 1 server selesai di-up. */
    @Synchronized
    fun archiveSession(serverName: String) {
        val snap = ArrayList(buf)
        if (snap.size >= BATAS_PANJANG / 2 && appCtx != null) {
            // Log server ini panjang: simpan ke berkas, arsip dalam aplikasi cukup catatan singkat
            unduh(snap, "server-$serverName")
            archives.add(SessionArchive(serverName, dateFmt.format(Date()), listOf("(${snap.size} baris, sudah diunduh ke berkas)")))
        } else {
            archives.add(SessionArchive(serverName, dateFmt.format(Date()), snap))
        }
        while (archives.size > 200) archives.removeAt(0)
        buf.clear(); epoch++; seq = 0
        add("── Arsip sesi $serverName tersimpan ──")
    }

    /** Ambil semua arsip sesi. */
    @Synchronized
    fun getArchives(): List<SessionArchive> = ArrayList(archives)

    /** Ambil arsip sesi tertentu berdasarkan index. */
    @Synchronized
    fun getArchive(index: Int): SessionArchive? = archives.getOrNull(index)

    /** Jumlah arsip. */
    @Synchronized
    fun archiveCount(): Int = archives.size

    /** Hapus semua arsip. */
    @Synchronized
    fun clearArchives() { archives.clear() }

    /** Teks arsip sesi tertentu. */
    @Synchronized
    fun archiveText(index: Int): String {
        val a = archives.getOrNull(index) ?: return "Arsip tidak ditemukan."
        return "═══ Server ${a.serverName} (${a.timestamp}) ═══\n" + a.lines.joinToString("\n")
    }

    /** Daftar ringkasan arsip. */
    @Synchronized
    fun archiveSummary(): String {
        if (archives.isEmpty()) return "Belum ada arsip sesi."
        return archives.mapIndexed { i, a ->
            "${i + 1}. Server ${a.serverName} — ${a.timestamp} (${a.lines.size} baris)"
        }.joinToString("\n")
    }
}
