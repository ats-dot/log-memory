package com.pencatat.memori

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

// Menu "Tanda lain..." sesuai mockup: daftar baris datar bergaris pemisah.
// Dari notifikasi (ringkas) tepat 6 baris seperti mockup; dari dalam aplikasi ditambah dua tanda cepat di atas.
class MarkerActivity : Activity() {

    private lateinit var pal: Pal

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gelap = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        pal = Pal(gelap)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val gulir = ScrollView(this)

        val ringkas = intent.getBooleanExtra("ringkas", false)
        val pilihan = ArrayList<String>()
        if (!ringkas) {
            pilihan.add("Tower BISA dihit sekarang")
            pilihan.add("Mulai lag / macet")
        }
        pilihan.add("Halaman hasil 1")
        pilihan.add("Halaman hasil 2")
        pilihan.add("Halaman hasil 3")
        pilihan.add("Sampai di lobby")
        pilihan.add("Match mulai (loading)")

        val kartu = LinearLayout(this)
        kartu.orientation = LinearLayout.VERTICAL
        kartu.background = bentuk(pal.surf, 18, pal.bd)
        kartu.clipToOutline = true

        for (p in pilihan) {
            kartu.addView(barisPilihan(p) { simpan(p) }, lp())
            kartu.addView(garisBawah(pal))
        }

        // Baris terakhir: "Catatan ketik sendiri..." membuka kolom ketik
        val barisCatatan = barisPilihan("Catatan ketik sendiri…") { }
        val kolom = LinearLayout(this)
        kolom.orientation = LinearLayout.VERTICAL
        kolom.setPadding(dp(16), dp(8), dp(16), dp(12))
        kolom.visibility = View.GONE
        val isi = EditText(this)
        isi.hint = "Ketik catatan"
        isi.setTextColor(pal.tx)
        isi.setHintTextColor(pal.mu)
        isi.inputType = InputType.TYPE_CLASS_TEXT
        isi.background = bentuk(pal.surf2, 12)
        isi.setPadding(dp(14), dp(12), dp(14), dp(12))
        isi.setSingleLine(true)
        isi.imeOptions = EditorInfo.IME_ACTION_DONE
        isi.setOnEditorActionListener { _, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_DONE) {
                val t = isi.text.toString().trim()
                if (t.isNotEmpty()) simpan(t)
                true
            } else {
                false
            }
        }
        // Saat keyboard muncul, gulir ke bawah supaya kolom dan tombol Simpan tetap terlihat
        isi.setOnFocusChangeListener { _, fokus ->
            if (fokus) gulir.postDelayed({ gulir.fullScroll(View.FOCUS_DOWN) }, 250)
        }
        kolom.addView(isi, lp(bawah = dp(8)))
        kolom.addView(tombol("Simpan catatan", pal, 0) {
            val t = isi.text.toString().trim()
            if (t.isNotEmpty()) simpan(t)
        }, lp())
        barisCatatan.setOnClickListener {
            barisCatatan.visibility = View.GONE
            kolom.visibility = View.VISIBLE
            isi.requestFocus()
            window.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
        kartu.addView(barisCatatan, lp())
        kartu.addView(kolom, lp())

        gulir.addView(kartu)
        val luar = FrameLayout(this)
        luar.setPadding(dp(12), dp(12), dp(12), dp(12))
        luar.addView(gulir)
        setContentView(luar)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun barisPilihan(label: String, klik: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.stateListAnimator = null
        b.background = null
        b.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        b.setPadding(dp(16), 0, dp(16), 0)
        b.minHeight = dp(48)
        b.minimumHeight = dp(48)
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        b.setTextColor(pal.tx)
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.setOnClickListener { klik() }
        return b
    }

    private fun simpan(label: String) {
        Perekam.tanda(label)
        Toast.makeText(this, "Tercatat: $label", Toast.LENGTH_SHORT).show()
        finish()
    }
}
