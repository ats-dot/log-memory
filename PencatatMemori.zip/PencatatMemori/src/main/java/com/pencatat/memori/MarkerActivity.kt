package com.pencatat.memori

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

// Dialog "Tanda lain": pilihan kejadian + catatan ketik sendiri.
class MarkerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gelap = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val pal = Pal(gelap)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val kartu = LinearLayout(this)
        kartu.orientation = LinearLayout.VERTICAL
        kartu.background = bentuk(pal.surf, 20, pal.bd)
        kartu.setPadding(dp(16), dp(16), dp(16), dp(12))
        kartu.addView(teks("Tandai kejadian", 17f, pal.tx, true), lp(bawah = dp(10)))

        val pilihan = listOf(
            "Tower BISA dihit sekarang",
            "Tower belum bisa dihit",
            "Halaman hasil 1",
            "Halaman hasil 2",
            "Halaman hasil 3",
            "Sampai di lobby",
            "Match mulai (loading)",
            "Mulai lag / macet"
        )
        for (p in pilihan) {
            kartu.addView(tombol(p, pal, 2) {
                Perekam.tanda(p)
                Toast.makeText(this, "Tercatat: $p", Toast.LENGTH_SHORT).show()
                finish()
            }, lp(bawah = dp(8)))
        }

        val isi = EditText(this)
        isi.hint = "Catatan ketik sendiri"
        isi.setTextColor(pal.tx)
        isi.setHintTextColor(pal.mu)
        isi.inputType = InputType.TYPE_CLASS_TEXT
        isi.background = bentuk(pal.surf2, 12)
        isi.setPadding(dp(14), dp(12), dp(14), dp(12))
        kartu.addView(isi, lp(atas = dp(4), bawah = dp(8)))
        kartu.addView(tombol("Simpan catatan", pal, 0) {
            val t = isi.text.toString().trim()
            if (t.isNotEmpty()) {
                Perekam.tanda(t)
                Toast.makeText(this, "Tercatat: $t", Toast.LENGTH_SHORT).show()
                finish()
            }
        }, lp(bawah = dp(4)))

        val gulir = ScrollView(this)
        gulir.addView(kartu)
        val luar = FrameLayout(this)
        luar.setPadding(dp(12), dp(12), dp(12), dp(12))
        luar.addView(gulir)
        setContentView(luar)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
