package com.pencatat.memori

import android.util.Base64
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

// Proses native (memscan serve) yang tetap hidup di sandbox game lewat "run-as". Baca/tulis memori lewat
// satu baris perintah per operasi, tanpa memulai proses baru (dd + base64) tiap kali. Jauh lebih cepat.
class HelperNative(private val paket: String, private val path: String) {

    private var proc: Process? = null
    private var keluar: OutputStream? = null
    private val antrean = LinkedBlockingQueue<String>()

    @Volatile
    var hidup = false
        private set

    fun buka(): Boolean {
        tutup()
        if (!Regex("[A-Za-z0-9_.]+").matches(paket) || path.isEmpty()) return false
        return try {
            val p = ShizukuHelper.start(arrayOf("sh", "-c", "run-as $paket $path serve"))
            proc = p
            keluar = p.outputStream
            hidup = true
            Thread {
                try {
                    val r = p.inputStream.bufferedReader()
                    while (true) {
                        val baris = r.readLine() ?: break
                        antrean.offer(baris)
                    }
                } catch (_: Throwable) {
                }
                hidup = false
            }.apply { isDaemon = true }.start()
            Thread {
                try {
                    val buf = ByteArray(1024)
                    while (p.errorStream.read(buf) >= 0) {
                    }
                } catch (_: Throwable) {
                }
            }.apply { isDaemon = true }.start()
            val jawab = kirim("P", 4000)
            if (jawab == "PONG") true else { tutup(); false }
        } catch (_: Throwable) {
            tutup()
            false
        }
    }

    fun tutup() {
        hidup = false
        try { keluar?.write("Q\n".toByteArray()); keluar?.flush() } catch (_: Throwable) {}
        try { proc?.destroy() } catch (_: Throwable) {}
        proc = null
        keluar = null
        antrean.clear()
    }

    // Kirim satu baris, tunggu satu baris jawaban. Melempar IOException kalau proses mati / tidak menjawab.
    @Synchronized
    private fun kirim(baris: String, batasMs: Long = 3000): String {
        val o = keluar
        if (o == null || !hidup) throw IOException("helper mati")
        antrean.clear()
        try {
            o.write((baris + "\n").toByteArray())
            o.flush()
        } catch (e: Throwable) {
            tutup()
            throw IOException("tulis ke helper gagal")
        }
        val j = antrean.poll(batasMs, TimeUnit.MILLISECONDS)
        if (j == null) {
            tutup()
            throw IOException("helper tidak menjawab")
        }
        return j
    }

    // null = alamat tidak terbaca (jawaban resmi dari helper). IOException = helper bermasalah (pakai cara lain).
    fun baca(pid: Int, alamat: Long, panjang: Int): ByteArray? {
        if (alamat <= 0L || panjang <= 0) return null
        val j = kirim("R $pid ${java.lang.Long.toHexString(alamat)} $panjang")
        if (!j.startsWith("D ")) return null
        return try { Base64.decode(j.substring(2), Base64.DEFAULT) } catch (_: Throwable) { null }
    }

    fun tulis(pid: Int, daftar: List<Pair<Long, ByteArray>>): Boolean {
        for (potong in daftar.chunked(24)) {
            val sb = StringBuilder("W $pid")
            var n = 0
            for ((a, b) in potong) {
                if (a <= 0L || b.isEmpty()) continue
                sb.append(' ').append(java.lang.Long.toHexString(a)).append(' ')
                for (x in b) sb.append(String.format("%02x", x.toInt() and 0xFF))
                n++
            }
            if (n == 0) continue
            if (kirim(sb.toString(), 5000) != "OK") return false
        }
        return true
    }
}
