package com.pencatat.memori

/**
 * Kirim paket Klaim Hadiah Kemenangan via TCP melalui CMD_FILE di Clone.
 *
 * Alur otomatis:
 * 1. Server pertama: klaim via UI biasa. NetMon menangkap payload klaim asli
 *    dari paket bbea 43-byte yang game kirim (berisi reward ID event).
 * 2. Server berikutnya: kirim 4 paket TCP langsung (buka halaman, query,
 *    query2, klaim asli) tanpa perlu navigasi UI.
 * 3. Payload klaim di-reuse karena reward ID sama untuk semua server dalam
 *    satu periode event.
 */
object PaketKirim {
    private fun log(m: String) = AppLog.add("[Paket] $m")

    private const val CLONE_PKG = "top.niunaijun.blackbox"

    // Tracking seq dari netlog
    @Volatile var lastSeq = 0
    @Volatile var gameServerIp = ""

    // Payload klaim asli (bagian setelah seq).
    // Kosong di awal: server pertama pakai UI klaim, NetMon tangkap payload.
    // Reward ID berubah tiap periode event, jadi TIDAK boleh di-hardcode.
    @Volatile var capturedKlaimPost = ""

    // Flag: NetMon hanya boleh tangkap payload klaim saat ini true.
    // Engine set true tepat sebelum claimHadiahKemenangan() di server pertama.
    // Mencegah salah tangkap paket bbea lain (lobby loading dll).
    @Volatile var siapTangkap = false

    // ── Template paket ──

    // Konfirmasi match: opcode e399 (23 byte)
    private const val KONF_PRE  = "7000e3990101"
    private const val KONF_POST = "45087000d2fff5f9088080"

    // Step 1: Buka halaman Hadiah — opcode bbea + d464 (28 byte)
    private const val BUKA_PRE  = "7000bbea0101"
    private const val BUKA_POST = "450d7000d46401d46402014301318080"

    // Step 2: Query status — opcode b3ea + d464 (22 byte)
    private const val QUERY_PRE  = "7000b3ea0101"
    private const val QUERY_POST = "450770500100d4648080"

    // Step 3: Query lanjutan — opcode b0ff + d464 (20 byte)
    private const val QUERY2_PRE  = "7000b0ff0101"
    private const val QUERY2_POST = "45057000d4648080"

    // Step 4: Klaim asli — opcode bbea + payload tangkapan (43 byte)
    private const val KLAIM_PRE = "7000bbea0101"

    /**
     * Dipanggil dari NetMon saat mendeteksi paket klaim asli (bbea >= 40 byte).
     * Menyimpan payload setelah seq untuk dipakai TCP Klaim di server berikutnya.
     */
    fun tangkapKlaim(postHex: String) {
        capturedKlaimPost = postHex
        siapTangkap = false  // sudah tertangkap, matikan flag
        log("Reward payload tertangkap (${postHex.length / 2} byte): ...${postHex.takeLast(30)}")
    }

    /**
     * Dipanggil dari NetMon.laporBarisClone() untuk setiap SEND di game server.
     * Coba dekode seq varint dari byte 10-11 hex data.
     */
    fun lacakSeq(hex: String, dest: String) {
        if (dest.contains(":10003")) {
            gameServerIp = dest
        }
        if (hex.length < 24) return
        if (hex.substring(8, 12) != "7000") return

        try {
            val b10 = hex.substring(20, 22).toInt(16)
            val b11 = hex.substring(22, 24).toInt(16)

            val seq = if (b10 >= 0x80) {
                (b10 and 0x7F) or (b11 shl 7)
            } else {
                b10
            }

            if (seq > lastSeq) lastSeq = seq
        } catch (_: Throwable) {}
    }

    private fun varintHex(value: Int): String {
        val sb = StringBuilder()
        var v = value
        while (v >= 0x80) {
            sb.append(String.format("%02x", (v and 0x7F) or 0x80))
            v = v ushr 7
        }
        sb.append(String.format("%02x", v))
        return sb.toString()
    }

    private fun bangunPaket(pre: String, post: String, seq: Int): String {
        val seqHex = varintHex(seq)
        val payload = pre + seqHex + post
        val totalBytes = payload.length / 2 + 4
        val lenHex = String.format("%08x", totalBytes)
        return lenHex + payload
    }

    private fun tulisCmdFile(isi: String): Boolean {
        return try {
            val cmd = "run-as $CLONE_PKG sh -c 'cat > files/netcmd.txt'"
            val p = ShizukuHelper.start(arrayOf("sh", "-c", "echo '$isi' | $cmd"))
            p.waitFor()
            p.exitValue() == 0
        } catch (e: Throwable) {
            log("CMD_FILE error: ${e.javaClass.simpleName} ${e.message}")
            false
        }
    }

    /**
     * Kirim 4 paket klaim Hadiah Kemenangan via TCP.
     * Hanya bisa dipanggil kalau capturedKlaimPost sudah terisi.
     *
     * @return true jika berhasil tulis CMD_FILE
     */
    fun kirimKlaimHadiah(): Boolean {
        val post = capturedKlaimPost
        if (post.isEmpty()) {
            log("Gagal: payload klaim belum tertangkap")
            return false
        }
        val seq = lastSeq
        if (seq <= 0 || gameServerIp.isEmpty()) {
            log("Gagal kirim Klaim: seq=$seq, server=$gameServerIp")
            return false
        }

        // 4 paket berurutan: buka halaman, query, query2, klaim asli
        val s1 = seq + 1
        val s2 = seq + 2
        val s3 = seq + 3
        val s4 = seq + 4

        val pktBuka   = bangunPaket(BUKA_PRE, BUKA_POST, s1)
        val pktQuery  = bangunPaket(QUERY_PRE, QUERY_POST, s2)
        val pktQuery2 = bangunPaket(QUERY2_PRE, QUERY2_POST, s3)
        val pktKlaim  = bangunPaket(KLAIM_PRE, post, s4)

        val isi = "$pktBuka\n$pktQuery\n$pktQuery2\n$pktKlaim\n"

        log("Kirim 4 paket TCP Klaim (seq=$s1..$s4) ke $gameServerIp")

        val ok = tulisCmdFile(isi)
        if (ok) {
            log("TCP Klaim CMD_FILE berhasil (payload=$post)")
            lastSeq = s4
        } else {
            log("TCP Klaim CMD_FILE gagal ditulis")
        }
        return ok
    }

    /**
     * Kirim Konfirmasi match result saja (opcode e399).
     */
    fun kirimKonfirmasi(): Boolean {
        val seq = lastSeq
        if (seq <= 0 || gameServerIp.isEmpty()) {
            log("Gagal kirim Konfirmasi: seq=$seq, server=$gameServerIp")
            return false
        }

        val s1 = seq + 1
        val pkt = bangunPaket(KONF_PRE, KONF_POST, s1)
        val isi = "$pkt\n"

        log("Kirim Konfirmasi TCP (seq=$s1) ke $gameServerIp")

        val ok = tulisCmdFile(isi)
        if (ok) {
            log("Konfirmasi CMD_FILE berhasil")
            lastSeq = s1
        } else {
            log("Konfirmasi CMD_FILE gagal")
        }
        return ok
    }

    /** Reset saat ganti server / sesi baru. capturedKlaimPost TIDAK direset (sama untuk semua server). */
    fun reset() {
        lastSeq = 0
        gameServerIp = ""
    }

    /** Reset total (saat sesi otomasi baru dimulai).
     *  capturedKlaimPost TIDAK direset karena sudah pre-filled dengan reward ID tetap. */
    fun resetSemua() {
        lastSeq = 0
        gameServerIp = ""
        // capturedKlaimPost tetap (pre-filled / dari tangkapan sebelumnya)
        siapTangkap = false
    }
}
