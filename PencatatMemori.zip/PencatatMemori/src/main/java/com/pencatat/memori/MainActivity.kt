package com.pencatat.memori

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Tiga tab sesuai mockup: Beranda, Aktivitas, Cari (Memori / Hasil / File).
class MainActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var sp: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private val idn = Locale("id", "ID")

    private var tab = 0
    private var filter = "Semua"
    private var versiTampil = -1
    private var tampil: List<Perekam.Kejadian> = emptyList()
    private var cariLayar = 0            // 0 = memori, 1 = hasil, 2 = file
    private var menungguHasil = false
    private var sigCari = ""

    // Beranda
    private lateinit var tvChip: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var tvMulti: TextView
    private lateinit var tvGame: TextView
    private lateinit var tvJumlah: TextView
    private lateinit var tvHz: TextView
    private lateinit var tvUkuran: TextView
    private lateinit var tvPesan: TextView
    private lateinit var btnUtama: Button
    private lateinit var btnKedua: Button

    // Aktivitas
    private lateinit var tvHitung: TextView
    private lateinit var daftarView: ListView
    private lateinit var adapter: BaseAdapter
    private val chipFilter = ArrayList<Button>()

    // Cari (bagian yang diperbarui tiap 0,5 detik)
    private lateinit var kontenCari: FrameLayout
    private var cChip: TextView? = null
    private var cStat1: TextView? = null
    private var cStat2: TextView? = null
    private var cStat3: TextView? = null

    private lateinit var kontenBeranda: View
    private lateinit var kontenAktivitas: View
    private lateinit var navBeranda: Button
    private lateinit var navAktivitas: Button
    private lateinit var navCari: Button

    private val pilihanHz = intArrayOf(2, 5, 10, 20)

    private val segar = object : Runnable {
        override fun run() {
            perbarui()
            h.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gelap = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        pal = Pal(gelap)
        sp = getSharedPreferences("pencatat", Context.MODE_PRIVATE)
        muatPengaturan()
        PemindaiFile.muat(this)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.surf
        if (!gelap) {
            window.insetsController?.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
        setContentView(bangunUi())
        pilihTab(0)
    }

    override fun onResume() {
        super.onResume()
        h.removeCallbacks(segar)
        h.post(segar)
    }

    override fun onPause() {
        h.removeCallbacks(segar)
        tutupKeyboard()
        simpanPengaturan()
        super.onPause()
    }

    // ------------------------------------------------------------------
    // Keyboard: tutup + lepas fokus saat pindah tab, saat ke belakang, dan saat menyentuh di luar kolom.
    // Jendela memakai adjustPan (lihat manifest), jadi tab bawah tidak ikut naik.

    private fun tutupKeyboard() {
        val v = currentFocus ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun tutupKeyboardDari(v: View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f is EditText) {
                val r = Rect()
                f.getGlobalVisibleRect(r)
                if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) tutupKeyboard()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------------
    // Pengaturan

    private fun muatPengaturan() {
        Perekam.paket = sp.getString("paket", "com.dong.multirun") ?: "com.dong.multirun"
        Perekam.hz = sp.getInt("hz", 5)
        Perekam.deteksiLag = sp.getBoolean("lag", true)
        Perekam.areaAkun = sp.getBoolean("akun", true)
        Perekam.areaMatch = sp.getBoolean("match", true)
        Perekam.areaHero = sp.getBoolean("hero", true)
        Perekam.areaTower = sp.getBoolean("tower", true)
        Perekam.cariAkun = sp.getBoolean("cari_akun", true)
        Perekam.cariMatch = sp.getBoolean("cari_match", true)
        Perekam.cariHero = sp.getBoolean("cari_hero", true)
        Perekam.cariTower = sp.getBoolean("cari_tower", true)
        PemindaiFile.runAs = sp.getBoolean("file_runas", true)
        PemindaiFile.androidData = sp.getBoolean("file_android", true)
    }

    private fun simpanPengaturan() {
        sp.edit()
            .putString("paket", Perekam.paket)
            .putInt("hz", Perekam.hz)
            .putBoolean("lag", Perekam.deteksiLag)
            .putBoolean("akun", Perekam.areaAkun)
            .putBoolean("match", Perekam.areaMatch)
            .putBoolean("hero", Perekam.areaHero)
            .putBoolean("tower", Perekam.areaTower)
            .putBoolean("cari_akun", Perekam.cariAkun)
            .putBoolean("cari_match", Perekam.cariMatch)
            .putBoolean("cari_hero", Perekam.cariHero)
            .putBoolean("cari_tower", Perekam.cariTower)
            .putBoolean("file_runas", PemindaiFile.runAs)
            .putBoolean("file_android", PemindaiFile.androidData)
            .apply()
    }

    // ------------------------------------------------------------------
    // Kerangka: tiga isi + garis + menu bawah berikon

    private fun bangunUi(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL
        akar.setBackgroundColor(pal.bg)

        kontenBeranda = bangunBeranda()
        kontenAktivitas = bangunAktivitas()
        kontenCari = FrameLayout(this)
        akar.addView(kontenBeranda, lp(tinggi = 0, bobot = 1f))
        akar.addView(kontenAktivitas, lp(tinggi = 0, bobot = 1f))
        akar.addView(kontenCari, lp(tinggi = 0, bobot = 1f))
        akar.addView(garisBawah(pal))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(pal.surf)
        navBeranda = tombolNav("Beranda", R.drawable.ic_home) { pilihTab(0) }
        navAktivitas = tombolNav("Aktivitas", R.drawable.ic_list) { pilihTab(1) }
        navCari = tombolNav("Cari", R.drawable.ic_search) {
            if (tab == 2 && cariLayar == 1) cariLayar = 0
            pilihTab(2)
        }
        nav.addView(navBeranda, lp(lebar = 0, bobot = 1f))
        nav.addView(navAktivitas, lp(lebar = 0, bobot = 1f))
        nav.addView(navCari, lp(lebar = 0, bobot = 1f))
        akar.addView(nav, lp())
        return akar
    }

    private fun tombolNav(label: String, ikon: Int, klik: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.stateListAnimator = null
        b.background = null
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        b.minHeight = dp(56)
        b.minimumHeight = dp(56)
        b.compoundDrawablePadding = dp(3)
        b.tag = ikon
        b.setOnClickListener { klik() }
        return b
    }

    private fun warnaNav(b: Button, aktif: Boolean) {
        val w = if (aktif) pal.acc else pal.mu
        b.setTextColor(w)
        b.typeface = if (aktif) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val d = getDrawable(b.tag as Int)?.mutate()
        d?.setTint(w)
        b.setCompoundDrawablesWithIntrinsicBounds(null, d, null, null)
    }

    private fun pilihTab(t: Int) {
        tutupKeyboard()
        tab = t
        kontenBeranda.visibility = if (t == 0) View.VISIBLE else View.GONE
        kontenAktivitas.visibility = if (t == 1) View.VISIBLE else View.GONE
        kontenCari.visibility = if (t == 2) View.VISIBLE else View.GONE
        warnaNav(navBeranda, t == 0)
        warnaNav(navAktivitas, t == 1)
        warnaNav(navCari, t == 2)
        versiTampil = -1
        sigCari = ""
        perbarui()
    }

    // ------------------------------------------------------------------
    // Pembantu tampilan

    private fun titikAktif(): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.acc)
        g.setSize(dp(8), dp(8))
        return g
    }

    private fun buatChip(awal: String): TextView {
        val c = teks(awal, 12f, pal.acc, true)
        c.background = bentuk(0, 20, pal.acc)
        c.setPadding(dp(10), dp(6), dp(10), dp(6))
        c.compoundDrawablePadding = dp(6)
        return c
    }

    private fun setChip(c: TextView, aktif: Boolean, label: String) {
        c.text = label
        if (aktif) {
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(titikAktif(), null, null, null)
        } else {
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
        }
    }

    // Kepala layar: judul + subjudul di kiri, chip status di kanan (opsional)
    private fun kepala(judul: String, sub: String, chip: TextView?, panjang: (() -> Unit)?): View {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.HORIZONTAL
        k.gravity = Gravity.CENTER_VERTICAL
        k.setPadding(dp(20), dp(16), dp(20), dp(12))
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.addView(teks(judul, 20f, pal.tx, true))
        kol.addView(teks(sub, 13f, pal.mu))
        if (panjang != null) {
            kol.setOnLongClickListener {
                panjang()
                true
            }
        }
        k.addView(kol, lp(lebar = 0, bobot = 1f))
        if (chip != null) k.addView(chip)
        return k
    }

    private fun angka(n: Int): String = String.format(idn, "%,d", n)

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun kotakStat(label: String, besar: Float): Pair<LinearLayout, TextView> {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.VERTICAL
        k.background = bentuk(pal.surf, 14, pal.bd)
        k.setPadding(dp(12), dp(12), dp(12), dp(12))
        val nilai = teks("-", besar, pal.tx, true)
        k.addView(nilai)
        k.addView(teks(label, 12f, pal.mu))
        return Pair(k, nilai)
    }

    private fun barisStat(a: LinearLayout, b: LinearLayout, c: LinearLayout): LinearLayout {
        val s = LinearLayout(this)
        s.orientation = LinearLayout.HORIZONTAL
        s.addView(a, lp(lebar = 0, bobot = 1f, kanan = dp(8)))
        s.addView(b, lp(lebar = 0, bobot = 1f, kanan = dp(8)))
        s.addView(c, lp(lebar = 0, bobot = 1f))
        return s
    }

    private fun paragraf(isi: String, ukuran: Float): TextView {
        val t = teks(isi, ukuran, pal.mu)
        t.setLineSpacing(0f, 1.25f)
        t.setPadding(dp(4), 0, dp(4), 0)
        return t
    }

    // ------------------------------------------------------------------
    // Beranda (sesuai mockup "Beranda (sedang merekam)")

    private fun barisKoneksi(induk: LinearLayout, label: String): TextView {
        val baris = LinearLayout(this)
        baris.orientation = LinearLayout.HORIZONTAL
        baris.gravity = Gravity.CENTER_VERTICAL
        baris.addView(teks(label, 14f, pal.tx), lp(lebar = 0, bobot = 1f))
        val nilai = teks("-", 14f, pal.acc, true)
        nilai.compoundDrawablePadding = dp(6)
        baris.addView(nilai)
        induk.addView(baris, lp(atas = dp(10)))
        return nilai
    }

    private fun setKoneksi(t: TextView, isi: String, ok: Boolean) {
        t.text = isi
        t.setTextColor(if (ok) pal.acc else pal.mu)
        if (ok) {
            val d = getDrawable(R.drawable.ic_check)?.mutate()
            d?.setTint(pal.acc)
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(d, null, null, null)
        } else {
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
        }
    }

    private fun bangunBeranda(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL

        tvChip = buatChip("SIAP")
        // Tahan lama judul untuk membuka Setelan (supaya tampilan Beranda tetap sama dengan mockup)
        akar.addView(kepala("Pencatat Memori", "Membaca data game lewat Shizuku", tvChip) { tampilkanSetelan() }, lp())

        val gulir = ScrollView(this)
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setPadding(dp(16), dp(4), dp(16), dp(8))

        val kKon = kartu(pal)
        kKon.addView(teks("Koneksi", 13f, pal.mu, true))
        tvShizuku = barisKoneksi(kKon, "Shizuku")
        tvMulti = barisKoneksi(kKon, "Multi Run")
        tvGame = barisKoneksi(kKon, "Game")
        kol.addView(kKon, lp(bawah = dp(12)))

        tvPesan = teks("", 13f, pal.ambTx)
        tvPesan.background = bentuk(pal.ambBg, 12)
        tvPesan.setPadding(dp(12), dp(10), dp(12), dp(10))
        kol.addView(tvPesan, lp(bawah = dp(12)))

        val s1 = kotakStat("perubahan", 20f)
        val s2 = kotakStat("baca per detik", 20f)
        val s3 = kotakStat("ukuran berkas", 20f)
        tvJumlah = s1.second
        tvHz = s2.second
        tvUkuran = s3.second
        kol.addView(barisStat(s1.first, s2.first, s3.first), lp(bawah = dp(12)))

        val kArea = kartu(pal, 6)
        kArea.addView(teks("Area dipantau", 13f, pal.mu, true))
        kArea.addView(barisCentang(pal, "Data akun", "${Daftar.AKUN.size} field", Perekam.areaAkun, true) {
            Perekam.areaAkun = it
        })
        kArea.addView(barisCentang(pal, "Data pertandingan", "${Daftar.MATCH.size} field", Perekam.areaMatch, true) {
            Perekam.areaMatch = it
        })
        kArea.addView(barisCentang(pal, "Hero sendiri", "posisi dan flag", Perekam.areaHero, true) {
            Perekam.areaHero = it
        })
        kArea.addView(barisCentang(pal, "Tower musuh", "flag, HP, perisai", Perekam.areaTower, true) {
            Perekam.areaTower = it
        })
        kol.addView(kArea, lp())
        gulir.addView(kol)
        akar.addView(gulir, lp(tinggi = 0, bobot = 1f))

        val bawah = LinearLayout(this)
        bawah.orientation = LinearLayout.VERTICAL
        bawah.setPadding(dp(16), dp(12), dp(16), dp(14))
        btnUtama = tombol("Mulai merekam", pal, 0) { klikUtama() }
        btnKedua = tombol("", pal, 1, R.drawable.ic_stop) { klikKedua() }
        bawah.addView(btnUtama, lp(tinggi = dp(56), bawah = dp(8)))
        bawah.addView(btnKedua, lp(tinggi = dp(48)))
        akar.addView(bawah, lp())
        return akar
    }

    // Setelan (tahan lama judul "Pencatat Memori")
    private fun tampilkanSetelan() {
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setBackgroundColor(pal.surf)
        kol.setPadding(dp(20), dp(12), dp(20), dp(8))
        kol.addView(teks("Paket Multi Run", 13f, pal.tx))
        val isi = EditText(this)
        isi.setText(Perekam.paket)
        isi.setTextColor(pal.tx)
        isi.setSingleLine(true)
        isi.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        isi.imeOptions = EditorInfo.IME_ACTION_DONE
        isi.background = bentuk(pal.surf2, 12)
        isi.setPadding(dp(12), dp(10), dp(12), dp(10))
        kol.addView(isi, lp(atas = dp(4)))
        val tombolHz = tombol("", pal, 2) { }
        fun segarHz() {
            tombolHz.text = "Baca per detik (target): ${Perekam.hz}x"
        }
        segarHz()
        tombolHz.setOnClickListener {
            var i = 0
            for (k in pilihanHz.indices) if (pilihanHz[k] == Perekam.hz) i = k
            Perekam.hz = pilihanHz[(i + 1) % pilihanHz.size]
            segarHz()
        }
        kol.addView(tombolHz, lp(atas = dp(10)))
        kol.addView(barisCentang(pal, "Deteksi lag otomatis", "eksperimen", Perekam.deteksiLag, true) {
            Perekam.deteksiLag = it
        })
        val dlg = AlertDialog.Builder(this)
            .setTitle("Setelan")
            .setView(kol)
            .setPositiveButton("Selesai", null)
            .create()
        isi.setOnEditorActionListener { v, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_DONE) {
                terapkanPaket(isi)
                tutupKeyboardDari(v)
                true
            } else {
                false
            }
        }
        dlg.setOnDismissListener {
            terapkanPaket(isi)
            simpanPengaturan()
        }
        dlg.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        dlg.show()
    }

    private fun terapkanPaket(isi: EditText) {
        val t = isi.text.toString().trim()
        if (t.isEmpty()) return
        if (Regex("[A-Za-z0-9_.]+").matches(t)) {
            Perekam.paket = t
        } else {
            toast("Nama paket tidak valid")
        }
    }

    // ------------------------------------------------------------------
    // Aktivitas (sesuai mockup "Aktivitas (perubahan langsung)")

    private fun bangunAktivitas(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL

        val kep = LinearLayout(this)
        kep.orientation = LinearLayout.HORIZONTAL
        kep.gravity = Gravity.CENTER_VERTICAL
        kep.setPadding(dp(20), dp(16), dp(16), dp(8))
        kep.addView(teks("Aktivitas", 20f, pal.tx, true), lp(lebar = 0, bobot = 1f))
        kep.addView(
            tombol("Bagikan berkas", pal, 3, R.drawable.ic_share) { bagikan() },
            lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, tinggi = dp(44))
        )
        akar.addView(kep, lp())

        val gulirChip = HorizontalScrollView(this)
        gulirChip.isHorizontalScrollBarEnabled = false
        val barisChip = LinearLayout(this)
        barisChip.orientation = LinearLayout.HORIZONTAL
        barisChip.setPadding(dp(16), dp(4), dp(16), dp(8))
        for (nama in listOf("Semua", "Akun", "Pertandingan", "Tanda")) {
            val c = Button(this)
            c.text = nama
            c.isAllCaps = false
            c.stateListAnimator = null
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            c.minHeight = dp(44)
            c.minimumHeight = dp(44)
            c.minWidth = 0
            c.minimumWidth = 0
            c.setPadding(dp(14), 0, dp(14), 0)
            c.setOnClickListener {
                filter = nama
                versiTampil = -1
                warnaiChip()
                perbarui()
            }
            chipFilter.add(c)
            barisChip.addView(c, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kanan = dp(8)))
        }
        gulirChip.addView(barisChip)
        akar.addView(gulirChip, lp())
        warnaiChip()

        tvHitung = teks("", 12f, pal.mu)
        tvHitung.setPadding(dp(20), 0, dp(20), dp(8))
        akar.addView(tvHitung, lp())

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = tampil.size
            override fun getItem(position: Int): Any = tampil[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
                barisView(tampil[position])
        }
        daftarView = ListView(this)
        daftarView.adapter = adapter
        daftarView.divider = null
        daftarView.background = bentuk(pal.surf, 16, pal.bd)
        daftarView.clipToOutline = true
        akar.addView(daftarView, lp(tinggi = 0, bobot = 1f, kiri = dp(16), kanan = dp(16), bawah = dp(12)))
        return akar
    }

    private fun warnaiChip() {
        for (c in chipFilter) {
            val on = c.text.toString() == filter
            c.background = if (on) bentuk(pal.acc, 22) else bentuk(0, 22, pal.bd)
            c.setTextColor(if (on) pal.onAcc else pal.tx)
            c.typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun barisView(k: Perekam.Kejadian): View {
        val tanda = k.tipe == "TANDA"
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        if (tanda) v.setBackgroundColor(pal.ambBg)

        val isi = LinearLayout(this)
        isi.orientation = LinearLayout.VERTICAL
        isi.setPadding(dp(16), dp(10), dp(16), dp(10))

        val atas = LinearLayout(this)
        atas.orientation = LinearLayout.HORIZONTAL
        atas.gravity = Gravity.CENTER_VERTICAL
        val jam = teks(SimpleDateFormat("HH:mm:ss.S", Locale.US).format(Date(k.waktu)), 12f, if (tanda) pal.ambTx else pal.mu)
        jam.typeface = Typeface.MONOSPACE
        atas.addView(jam)
        val gaya = when (k.tipe) {
            "PERTANDINGAN", "HERO", "TOWER" -> 1
            "TANDA" -> 2
            "OTOMATIS" -> 4
            else -> 0
        }
        atas.addView(chipTeks(pal, k.tipe, gaya), lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(8)))
        if (k.ket != null) {
            val ket = teks(k.ket, 12f, if (tanda) pal.ambTx else pal.mu)
            ket.gravity = Gravity.END
            ket.maxLines = 1
            ket.ellipsize = TextUtils.TruncateAt.END
            atas.addView(ket, lp(lebar = 0, bobot = 1f, kiri = dp(8)))
        }
        isi.addView(atas, lp())

        if (tanda) {
            isi.addView(teks(k.judul, 14f, pal.ambTx, true), lp(atas = dp(4)))
        } else {
            val bawah = LinearLayout(this)
            bawah.orientation = LinearLayout.HORIZONTAL
            bawah.gravity = Gravity.CENTER_VERTICAL
            val medan = teks(k.judul, 13f, pal.tx)
            medan.typeface = Typeface.MONOSPACE
            medan.maxLines = 1
            medan.ellipsize = TextUtils.TruncateAt.END
            bawah.addView(medan, lp(lebar = 0, bobot = 1f))
            val ubah = SpannableStringBuilder()
            ubah.append(k.lama ?: "-").append(" → ")
            val mulai = ubah.length
            ubah.append(k.baru ?: "-")
            ubah.setSpan(ForegroundColorSpan(pal.tx), mulai, ubah.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            ubah.setSpan(StyleSpan(Typeface.BOLD), mulai, ubah.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val tvUbah = teks("", 13f, pal.mu)
            tvUbah.text = ubah
            tvUbah.typeface = Typeface.MONOSPACE
            tvUbah.maxLines = 1
            bawah.addView(tvUbah, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(10)))
            isi.addView(bawah, lp(atas = dp(4)))
        }
        v.addView(isi, lp())
        v.addView(garisBawah(pal))
        return v
    }

    // ------------------------------------------------------------------
    // Cari (sesuai mockup "Cari memori", "Hasil cari memori", "Cari file")

    private fun segmen(aktif: String): View {
        val w = LinearLayout(this)
        w.orientation = LinearLayout.HORIZONTAL
        w.background = bentuk(pal.surf2, 14, pal.bd)
        w.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (nama in listOf("Memori", "File")) {
            val on = nama == aktif
            val b = Button(this)
            b.text = nama
            b.isAllCaps = false
            b.stateListAnimator = null
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            b.typeface = Typeface.DEFAULT_BOLD
            b.minHeight = dp(44)
            b.minimumHeight = dp(44)
            b.background = if (on) bentuk(pal.acc, 10) else null
            b.setTextColor(if (on) pal.onAcc else pal.mu)
            b.setOnClickListener {
                cariLayar = if (nama == "Memori") 0 else 2
                sigCari = ""
                perbarui()
            }
            w.addView(b, lp(lebar = 0, bobot = 1f, kanan = if (nama == "Memori") dp(4) else 0))
        }
        return w
    }

    private fun judulSeksi(isi: String, ket: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(6))
        r.addView(teks(isi, 13f, pal.mu, true), lp(lebar = 0, bobot = 1f))
        r.addView(teks(ket, 12f, pal.mu))
        return r
    }

    private fun bangunCariMemori(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL
        val cari = Perekam.berjalan && Perekam.mode == 1
        val chip = buatChip("SIAP")
        cChip = chip
        akar.addView(kepala("Cari", "Temukan bagian game yang berubah", chip, null), lp())
        akar.addView(segmen("Memori"), lp(kiri = dp(16), kanan = dp(16), bawah = dp(12)))

        val gulir = ScrollView(this)
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setPadding(dp(16), 0, dp(16), dp(8))

        val kCak = kartu(pal, 6)
        kCak.addView(teks("Cakupan memori", 13f, pal.mu, true))
        kCak.addView(barisCentang(pal, "Data akun, dibaca penuh", "16 KB", Perekam.cariAkun, !cari) { Perekam.cariAkun = it })
        kCak.addView(barisCentang(pal, "Data pertandingan, dibaca penuh", "4 KB", Perekam.cariMatch, !cari) { Perekam.cariMatch = it })
        kCak.addView(barisCentang(pal, "Hero sendiri, dibaca penuh", "4 KB", Perekam.cariHero, !cari) { Perekam.cariHero = it })
        kCak.addView(barisCentang(pal, "Tower musuh, dibaca penuh", "5 KB per tower", Perekam.cariTower, !cari) { Perekam.cariTower = it })
        kol.addView(kCak, lp(bawah = dp(12)))

        val s1 = kotakStat("sampel", 20f)
        val s2 = kotakStat("alamat berubah", 20f)
        val s3 = kotakStat("per putaran", 20f)
        cStat1 = s1.second
        cStat2 = s2.second
        cStat3 = s3.second
        kol.addView(barisStat(s1.first, s2.first, s3.first), lp(bawah = dp(12)))
        kol.addView(
            paragraf(
                "Mode cari membaca seluruh objek (bukan hanya field yang dikenal) tiap detik. " +
                    "Main satu match, lalu tekan Hentikan untuk melihat alamat yang berubah.",
                13f
            ),
            lp()
        )
        gulir.addView(kol)
        akar.addView(gulir, lp(tinggi = 0, bobot = 1f))

        val bawah = LinearLayout(this)
        bawah.orientation = LinearLayout.VERTICAL
        bawah.setPadding(dp(16), dp(12), dp(16), dp(14))
        if (cari) {
            bawah.addView(
                tombol("Hentikan dan lihat hasil", pal, 0, R.drawable.ic_stop) {
                    menungguHasil = true
                    Perekam.berhenti()
                },
                lp(tinggi = dp(56), bawah = dp(8))
            )
            bawah.addView(
                tombol("Tandai kejadian", pal, 1, R.drawable.ic_flag) {
                    startActivity(Intent(this, MarkerActivity::class.java))
                },
                lp(tinggi = dp(48))
            )
        } else {
            bawah.addView(tombol("Mulai mode cari", pal, 0) { mulaiCari() }, lp(tinggi = dp(56)))
        }
        akar.addView(bawah, lp())
        return akar
    }

    private fun gayaArea(a: String): Int = if (a == "AKUN") 0 else 1

    private fun barisHasil(hs: Hasil): View {
        val baris = LinearLayout(this)
        baris.orientation = LinearLayout.HORIZONTAL
        baris.gravity = Gravity.TOP
        baris.setPadding(dp(16), dp(10), dp(16), dp(10))

        val cb = CheckBox(this)
        cb.isChecked = hs.centang
        cb.buttonTintList = ColorStateList.valueOf(pal.acc)
        cb.setOnCheckedChangeListener { _, ok -> hs.centang = ok }
        baris.addView(cb, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kanan = dp(8)))

        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        val l1 = LinearLayout(this)
        l1.orientation = LinearLayout.HORIZONTAL
        l1.gravity = Gravity.CENTER_VERTICAL
        l1.addView(chipTeks(pal, hs.area, gayaArea(hs.area)))
        val off = teks("+" + hs.offset, 13f, pal.tx, true)
        off.typeface = Typeface.MONOSPACE
        l1.addView(off, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(6)))
        if (hs.nama != null) {
            val nm = teks(hs.nama, 12.5f, pal.mu)
            nm.typeface = Typeface.MONOSPACE
            nm.maxLines = 1
            nm.ellipsize = TextUtils.TruncateAt.END
            l1.addView(nm, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(6)))
        }
        l1.addView(
            chipTeks(pal, if (hs.tagBaru) "BARU" else "DIKENAL", if (hs.tagBaru) 2 else 3),
            lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(6))
        )
        kol.addView(l1, lp())

        val s = SpannableStringBuilder()
        s.append(hs.lama).append(" → ")
        val mulai = s.length
        s.append(hs.baru)
        s.setSpan(ForegroundColorSpan(pal.tx), mulai, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), mulai, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.append(if (hs.kategori == 1) "   diam sejak @" else "   @").append(Penelusur.mmss(hs.waktuMs))
        if (hs.ket != null) s.append("   ").append(hs.ket)
        val l2 = teks("", 13f, pal.mu)
        l2.text = s
        l2.typeface = Typeface.MONOSPACE
        kol.addView(l2, lp(atas = dp(5)))
        baris.addView(kol, lp(lebar = 0, bobot = 1f))
        return baris
    }

    private fun bangunHasil(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL
        val fmt = SimpleDateFormat("HH:mm", Locale.US)
        val sub = fmt.format(Date(Penelusur.mulaiWall)) + " sampai " + fmt.format(Date(Penelusur.akhirWall)) +
            " · " + angka(Penelusur.sampel) + " sampel"
        akar.addView(kepala("Hasil cari", sub, null, null), lp())

        val gulir = ScrollView(this)
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setPadding(dp(16), 0, dp(16), dp(8))

        val a = kotakStat("alamat berubah", 18f)
        a.second.text = angka(Penelusur.berubah)
        val b = kotakStat("gangguan disembunyikan", 18f)
        b.second.text = angka(Penelusur.gangguan)
        val ringkas = LinearLayout(this)
        ringkas.orientation = LinearLayout.HORIZONTAL
        ringkas.addView(a.first, lp(lebar = 0, bobot = 1f, kanan = dp(8)))
        ringkas.addView(b.first, lp(lebar = 0, bobot = 1f))
        kol.addView(ringkas, lp(bawah = dp(10)))

        val daftarKartu = LinearLayout(this)
        daftarKartu.orientation = LinearLayout.VERTICAL
        daftarKartu.background = bentuk(pal.surf, 16, pal.bd)
        daftarKartu.clipToOutline = true
        val batas = 60
        var total = 0
        for (kat in 0..1) total += minOf(batas, Penelusur.hasil.count { it.kategori == kat })
        var urut = 0
        for (kat in 0..1) {
            val semua = Penelusur.hasil.filter { it.kategori == kat }
            if (semua.isEmpty()) continue
            daftarKartu.addView(
                judulSeksi(
                    if (kat == 0) "Berubah sekali" else "Seperti penghitung",
                    if (kat == 0) "kandidat sakelar" else "berubah lalu diam"
                )
            )
            for (hs in semua.take(batas)) {
                daftarKartu.addView(barisHasil(hs))
                urut++
                if (urut < total) daftarKartu.addView(garisBawah(pal))
            }
            if (semua.size > batas) {
                val lagi = teks("+" + (semua.size - batas) + " lagi, lihat di berkas yang dibagikan", 12f, pal.mu)
                lagi.setPadding(dp(16), dp(6), dp(16), dp(10))
                daftarKartu.addView(lagi)
            }
        }
        if (total == 0) {
            val kosong = teks("Tidak ada alamat yang berubah selama pencarian.", 13f, pal.mu)
            kosong.setPadding(dp(16), dp(16), dp(16), dp(16))
            daftarKartu.addView(kosong)
        }
        kol.addView(daftarKartu, lp(bawah = dp(10)))
        kol.addView(
            paragraf(
                "Yang dicentang akan dipantau rapat, dan yang lain berhenti dibaca. " +
                    "Alamat dengan tanda BARU belum ada di tabel script.",
                12f
            ),
            lp()
        )
        gulir.addView(kol)
        akar.addView(gulir, lp(tinggi = 0, bobot = 1f))

        val bawah = LinearLayout(this)
        bawah.orientation = LinearLayout.VERTICAL
        bawah.setPadding(dp(16), dp(12), dp(16), dp(14))
        bawah.addView(tombol("Pantau yang dicentang saja", pal, 0) { pantauTerpilih() }, lp(tinggi = dp(56), bawah = dp(8)))
        bawah.addView(
            tombol("Bagikan hasil", pal, 1, R.drawable.ic_share) { bagikanBerkas(Perekam.berkasHasil, "Kirim hasil cari") },
            lp(tinggi = dp(48))
        )
        akar.addView(bawah, lp())
        return akar
    }

    private fun kb(b: Long, bertanda: Boolean): String {
        val s = String.format(idn, "%.1f", Math.abs(b) / 1024.0)
        val awal = if (!bertanda) "" else if (b < 0) "−" else "+"
        return "$awal$s KB"
    }

    private fun pathPendek(p: String): String {
        val bagian = p.trimEnd('/').split('/')
        return if (bagian.size <= 2) p else ".../" + bagian.takeLast(2).joinToString("/")
    }

    private fun barisFile(p: PemindaiFile.Perubahan): View {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(dp(16), dp(10), dp(16), dp(10))
        val atas = LinearLayout(this)
        atas.orientation = LinearLayout.HORIZONTAL
        atas.gravity = Gravity.CENTER_VERTICAL
        val gaya = when (p.jenis) {
            "DIUBAH" -> 1
            "BARU" -> 2
            else -> 0
        }
        atas.addView(chipTeks(pal, p.jenis, gaya))
        val path = teks(pathPendek(p.path), 12.5f, pal.tx)
        path.typeface = Typeface.MONOSPACE
        path.maxLines = 1
        path.ellipsize = TextUtils.TruncateAt.START
        atas.addView(path, lp(lebar = 0, bobot = 1f, kiri = dp(8)))
        v.addView(atas, lp())
        val jam = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(p.waktu))
        val meta = when (p.jenis) {
            "DIUBAH" -> "diubah $jam · " + kb(p.selisih, true)
            "BARU" -> "dibuat $jam · " + kb(p.ukuran, false)
            else -> "dihapus · " + kb(p.ukuran, false)
        }
        v.addView(teks(meta, 12f, pal.mu), lp(atas = dp(5)))
        return v
    }

    private fun bangunCariFile(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL
        akar.addView(kepala("Cari", "Temukan bagian game yang berubah", null, null), lp())
        akar.addView(segmen("File"), lp(kiri = dp(16), kanan = dp(16), bawah = dp(12)))

        val gulir = ScrollView(this)
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setPadding(dp(16), 0, dp(16), dp(8))

        val kFold = kartu(pal, 6)
        kFold.addView(teks("Folder yang dipindai", 13f, pal.mu, true))
        kFold.addView(barisCentang(pal, "Data game di Multi Run", "dibaca lewat run-as", PemindaiFile.runAs, !PemindaiFile.sedang) {
            PemindaiFile.runAs = it
        })
        kFold.addView(barisCentang(pal, "Folder Android/data game", "jika bisa dibaca", PemindaiFile.androidData, !PemindaiFile.sedang) {
            PemindaiFile.androidData = it
        })
        kol.addView(kFold, lp(bawah = dp(12)))

        val awal = PemindaiFile.awal
        val kLang = kartu(pal, 12)
        val barisAwal = LinearLayout(this)
        barisAwal.orientation = LinearLayout.HORIZONTAL
        barisAwal.addView(teks("Daftar awal", 14f, pal.tx), lp(lebar = 0, bobot = 1f))
        val nilaiAwal = if (awal == null) {
            "Belum diambil"
        } else {
            angka(awal.size) + " berkas · " + SimpleDateFormat("HH:mm", Locale.US).format(Date(PemindaiFile.waktuAwal))
        }
        barisAwal.addView(teks(nilaiAwal, 14f, pal.acc, true))
        kLang.addView(barisAwal)
        val ket = if (PemindaiFile.sedang) {
            "Memindai..."
        } else if (PemindaiFile.pesan.isNotEmpty()) {
            PemindaiFile.pesan
        } else if (awal == null) {
            "Ambil daftar awal sebelum main satu match."
        } else {
            "Sudah diambil. Main satu match, lalu bandingkan."
        }
        kLang.addView(paragraf(ket, 12f), lp(atas = dp(8)))
        kol.addView(kLang, lp(bawah = dp(12)))

        if (PemindaiFile.adaHasil) {
            val kHas = LinearLayout(this)
            kHas.orientation = LinearLayout.VERTICAL
            kHas.background = bentuk(pal.surf, 16, pal.bd)
            kHas.clipToOutline = true
            val hasil = PemindaiFile.hasil
            kHas.addView(judulSeksi("Berubah selama match", angka(hasil.size) + " berkas"))
            val tampilkan = hasil.take(100)
            for ((i, p) in tampilkan.withIndex()) {
                kHas.addView(barisFile(p))
                if (i < tampilkan.size - 1) kHas.addView(garisBawah(pal))
            }
            if (hasil.isEmpty()) {
                val kosong = teks("Tidak ada berkas yang berubah.", 13f, pal.mu)
                kosong.setPadding(dp(16), dp(4), dp(16), dp(16))
                kHas.addView(kosong)
            }
            if (hasil.size > 100) {
                val lagi = teks("+" + (hasil.size - 100) + " lagi", 12f, pal.mu)
                lagi.setPadding(dp(16), dp(6), dp(16), dp(10))
                kHas.addView(lagi)
            }
            kol.addView(kHas, lp(bawah = dp(10)))
        } else {
            kol.addView(paragraf("Hasil muncul di sini setelah dibandingkan.", 12f), lp())
        }
        gulir.addView(kol)
        akar.addView(gulir, lp(tinggi = 0, bobot = 1f))

        val bawah = LinearLayout(this)
        bawah.orientation = LinearLayout.VERTICAL
        bawah.setPadding(dp(16), dp(12), dp(16), dp(14))
        val utama = tombol(if (awal == null) "Ambil daftar awal" else "Bandingkan sekarang", pal, 0) {
            if (PemindaiFile.awal == null) {
                simpanPengaturan()
                PemindaiFile.ambilAwal(this, Perekam.paket)
            } else {
                PemindaiFile.bandingkan(Perekam.paket)
            }
        }
        utama.isEnabled = !PemindaiFile.sedang
        utama.alpha = if (PemindaiFile.sedang) 0.5f else 1f
        bawah.addView(utama, lp(tinggi = dp(56)))
        if (awal != null) {
            val ulang = tombol("Ambil daftar awal ulang", pal, 1) {
                simpanPengaturan()
                PemindaiFile.ambilAwal(this, Perekam.paket)
            }
            ulang.isEnabled = !PemindaiFile.sedang
            ulang.alpha = if (PemindaiFile.sedang) 0.5f else 1f
            bawah.addView(ulang, lp(tinggi = dp(48), atas = dp(8)))
        }
        akar.addView(bawah, lp())
        return akar
    }

    private fun tampilkanCari() {
        tutupKeyboard()
        cChip = null
        cStat1 = null
        cStat2 = null
        cStat3 = null
        val v = when (cariLayar) {
            1 -> bangunHasil()
            2 -> bangunCariFile()
            else -> bangunCariMemori()
        }
        kontenCari.removeAllViews()
        kontenCari.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------
    // Aksi

    private fun klikUtama() {
        if (Perekam.berjalan) {
            startActivity(Intent(this, MarkerActivity::class.java))
        } else {
            mulaiRekam()
        }
    }

    private fun klikKedua() {
        if (Perekam.berjalan) {
            if (Perekam.mode == 1) menungguHasil = true
            Perekam.berhenti()
        } else {
            ShizukuHelper.requestPermission()
        }
    }

    private fun mulaiLayanan() {
        simpanPengaturan()
        if (ShizukuHelper.isRunning() && !ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        try {
            startForegroundService(Intent(this, LayananPerekam::class.java))
        } catch (e: Throwable) {
            Toast.makeText(this, "Gagal memulai: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun mulaiRekam() {
        Perekam.mode = 0
        Perekam.terpilih = null
        mulaiLayanan()
    }

    private fun mulaiCari() {
        Perekam.mode = 1
        Perekam.terpilih = null
        menungguHasil = false
        mulaiLayanan()
    }

    // Pantau rapat hanya alamat yang dicentang dari hasil cari
    private fun pantauTerpilih() {
        val pilih = Penelusur.hasil.filter { it.centang }
        if (pilih.isEmpty()) {
            toast("Centang minimal satu alamat")
            return
        }
        if (Perekam.berjalan) {
            toast("Masih ada perekaman berjalan")
            return
        }
        Perekam.mode = 0
        Perekam.terpilih = pilih
        mulaiLayanan()
        pilihTab(0)
    }

    private fun bagikan() {
        Perekam.flush()
        bagikanBerkas(Perekam.berkas, "Kirim berkas log")
    }

    private fun bagikanBerkas(f: File?, judul: String) {
        if (f == null || !f.exists() || f.length() == 0L) {
            toast("Belum ada berkas")
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.berkas", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, judul))
        } catch (e: Throwable) {
            Toast.makeText(this, "Gagal membagikan: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------
    // Penyegaran tampilan (tiap 0,5 detik)

    private fun perbarui() {
        val jalan = Perekam.berjalan
        val cari = jalan && Perekam.mode == 1
        setChip(tvChip, jalan, if (jalan) (if (cari) "MENCARI " else "MEREKAM ") + Perekam.durasi() else "SIAP")

        val sz = ShizukuHelper.isRunning()
        if (!sz) {
            setKoneksi(tvShizuku, "Tidak aktif", false)
        } else if (ShizukuHelper.hasPermission()) {
            setKoneksi(tvShizuku, "Tersambung", true)
        } else {
            setKoneksi(tvShizuku, "Belum diizinkan", false)
        }
        setKoneksi(tvMulti, if (jalan) Perekam.statusMulti else "-", jalan && Perekam.statusMulti == "Bisa dibaca")
        setKoneksi(tvGame, if (jalan) Perekam.statusGame else "-", jalan && Perekam.statusGame.startsWith("PID"))

        val pesan = if (jalan) Perekam.pesan else ""
        tvPesan.text = pesan
        tvPesan.visibility = if (pesan.isEmpty()) View.GONE else View.VISIBLE

        tvJumlah.text = angka(Perekam.jumlah)
        tvHz.text = if (jalan) String.format(idn, "%.0f×", Perekam.hzNyata) else "-"
        tvUkuran.text = angka((Perekam.ukuranBerkas() / 1024).toInt()) + " KB"

        btnUtama.text = if (jalan) "Tandai kejadian" else "Mulai merekam"
        pasangIkon(btnUtama, if (jalan) R.drawable.ic_flag else 0, pal.onAcc)
        if (jalan) {
            btnKedua.visibility = View.VISIBLE
            btnKedua.text = "Berhenti merekam"
            pasangIkon(btnKedua, R.drawable.ic_stop, pal.tx)
        } else if (!ShizukuHelper.hasPermission()) {
            btnKedua.visibility = View.VISIBLE
            btnKedua.text = "Izinkan Shizuku"
            pasangIkon(btnKedua, 0, pal.tx)
        } else {
            btnKedua.visibility = View.GONE
        }

        if (tab == 1 && Perekam.versi != versiTampil) {
            versiTampil = Perekam.versi
            tampil = Perekam.salinan(filter, 200)
            adapter.notifyDataSetChanged()
            tvHitung.text = "Menampilkan " + angka(tampil.size) + " dari " + angka(Perekam.jumlah) +
                " perubahan, terbaru di atas"
        }

        if (menungguHasil && !Perekam.berjalan && Penelusur.siap) {
            menungguHasil = false
            cariLayar = 1
            sigCari = ""
        }
        if (tab == 2) {
            val sig = when (cariLayar) {
                1 -> "h|" + Penelusur.hasil.size + "|" + Penelusur.akhirWall
                2 -> "f|" + PemindaiFile.sedang + "|" + PemindaiFile.adaHasil + "|" + PemindaiFile.hasil.size +
                    "|" + PemindaiFile.waktuAwal + "|" + PemindaiFile.pesan
                else -> "m|" + cari
            }
            if (sig != sigCari) {
                sigCari = sig
                tampilkanCari()
            }
            if (cariLayar == 0) {
                val c = cChip
                if (c != null) setChip(c, cari, if (cari) "MENCARI " + Perekam.durasi() else "SIAP")
                cStat1?.text = if (cari) angka(Perekam.cariSampel) else "-"
                cStat2?.text = if (cari) angka(Perekam.cariBerubah) else "-"
                cStat3?.text = if (cari && Perekam.rataMs > 0) Perekam.rataMs.toInt().toString() + " ms" else "-"
            }
        }
    }
}
