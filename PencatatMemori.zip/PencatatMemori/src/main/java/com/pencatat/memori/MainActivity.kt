package com.pencatat.memori

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

// Tampilan dimuat dari assets/ui/index.html (desain yang sama dengan artefak, lengkap dengan font dan animasinya).
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        CheatCfg.init(this)
        window.statusBarColor = 0xFF09090B.toInt()
        window.navigationBarColor = 0xFF09090B.toInt()
        if (Build.VERSION.SDK_INT >= 33) {
            try { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) } catch (_: Throwable) {}
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF09090B.toInt())
        web = WebView(this)
        web.setBackgroundColor(0xFF09090B.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            textZoom = 100
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            if (Build.VERSION.SDK_INT >= 33) isAlgorithmicDarkeningAllowed = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) AppLog.add("UI error: ${m.message()} (${m.lineNumber()})")
                return true
            }
        }
        web.addJavascriptInterface(Jembatan(this), "Native")
        web.loadUrl("file:///android_asset/ui/index.html")
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Root memegang fokus: kalau keyboard sudah tidak dipakai, fokus isian dilepas (seperti claim-vg)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        var imeWas = false
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val vis = try { root.rootWindowInsets?.isVisible(android.view.WindowInsets.Type.ime()) == true } catch (_: Throwable) { false }
            if (vis != imeWas) {
                imeWas = vis
                if (!vis) {
                    web.evaluateJavascript("(function(){var a=document.activeElement;if(a&&a.tagName==='INPUT')a.blur()})()", null)
                    web.clearFocus()
                    root.requestFocus()
                }
            }
        }
        setContentView(root)

        // Tombol kembali: dari Log/Pengaturan balik ke Beranda, di Beranda keluar biasa
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){if(popBack())return 1;if(page!==0){go(0);return 1}return 0})()") { r ->
                    if (r != "1") { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        // Layanan aksesibilitas yang ikut mati karena proses mati dinyalakan lagi otomatis
        if (AutoService.inst == null && AutoAccess.granted(this)) {
            Thread { AutoAccess.siapkan(applicationContext, 3000) { AppLog.add(it) } }.apply { isDaemon = true; start() }
        }
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("Native")
        web.destroy()
        super.onDestroy()
    }
}
