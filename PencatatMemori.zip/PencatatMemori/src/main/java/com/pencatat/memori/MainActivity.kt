package com.pencatat.memori

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Dua layar sesuai mockup: Beranda (kontrol dan status) dan Aktivitas (perubahan langsung).
class MainActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var sp: SharedPreferences
    private val h = Handler(Looper.getMainLooper())

    private var tab = 0
    private var filter = "Semua"
    private var versiTampil = -1
    private var tampil: List<Perekam.Kejadian> = emptyList()

    private lateinit var tvChip: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var tvMulti: TextView
    private lateinit var tvGame: TextView
    private lateinit var tvJumlah: TextView
    private lateinit var tvHz: TextView
    private lateinit var tvUkuran: TextView
    private lateinit var tvPesan: TextView
    private lateinit var btnUtama: Button
    private lateinit var btnKedua: Button
    private lateinit var btnHz: Button
    private lateinit var kontenBeranda: View
    private lateinit var kontenAktivitas: View
    private lateinit var tvHitung: TextView
    private lateinit var daftarView: ListView
    private lateinit var adapter: BaseAdapter
    private lateinit var navBeranda: Button
    private lateinit var navAktivitas: Button
    private val chipFilter = ArrayList<Button>()

    private val pilihanHz = intArrayOf(2, 5, 10, 20)

    private val segar = object : Runnable {
        override fun run() {
            perbarui()
            h.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gelap = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        pal = Pal(gelap)
        sp = getSharedPreferences("pencatat", Context.MODE_PRIVATE)
        muatPengaturan()

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.surf
        if (!gelap) {
            window.insetsController?.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
        setContentView(bangunUi())
        pilihTab(0)
        perbarui()
    }

    override fun onResume() {
        super.onResume()
        h.removeCallbacks(segar)
        h.post(segar)
    }

    override fun onPause() {
        h.removeCallbacks(segar)
        simpanPengaturan()
        super.onPause()
    }

    // ------------------------------------------------------------------
    // Pengaturan

    private fun muatPengaturan() {
        Perekam.paket = sp.getString("paket", "com.dong.multirun") ?: "com.dong.multirun"
        Perekam.hz = sp.getInt("hz", 5)
        Perekam.deteksiLag = sp.getBoolean("lag", true)
        Perekam.areaAkun = sp.getBoolean("akun", true)
        Perekam.areaMatch = sp.getBoolean("match", true)
        Perekam.areaHero = sp.getBoolean("hero", true)
    }

    private fun simpanPengaturan() {
        sp.edit()
            .putString("paket", Perekam.paket)
            .putInt("hz", Perekam.hz)
            .putBoolean("lag", Perekam.deteksiLag)
            .putBoolean("akun", Perekam.areaAkun)
            .putBoolean("match", Perekam.areaMatch)
            .putBoolean("hero", Perekam.areaHero)
            .apply()
    }

    // ------------------------------------------------------------------
    // Susunan layar

    private fun bangunUi(): View {
        val akar = LinearLayout(this)
        akar.orientation = LinearLayout.VERTICAL
        akar.setBackgroundColor(pal.bg)

        kontenBeranda = bangunBeranda()
        kontenAktivitas = bangunAktivitas()
        akar.addView(kontenBeranda, lp(tinggi = 0, bobot = 1f))
        akar.addView(kontenAktivitas, lp(tinggi = 0, bobot = 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(pal.surf)
        navBeranda = tombolNav("Beranda") { pilihTab(0) }
        navAktivitas = tombolNav("Aktivitas") { pilihTab(1) }
        nav.addView(navBeranda, lp(lebar = 0, bobot = 1f))
        nav.addView(navAktivitas, lp(lebar = 0, bobot = 1f))
        akar.addView(nav, lp())
        return akar
    }

    private fun tombolNav(label: String, klik: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.stateListAnimator = null
        b.background = null
        b.minHeight = dp(56)
        b.minimumHeight = dp(56)
        b.setOnClickListener { klik() }
        return b
    }

    private fun pilihTab(t: Int) {
        tab = t
        kontenBeranda.visibility = if (t == 0) View.VISIBLE else View.GONE
        kontenAktivitas.visibility = if (t == 1) View.VISIBLE else View.GONE
        navBeranda.setTextColor(if (t == 0) pal.acc else pal.mu)
        navAktivitas.setTextColor(if (t == 1) pal.acc else pal.mu)
        navBeranda.typeface = if (t == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        navAktivitas.typeface = if (t == 1) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        versiTampil = -1
        perbarui()
    }

    private fun kartu(): LinearLayout {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.VERTICAL
        k.background = bentuk(pal.surf, 16, pal.bd)
        k.setPadding(dp(16), dp(14), dp(16), dp(14))
        return k
    }

    private fun judulKartu(s: String): TextView = teks(s, 13f, pal.mu, true)

    // Satu baris "label ........ nilai"; mengembalikan TextView nilai
    private fun barisNilai(induk: LinearLayout, label: String): TextView {
        val baris = LinearLayout(this)
        baris.orientation = LinearLayout.HORIZONTAL
        baris.gravity = Gravity.CENTER_VERTICAL
        baris.addView(teks(label, 14f, pal.tx), lp(lebar = 0, bobot = 1f))
        val nilai = teks("-", 14f, pal.acc, true)
        baris.addView(nilai)
        induk.addView(baris, lp(atas = dp(10)))
        return nilai
    }

    private fun kotakStat(label: String): Pair<LinearLayout, TextView> {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.VERTICAL
        k.background = bentuk(pal.surf, 14, pal.bd)
        k.setPadding(dp(12), dp(12), dp(12), dp(12))
        val nilai = teks("-", 19f, pal.tx, true)
        k.addView(nilai)
        k.addView(teks(label, 12f, pal.mu))
        return Pair(k, nilai)
    }

    private fun centang(label: String, ket: String, nyala: Boolean, aktif: Boolean, ubah: (Boolean) -> Unit): View {
        val baris = LinearLayout(this)
        baris.orientation = LinearLayout.HORIZONTAL
        baris.gravity = Gravity.CENTER_VERTICAL
        baris.minimumHeight = dp(48)
        val cb = CheckBox(this)
        cb.isChecked = nyala
        cb.isEnabled = aktif
        cb.buttonTintList = ColorStateList.valueOf(if (aktif) pal.acc else pal.mu)
        cb.setOnCheckedChangeListener { _, ok -> ubah(ok) }
        baris.addView(cb)
        baris.addView(teks(label, 14f, if (aktif) pal.tx else pal.mu), lp(lebar = 0, bobot = 1f))
        baris.addView(teks(ket, 12f, pal.mu))
        return baris
    }

    private fun bangunBeranda(): View {
        val gulir = ScrollView(this)
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.setPadding(dp(16), dp(12), dp(16), dp(16))

        // Kepala
        val kepala = LinearLayout(this)
        kepala.orientation = LinearLayout.HORIZONTAL
        kepala.gravity = Gravity.CENTER_VERTICAL
        val judul = LinearLayout(this)
        judul.orientation = LinearLayout.VERTICAL
        judul.addView(teks("Pencatat Memori", 20f, pal.tx, true))
        judul.addView(teks("Membaca data game lewat Shizuku", 13f, pal.mu))
        kepala.addView(judul, lp(lebar = 0, bobot = 1f))
        tvChip = teks("SIAP", 12f, pal.acc, true)
        tvChip.background = bentuk(0, 20, pal.acc)
        tvChip.setPadding(dp(10), dp(6), dp(10), dp(6))
        kepala.addView(tvChip)
        kol.addView(kepala, lp(bawah = dp(12)))

        // Koneksi
        val kKon = kartu()
        kKon.addView(judulKartu("Koneksi"))
        tvShizuku = barisNilai(kKon, "Shizuku")
        tvMulti = barisNilai(kKon, "Multi Run")
        tvGame = barisNilai(kKon, "Game")
        kol.addView(kKon, lp(bawah = dp(12)))

        tvPesan = teks("", 13f, pal.ambTx)
        tvPesan.background = bentuk(pal.ambBg, 12)
        tvPesan.setPadding(dp(12), dp(10), dp(12), dp(10))
        kol.addView(tvPesan, lp(bawah = dp(12)))

        // Statistik
        val stat = LinearLayout(this)
        stat.orientation = LinearLayout.HORIZONTAL
        val s1 = kotakStat("perubahan")
        val s2 = kotakStat("baca per detik")
        val s3 = kotakStat("ukuran berkas")
        tvJumlah = s1.second
        tvHz = s2.second
        tvUkuran = s3.second
        stat.addView(s1.first, lp(lebar = 0, bobot = 1f, kanan = dp(8)))
        stat.addView(s2.first, lp(lebar = 0, bobot = 1f, kanan = dp(8)))
        stat.addView(s3.first, lp(lebar = 0, bobot = 1f))
        kol.addView(stat, lp(bawah = dp(12)))

        // Area dipantau
        val kArea = kartu()
        kArea.addView(judulKartu("Area dipantau"))
        kArea.addView(centang("Data akun", "${Daftar.AKUN.size} field", Perekam.areaAkun, true) {
            Perekam.areaAkun = it
        })
        kArea.addView(centang("Data pertandingan", "${Daftar.MATCH.size} field", Perekam.areaMatch, true) {
            Perekam.areaMatch = it
        })
        kArea.addView(centang("Hero sendiri", "lompatan posisi, flag", Perekam.areaHero, true) {
            Perekam.areaHero = it
        })
        kArea.addView(centang("Tower musuh", "tahap berikutnya", false, false) { })
        kol.addView(kArea, lp(bawah = dp(12)))

        // Setelan
        val kSet = kartu()
        kSet.addView(judulKartu("Setelan"))
        kSet.addView(teks("Paket Multi Run", 13f, pal.tx), lp(atas = dp(10)))
        val isiPaket = EditText(this)
        isiPaket.setText(Perekam.paket)
        isiPaket.setTextColor(pal.tx)
        isiPaket.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        isiPaket.background = bentuk(pal.surf2, 12)
        isiPaket.setPadding(dp(12), dp(10), dp(12), dp(10))
        isiPaket.setOnFocusChangeListener { _, fokus ->
            if (!fokus) {
                val t = isiPaket.text.toString().trim()
                if (t.isNotEmpty()) Perekam.paket = t
            }
        }
        kSet.addView(isiPaket, lp(atas = dp(4)))
        btnHz = tombol("", pal, 2) {
            var i = 0
            for (k in pilihanHz.indices) if (pilihanHz[k] == Perekam.hz) i = k
            Perekam.hz = pilihanHz[(i + 1) % pilihanHz.size]
            perbarui()
        }
        kSet.addView(btnHz, lp(atas = dp(10)))
        kSet.addView(centang("Deteksi lag otomatis", "eksperimen", Perekam.deteksiLag, true) {
            Perekam.deteksiLag = it
        })
        kol.addView(kSet, lp(bawah = dp(12)))

        // Tombol
        btnUtama = tombol("Mulai merekam", pal, 0) { klikUtama() }
        btnKedua = tombol("", pal, 1) { klikKedua() }
        kol.addView(btnUtama, lp(tinggi = dp(56), bawah = dp(8)))
        kol.addView(btnKedua, lp(tinggi = dp(48)))

        gulir.addView(kol)
        return gulir
    }

    private fun bangunAktivitas(): View {
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL

        val kepala = LinearLayout(this)
        kepala.orientation = LinearLayout.HORIZONTAL
        kepala.gravity = Gravity.CENTER_VERTICAL
        kepala.setPadding(dp(20), dp(14), dp(16), dp(6))
        kepala.addView(teks("Aktivitas", 20f, pal.tx, true), lp(lebar = 0, bobot = 1f))
        kepala.addView(tombol("Bagikan berkas", pal, 1) { bagikan() }, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT))
        kol.addView(kepala, lp())

        val gulirChip = HorizontalScrollView(this)
        gulirChip.isHorizontalScrollBarEnabled = false
        val barisChip = LinearLayout(this)
        barisChip.orientation = LinearLayout.HORIZONTAL
        barisChip.setPadding(dp(16), dp(4), dp(16), dp(4))
        for (nama in listOf("Semua", "Akun", "Pertandingan", "Hero", "Tanda", "Otomatis")) {
            val c = Button(this)
            c.text = nama
            c.isAllCaps = false
            c.stateListAnimator = null
            c.minHeight = dp(44)
            c.minimumHeight = dp(44)
            c.setPadding(dp(14), 0, dp(14), 0)
            c.setOnClickListener {
                filter = nama
                versiTampil = -1
                warnaiChip()
                perbarui()
            }
            chipFilter.add(c)
            barisChip.addView(c, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kanan = dp(8)))
        }
        gulirChip.addView(barisChip)
        kol.addView(gulirChip, lp())
        warnaiChip()

        tvHitung = teks("", 12f, pal.mu)
        tvHitung.setPadding(dp(20), dp(2), dp(20), dp(6))
        kol.addView(tvHitung, lp())

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = tampil.size
            override fun getItem(position: Int): Any = tampil[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
                barisView(tampil[position])
        }
        daftarView = ListView(this)
        daftarView.adapter = adapter
        daftarView.divider = null
        daftarView.background = bentuk(pal.surf, 16, pal.bd)
        kol.addView(daftarView, lp(tinggi = 0, bobot = 1f, kiri = dp(16), kanan = dp(16), bawah = dp(12)))
        return kol
    }

    private fun warnaiChip() {
        for (c in chipFilter) {
            val on = c.text.toString() == filter
            c.background = if (on) bentuk(pal.acc, 22) else bentuk(0, 22, pal.bd)
            c.setTextColor(if (on) pal.onAcc else pal.tx)
            c.typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun barisView(k: Perekam.Kejadian): View {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(dp(16), dp(10), dp(16), dp(10))
        val tanda = k.tipe == "TANDA"
        if (tanda) v.setBackgroundColor(pal.ambBg)

        val atas = LinearLayout(this)
        atas.orientation = LinearLayout.HORIZONTAL
        atas.gravity = Gravity.CENTER_VERTICAL
        val jam = SimpleDateFormat("HH:mm:ss.S", Locale.US).format(Date(k.waktu))
        val tvJam = teks(jam, 12f, if (tanda) pal.ambTx else pal.mu)
        tvJam.typeface = Typeface.MONOSPACE
        atas.addView(tvJam)

        val chip = teks(k.tipe, 11f, pal.tx, true)
        var isiChip = pal.surf2
        var warnaTeks = pal.tx
        when (k.tipe) {
            "PERTANDINGAN", "HERO" -> {
                isiChip = pal.bluBg
                warnaTeks = pal.bluTx
            }
            "TANDA" -> {
                isiChip = pal.ambBg
                warnaTeks = pal.ambTx
            }
            "OTOMATIS" -> {
                isiChip = pal.surf2
                warnaTeks = pal.acc
            }
        }
        chip.setTextColor(warnaTeks)
        chip.background = bentuk(isiChip, 6, if (k.tipe == "AKUN" || k.tipe == "OTOMATIS") pal.bd else 0)
        chip.setPadding(dp(7), dp(2), dp(7), dp(2))
        atas.addView(chip, lp(lebar = ViewGroup.LayoutParams.WRAP_CONTENT, kiri = dp(8)))
        if (k.ket != null) {
            val ket = teks(k.ket, 12f, if (tanda) pal.ambTx else pal.mu)
            ket.gravity = Gravity.END
            atas.addView(ket, lp(lebar = 0, bobot = 1f, kiri = dp(8)))
        }
        v.addView(atas, lp())

        val bawah: TextView
        if (tanda) {
            bawah = teks(k.judul, 14f, pal.ambTx, true)
        } else {
            val s = StringBuilder(k.judul)
            if (k.lama != null || k.baru != null) {
                s.append("   ").append(k.lama ?: "-").append(" → ").append(k.baru ?: "-")
            }
            bawah = teks(s.toString(), 13f, pal.tx)
            bawah.typeface = Typeface.MONOSPACE
        }
        v.addView(bawah, lp(atas = dp(4)))
        return v
    }

    // ------------------------------------------------------------------
    // Aksi

    private fun klikUtama() {
        if (Perekam.berjalan) {
            startActivity(Intent(this, MarkerActivity::class.java))
        } else {
            mulaiRekam()
        }
    }

    private fun klikKedua() {
        if (Perekam.berjalan) {
            Perekam.berhenti()
        } else {
            ShizukuHelper.requestPermission()
        }
    }

    private fun mulaiRekam() {
        val t = (kontenBeranda.findFocus() as? EditText)?.text?.toString()?.trim()
        if (!t.isNullOrEmpty()) Perekam.paket = t
        simpanPengaturan()
        if (ShizukuHelper.isRunning() && !ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        try {
            startForegroundService(Intent(this, LayananPerekam::class.java))
        } catch (e: Throwable) {
            Toast.makeText(this, "Gagal memulai: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun bagikan() {
        Perekam.flush()
        val f = Perekam.berkas
        if (f == null || !f.exists() || f.length() == 0L) {
            Toast.makeText(this, "Belum ada berkas", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.berkas", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Kirim berkas log"))
        } catch (e: Throwable) {
            Toast.makeText(this, "Gagal membagikan: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------
    // Penyegaran tampilan (tiap 0,5 detik)

    private fun perbarui() {
        val jalan = Perekam.berjalan
        tvChip.text = if (jalan) "MEREKAM " + Perekam.durasi() else "SIAP"

        val sz = if (!ShizukuHelper.isRunning()) "Tidak aktif"
        else if (ShizukuHelper.hasPermission()) "Tersambung" else "Belum diizinkan"
        tvShizuku.text = sz
        tvMulti.text = if (jalan) Perekam.statusMulti else "-"
        tvGame.text = if (jalan) Perekam.statusGame else "-"

        val pesan = if (jalan) Perekam.pesan else ""
        tvPesan.text = pesan
        tvPesan.visibility = if (pesan.isEmpty()) View.GONE else View.VISIBLE

        tvJumlah.text = String.format(Locale.US, "%,d", Perekam.jumlah)
        tvHz.text = if (jalan) String.format(Locale.US, "%.1fx", Perekam.hzNyata) else "-"
        tvUkuran.text = String.format(Locale.US, "%d KB", Perekam.ukuranBerkas() / 1024)

        btnHz.text = "Baca per detik (target): ${Perekam.hz}x" +
            (if (jalan && Perekam.rataMs > 0) "   ·   ${Perekam.rataMs.toInt()} ms per putaran" else "")

        btnUtama.text = if (jalan) "Tandai kejadian" else "Mulai merekam"
        if (jalan) {
            btnKedua.visibility = View.VISIBLE
            btnKedua.text = "Berhenti merekam"
        } else if (sz != "Tersambung") {
            btnKedua.visibility = View.VISIBLE
            btnKedua.text = "Izinkan Shizuku"
        } else {
            btnKedua.visibility = View.GONE
        }

        if (tab == 1 && Perekam.versi != versiTampil) {
            versiTampil = Perekam.versi
            tampil = Perekam.salinan(filter, 200)
            adapter.notifyDataSetChanged()
            tvHitung.text = "Menampilkan ${tampil.size} dari ${Perekam.jumlah} perubahan, terbaru di atas"
        }
    }
}
