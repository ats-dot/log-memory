package com.pencatat.memori

import android.content.Context
import android.os.SystemClock
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Mesin perekam: membaca memori game berulang-ulang, membandingkan dengan bacaan
// sebelumnya, dan mencatat HANYA yang berubah (waktu, field, nilai lama -> baru).
object Perekam {

    class Kejadian(
        val waktu: Long,
        val tipe: String,
        val judul: String,
        val lama: String?,
        val baru: String?,
        val ket: String?
    )

    // ---- pengaturan (diisi dari layar Setelan) ----
    @Volatile var paket = "com.dong.multirun"
    @Volatile var hz = 5
    @Volatile var deteksiLag = true
    @Volatile var areaAkun = true
    @Volatile var areaMatch = true
    @Volatile var areaHero = true

    // ---- status untuk tampilan ----
    @Volatile var berjalan = false
    @Volatile var statusShizuku = "Belum dicek"
    @Volatile var statusMulti = "-"
    @Volatile var statusGame = "-"
    @Volatile var pesan = ""
    @Volatile var jumlah = 0
    @Volatile var versi = 0
    @Volatile var hzNyata = 0.0
    @Volatile var rataMs = 0.0
    @Volatile var mulaiMs = 0L
    @Volatile var berkas: File? = null

    private val kunci = Any()
    private val daftar = ArrayList<Kejadian>()
    private var tulis: BufferedWriter? = null

    @Volatile
    private var stopMinta = false
    private var thread: Thread? = null

    // ---- keadaan pembacaan ----
    private var prevAkun: LongArray? = null
    private var prevMatch: LongArray? = null
    private var prevHero: LongArray? = null
    private var lbmPtr = 0L
    private var heroPtr = 0L
    private var lbmCekMs = 0L
    private var posX = Float.NaN
    private var posY = Float.NaN
    private var statusSekarang = -1
    private var lagW0 = 0L
    private var lagG0 = 0L
    private var lagBuruk = 0
    private var lagTerakhir = 0L
    private var gagalBeruntun = 0
    private var hitungTick = 0
    private var jendelaMs = 0L

    private val iState = Daftar.indeks(Daftar.MATCH, "_m_eState")
    private val iSelf = Daftar.indeks(Daftar.MATCH, "m_RealSelfPlayer")
    private val iFrame = Daftar.indeks(Daftar.MATCH, "m_uiFrameTime")
    private val iMasuk = Daftar.indeks(Daftar.AKUN, "m_bEnterBattle")

    fun mulai(ctx: Context) {
        synchronized(kunci) {
            if (berjalan) return
            berjalan = true
            daftar.clear()
            jumlah = 0
            versi++
        }
        stopMinta = false
        mulaiMs = SystemClock.elapsedRealtime()
        pesan = ""
        siapkanBerkas(ctx.applicationContext)
        val t = Thread { loop() }
        t.isDaemon = true
        t.name = "perekam"
        thread = t
        t.start()
    }

    fun berhenti() {
        stopMinta = true
    }

    fun durasi(): String {
        if (mulaiMs == 0L) return "00:00"
        val d = (SystemClock.elapsedRealtime() - mulaiMs) / 1000
        return String.format(Locale.US, "%02d:%02d", d / 60, d % 60)
    }

    fun ukuranBerkas(): Long = berkas?.length() ?: 0L

    fun flush() {
        simpanBerkas()
    }

    // Tanda dari pengguna (tombol notifikasi atau layar)
    fun tanda(label: String) {
        catat("TANDA", label, null, null, ringkasKondisi())
    }

    fun salinan(filter: String, maks: Int): List<Kejadian> {
        val tipe = when (filter) {
            "Akun" -> "AKUN"
            "Pertandingan" -> "PERTANDINGAN"
            "Hero" -> "HERO"
            "Tanda" -> "TANDA"
            "Otomatis" -> "OTOMATIS"
            else -> ""
        }
        val hasil = ArrayList<Kejadian>()
        synchronized(kunci) {
            var i = daftar.size - 1
            while (i >= 0 && hasil.size < maks) {
                val k = daftar[i]
                if (tipe.isEmpty() || k.tipe == tipe) hasil.add(k)
                i--
            }
        }
        return hasil
    }

    fun formatBaris(k: Kejadian): String {
        val w = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(k.waktu))
        val sb = StringBuilder()
        sb.append(w).append(' ').append(k.tipe).append(' ').append(k.judul)
        if (k.lama != null || k.baru != null) {
            sb.append("  ").append(k.lama ?: "-").append(" -> ").append(k.baru ?: "-")
        }
        if (k.ket != null) sb.append("  (").append(k.ket).append(')')
        return sb.toString()
    }

    // ------------------------------------------------------------------

    private fun siapkanBerkas(ctx: Context) {
        try {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            val sp = ctx.getSharedPreferences("pencatat", Context.MODE_PRIVATE)
            val no = sp.getInt("sesi_no", 0) + 1
            sp.edit().putInt("sesi_no", no).apply()
            val f = File(dir, "Sesi_$no.txt")
            berkas = f
            tulis = BufferedWriter(OutputStreamWriter(FileOutputStream(f, true), Charsets.UTF_8))
            val tgl = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            baris("# Pencatat Memori, sesi $no, $tgl")
            baris("# paket=$paket hz=$hz deteksiLag=$deteksiLag area: akun=$areaAkun match=$areaMatch hero=$areaHero")
        } catch (e: Throwable) {
            tulis = null
        }
    }

    private fun baris(s: String) {
        synchronized(kunci) {
            try {
                tulis?.write(s)
                tulis?.newLine()
            } catch (e: Throwable) {
            }
        }
    }

    private fun simpanBerkas() {
        synchronized(kunci) {
            try {
                tulis?.flush()
            } catch (e: Throwable) {
            }
        }
    }

    private fun catat(tipe: String, judul: String, lama: String?, baru: String?, ket: String?) {
        val k = Kejadian(System.currentTimeMillis(), tipe, judul, lama, baru, ket)
        synchronized(kunci) {
            daftar.add(k)
            if (daftar.size > 800) daftar.removeAt(0)
            jumlah++
            versi++
            try {
                tulis?.write(formatBaris(k))
                tulis?.newLine()
            } catch (e: Throwable) {
            }
        }
    }

    private fun hex(v: Long): String = "0x" + java.lang.Long.toHexString(v)

    private fun ringkasKondisi(): String {
        val st = if (statusSekarang in 0..8) Daftar.STATUS[statusSekarang] else "-"
        val a = prevAkun
        var masuk = "-"
        var quick = "-"
        if (a != null) {
            masuk = a[iMasuk].toString()
            val nama = listOf(
                "m_bOpenQuickMatch", "bOpenQuickMatch_Part3", "m_iQuickMatchMaxRankIdInRank",
                "bQuickMatchUseNewBattleSettle", "m_isSelectQuickMatch"
            )
            quick = nama.joinToString("/") { a[Daftar.indeks(Daftar.AKUN, it)].toString() }
        }
        return "status=$st masukBattle=$masuk quick=$quick"
    }

    private fun tidur(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            stopMinta = true
        }
    }

    private fun resetBaca() {
        prevAkun = null
        prevMatch = null
        prevHero = null
        lbmPtr = 0L
        heroPtr = 0L
        lbmCekMs = 0L
        posX = Float.NaN
        posY = Float.NaN
        statusSekarang = -1
        lagW0 = 0L
        lagBuruk = 0
        gagalBeruntun = 0
    }

    private fun loop() {
        var sh: GameShell? = null
        var sas: Sasaran? = null
        try {
            while (!stopMinta) {
                if (!ShizukuHelper.hasPermission()) {
                    statusShizuku = if (ShizukuHelper.isRunning()) "Belum diizinkan" else "Shizuku tidak aktif"
                    statusMulti = "-"
                    statusGame = "-"
                    pesan = "Aktifkan Shizuku dan izinkan aplikasi ini"
                    sh?.tutup()
                    sh = null
                    sas = null
                    tidur(1000)
                    continue
                }
                statusShizuku = "Tersambung"

                if (sh == null || !sh.hidup) {
                    sh?.tutup()
                    sas = null
                    statusMulti = "Mencoba..."
                    val baru = GameShell(paket)
                    if (!baru.buka()) {
                        baru.tutup()
                        statusMulti = "Tidak bisa dibaca"
                        statusGame = "-"
                        pesan = if (!Regex("[A-Za-z0-9_.]+").matches(paket)) {
                            "Nama paket tidak valid (hanya huruf, angka, titik, garis bawah)"
                        } else {
                            "Multi Run ($paket) tidak bisa dibuka lewat run-as. Pastikan terpasang dan debuggable."
                        }
                        sh = null
                        tidur(2000)
                        continue
                    }
                    sh = baru
                    statusMulti = "Bisa dibaca"
                    pesan = ""
                }
                val shell = sh ?: continue

                if (sas == null) {
                    statusGame = "Mencari..."
                    val s = Pencari.cari(paket, shell) { pesan = it }
                    if (s == null) {
                        statusGame = "Belum ditemukan"
                        tidur(2000)
                        continue
                    }
                    sas = s
                    statusGame = "PID " + s.pid
                    pesan = ""
                    resetBaca()
                    catat("OTOMATIS", "Game ditemukan", null, "PID " + s.pid, null)
                    baris("# " + s.ringkas + " mode=" + shell.namaMode)
                }
                val sasaran = sas ?: continue

                val mulaiTick = SystemClock.elapsedRealtime()
                val ok = try {
                    tick(shell, sasaran)
                } catch (e: Throwable) {
                    baris("# ERROR tick: $e")
                    false
                }
                val sela = SystemClock.elapsedRealtime() - mulaiTick
                rataMs = if (rataMs == 0.0) sela.toDouble() else rataMs * 0.9 + sela * 0.1
                hitungTick++
                val kini = SystemClock.elapsedRealtime()
                if (jendelaMs == 0L) jendelaMs = kini
                if (kini - jendelaMs >= 2000) {
                    hzNyata = hitungTick * 1000.0 / (kini - jendelaMs)
                    hitungTick = 0
                    jendelaMs = kini
                    simpanBerkas()
                }
                if (ok) {
                    gagalBeruntun = 0
                } else {
                    gagalBeruntun++
                    if (gagalBeruntun >= 5) {
                        sas = null
                        statusGame = "Hilang, mencari lagi"
                        gagalBeruntun = 0
                        catat("OTOMATIS", "Game hilang", null, null, "pembacaan gagal 5 kali berturut-turut")
                    }
                }
                val periode = 1000L / maxOf(1, hz)
                val sisa = periode - (SystemClock.elapsedRealtime() - mulaiTick)
                if (sisa > 0) tidur(sisa)
            }
        } catch (e: Throwable) {
            pesan = "Error: " + (e.message ?: e.javaClass.simpleName)
            baris("# ERROR $e")
        } finally {
            try {
                sh?.tutup()
            } catch (e: Throwable) {
            }
            synchronized(kunci) {
                try {
                    tulis?.flush()
                    tulis?.close()
                } catch (e: Throwable) {
                }
                tulis = null
            }
            statusGame = "-"
            statusMulti = "-"
            berjalan = false
        }
    }

    private fun tick(sh: GameShell, s: Sasaran): Boolean {
        var ok = false

        if (areaAkun) {
            val b = sh.baca(s.pid, s.sdStatis, Daftar.PANJANG_AKUN)
            if (b != null) {
                ok = true
                prevAkun = bandingkan(Daftar.AKUN, b, prevAkun, true)
            }
        }

        val sekarang = SystemClock.elapsedRealtime()
        if (areaMatch || areaHero || deteksiLag) {
            if (lbmPtr == 0L || sekarang - lbmCekMs >= 1000) {
                lbmCekMs = sekarang
                val p = sh.bacaLong(s.pid, s.lbmGlobal)
                if (p != null) {
                    ok = true
                    if (p != lbmPtr) {
                        if (lbmPtr != 0L || p != 0L) {
                            catat("OTOMATIS", "LBM berganti", hex(lbmPtr), hex(p), "match baru atau match selesai")
                        }
                        lbmPtr = p
                        prevMatch = null
                        heroPtr = 0L
                        prevHero = null
                        posX = Float.NaN
                        posY = Float.NaN
                        statusSekarang = -1
                        lagW0 = 0L
                    }
                }
            }
            if (lbmPtr != 0L) {
                val m = sh.baca(s.pid, lbmPtr, Daftar.PANJANG_MATCH)
                if (m != null) {
                    ok = true
                    olahMatch(m, sekarang)
                }
            }
        }

        if (areaHero && heroPtr != 0L) {
            val h = sh.baca(s.pid, heroPtr, Daftar.PANJANG_HERO)
            if (h != null) {
                ok = true
                olahHero(h)
            }
        }
        return ok
    }

    // Bandingkan nilai terbaru dengan sebelumnya, catat yang berubah.
    // Bacaan pertama dicatat sebagai "nilai awal".
    private fun bandingkan(d: List<Bidang>, b: ByteArray, prev: LongArray?, catatKeLog: Boolean): LongArray {
        val baru = LongArray(d.size)
        for (i in d.indices) baru[i] = Daftar.nilai(b, d[i])
        if (catatKeLog) {
            for (i in d.indices) {
                val f = d[i]
                if (f.nama == "m_uiFrameTime") continue
                if (prev == null) {
                    catat(f.area, f.nama, null, Daftar.fmt(f, baru[i]), "nilai awal")
                } else if (prev[i] != baru[i]) {
                    catat(f.area, f.nama, Daftar.fmt(f, prev[i]), Daftar.fmt(f, baru[i]), null)
                }
            }
        }
        return baru
    }

    private fun olahMatch(m: ByteArray, sekarang: Long) {
        val pm = bandingkan(Daftar.MATCH, m, prevMatch, areaMatch)
        prevMatch = pm
        statusSekarang = pm[iState].toInt()
        heroPtr = pm[iSelf]

        if (deteksiLag && statusSekarang == 6) {
            val g = pm[iFrame] and 0xFFFFFFFFL
            if (lagW0 == 0L) {
                lagW0 = sekarang
                lagG0 = g
            } else if (sekarang - lagW0 >= 2000) {
                val dw = sekarang - lagW0
                val dg = g - lagG0
                if (dg >= 0 && dg <= dw * 10) {
                    val rasio = dg.toDouble() / dw.toDouble()
                    if (rasio < 0.7) lagBuruk++ else lagBuruk = 0
                    if (lagBuruk >= 2 && sekarang - lagTerakhir >= 5000) {
                        lagTerakhir = sekarang
                        catat("OTOMATIS", "LAG", null, null, String.format(Locale.US, "waktu game %.2fx jam asli", rasio))
                    }
                } else {
                    lagBuruk = 0
                }
                lagW0 = sekarang
                lagG0 = g
            }
        } else {
            lagW0 = 0L
            lagBuruk = 0
        }
    }

    private fun fmtPos(x: Float, y: Float): String = String.format(Locale.US, "(%.2f, %.2f)", x, y)

    private fun olahHero(h: ByteArray) {
        prevHero = bandingkan(Daftar.HERO, h, prevHero, true)
        val x = Daftar.pecahan(h, Daftar.POS_X)
        val y = Daftar.pecahan(h, Daftar.POS_Y)
        if (!x.isNaN() && !y.isNaN() && !x.isInfinite() && !y.isInfinite()) {
            if (!posX.isNaN() && !posY.isNaN()) {
                if (Math.abs(x - posX) + Math.abs(y - posY) > 0.8f) {
                    catat("HERO", "posisi", fmtPos(posX, posY), fmtPos(x, y), "lompatan")
                }
            }
            posX = x
            posY = y
        }
    }
}
