package com.pencatat.memori

import android.content.Context
import android.os.SystemClock
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Rencana baca satu objek: field yang dipantau + rentang byte yang dibaca (mulai dari offset [awal])
class Rencana(val bidang: List<Bidang>, val awal: Int, val panjang: Int)

// Mesin perekam. Dua mode:
//  mode 0 (pantau): membaca field yang dikenal (atau hanya yang dipilih dari hasil Mode cari),
//                   mencatat HANYA yang berubah.
//  mode 1 (cari)  : membaca objek penuh tiap detik dan mengumpulkan statistik perubahan (Penelusur).
object Perekam {

    class Kejadian(
        val waktu: Long,
        val tipe: String,
        val judul: String,
        val lama: String?,
        val baru: String?,
        val ket: String?
    )

    // ---- pengaturan (Beranda) ----
    @Volatile var paket = "com.dong.multirun"
    @Volatile var hz = 5
    @Volatile var deteksiLag = true
    @Volatile var areaAkun = true
    @Volatile var areaMatch = true
    @Volatile var areaHero = true
    @Volatile var areaTower = true

    // ---- cakupan Mode cari ----
    @Volatile var cariAkun = true
    @Volatile var cariMatch = true
    @Volatile var cariHero = true
    @Volatile var cariTower = true

    // ---- mode kerja ----
    @Volatile var mode = 0
    @Volatile var terpilih: List<Hasil>? = null

    // ---- status untuk tampilan ----
    @Volatile var berjalan = false
    @Volatile var statusShizuku = "Belum dicek"
    @Volatile var statusMulti = "-"
    @Volatile var statusGame = "-"
    @Volatile var pesan = ""
    @Volatile var jumlah = 0
    @Volatile var versi = 0
    @Volatile var hzNyata = 0.0
    @Volatile var rataMs = 0.0
    @Volatile var mulaiMs = 0L
    @Volatile var cariSampel = 0
    @Volatile var cariBerubah = 0
    @Volatile var berkas: File? = null
    @Volatile var berkasHasil: File? = null

    private val kunci = Any()
    private val daftar = ArrayList<Kejadian>()
    private var tulis: BufferedWriter? = null
    private var appCtx: Context? = null

    @Volatile
    private var stopMinta = false
    private var thread: Thread? = null

    // ---- rencana baca ----
    private var rAkun: Rencana? = null
    private var rMatch: Rencana? = null
    private var rHero: Rencana? = null
    private var rTowerE: Rencana? = null
    private var rTowerA: Rencana? = null
    private var catatMatch = true

    // ---- keadaan pembacaan ----
    private var prevAkun: LongArray? = null
    private var prevMatch: LongArray? = null
    private var prevHero: LongArray? = null
    private val prevTowerE = HashMap<Long, LongArray>()
    private val prevTowerA = HashMap<Long, LongArray>()
    private val terakhir = HashMap<String, Long>()
    private var menaraList: List<Menara> = emptyList()
    private val menaraDilapor = HashSet<Long>()
    private var menaraCekMs = 0L
    private var menaraBacaMs = 0L
    private var lbmPtr = 0L
    private var heroPtr = 0L
    private var lbmCekMs = 0L
    private var campSaya = 0
    private var campTahu = false
    private var posX = Float.NaN
    private var posY = Float.NaN
    private var statusSekarang = -1
    private var lagW0 = 0L
    private var lagG0 = 0L
    private var lagBuruk = 0
    private var lagTerakhir = 0L
    private var gagalBeruntun = 0
    private var hitungTick = 0
    private var jendelaMs = 0L
    private var cariMulaiMs = 0L

    fun mulai(ctx: Context) {
        synchronized(kunci) {
            if (berjalan) return
            berjalan = true
            daftar.clear()
            jumlah = 0
            versi++
        }
        stopMinta = false
        mulaiMs = SystemClock.elapsedRealtime()
        pesan = ""
        appCtx = ctx.applicationContext
        cariSampel = 0
        cariBerubah = 0
        if (mode == 1) {
            Penelusur.reset()
        } else {
            siapkanRencana()
        }
        siapkanBerkas(ctx.applicationContext)
        val t = Thread { loop() }
        t.isDaemon = true
        t.name = "perekam"
        thread = t
        t.start()
    }

    fun berhenti() {
        stopMinta = true
    }

    fun durasi(): String {
        if (mulaiMs == 0L) return "00:00"
        val d = (SystemClock.elapsedRealtime() - mulaiMs) / 1000
        return String.format(Locale.US, "%02d:%02d", d / 60, d % 60)
    }

    fun ukuranBerkas(): Long = berkas?.length() ?: 0L

    fun flush() {
        simpanBerkas()
    }

    // Tanda dari pengguna (tombol notifikasi atau layar)
    fun tanda(label: String) {
        catat("TANDA", label, null, null, ringkasKondisi())
    }

    fun salinan(filter: String, maks: Int): List<Kejadian> {
        val hasil = ArrayList<Kejadian>()
        synchronized(kunci) {
            var i = daftar.size - 1
            while (i >= 0 && hasil.size < maks) {
                val k = daftar[i]
                val cocok = when (filter) {
                    "Akun" -> k.tipe == "AKUN"
                    "Pertandingan" -> k.tipe == "PERTANDINGAN" || k.tipe == "HERO" || k.tipe == "TOWER"
                    "Tanda" -> k.tipe == "TANDA" || k.tipe == "OTOMATIS"
                    else -> true
                }
                if (cocok) hasil.add(k)
                i--
            }
        }
        return hasil
    }

    fun formatBaris(k: Kejadian): String {
        val w = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(k.waktu))
        val sb = StringBuilder()
        sb.append(w).append(' ').append(k.tipe).append(' ').append(k.judul)
        if (k.lama != null || k.baru != null) {
            sb.append("  ").append(k.lama ?: "-").append(" -> ").append(k.baru ?: "-")
        }
        if (k.ket != null) sb.append("  (").append(k.ket).append(')')
        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Rencana baca

    private fun rencanaDari(area: String, kode: String, pilih: List<Hasil>, kenal: List<Bidang>): Rencana? {
        val bidang = ArrayList<Bidang>()
        var min = Int.MAX_VALUE
        var maks = 0
        for (h in pilih) {
            if (h.area != area || h.kodeOff != kode) continue
            val k = Daftar.kenal(kenal, h.offset)
            val persis = k != null && k.off == h.offset
            val nama = if (persis && k != null) k.nama else "+" + h.offset
            val jenis = if (persis && k != null) k.jenis else 0
            bidang.add(Bidang(area, nama, h.offset, Tipe.I4, jenis))
            if (h.offset < min) min = h.offset
            if (h.offset + 4 > maks) maks = h.offset + 4
        }
        if (bidang.isEmpty()) return null
        val awal = (min / 4) * 4
        return Rencana(bidang, awal, maks - awal)
    }

    // Rencana pertandingan harus selalu memuat status, pointer hero, dan waktu game
    // (dibutuhkan deteksi lag, pembacaan hero, dan pencarian tower).
    private fun gabungWajib(rm: Rencana?): Rencana {
        val wajib = listOf("_m_eState", "m_RealSelfPlayer", "m_uiFrameTime")
        val bidang = ArrayList<Bidang>()
        if (rm != null) {
            for (f in rm.bidang) {
                if (!wajib.contains(f.nama)) bidang.add(f)
            }
        }
        // Selalu pakai definisi asli (pointer hero 8 byte, bukan 4 byte)
        for (nama in wajib) bidang.add(Daftar.MATCH[Daftar.indeks(Daftar.MATCH, nama)])
        var min = Int.MAX_VALUE
        var maks = 0
        for (f in bidang) {
            if (f.off < min) min = f.off
            if (f.off + f.tipe.n > maks) maks = f.off + f.tipe.n
        }
        val awal = (min / 4) * 4
        return Rencana(bidang, awal, maks - awal)
    }

    private fun siapkanRencana() {
        val t = terpilih
        if (t == null) {
            rAkun = if (areaAkun) Rencana(Daftar.AKUN, 0, Daftar.PANJANG_AKUN) else null
            rMatch = if (areaMatch || areaHero || areaTower || deteksiLag) {
                Rencana(Daftar.MATCH, 0, Daftar.PANJANG_MATCH)
            } else {
                null
            }
            catatMatch = areaMatch
            rHero = if (areaHero) Rencana(Daftar.HERO, 0, Daftar.PANJANG_HERO) else null
            rTowerE = if (areaTower) Rencana(Daftar.TOWER_E, 0, Daftar.PANJANG_TOWER_E) else null
            rTowerA = if (areaTower) Rencana(Daftar.TOWER_A, 0, Daftar.PANJANG_TOWER_A) else null
        } else {
            rAkun = rencanaDari("AKUN", "", t, Daftar.AKUN)
            val rm = rencanaDari("PERTANDINGAN", "", t, Daftar.MATCH)
            catatMatch = rm != null
            rMatch = gabungWajib(rm)
            rHero = rencanaDari("HERO", "", t, Daftar.HERO)
            rTowerE = rencanaDari("TOWER", "E", t, Daftar.TOWER_E)
            rTowerA = rencanaDari("TOWER", "A", t, Daftar.TOWER_A)
        }
    }

    // ------------------------------------------------------------------
    // Berkas dan catatan

    private fun siapkanBerkas(ctx: Context) {
        try {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            val sp = ctx.getSharedPreferences("pencatat", Context.MODE_PRIVATE)
            val no = sp.getInt("sesi_no", 0) + 1
            sp.edit().putInt("sesi_no", no).apply()
            val f = File(dir, "Sesi_$no.txt")
            berkas = f
            tulis = BufferedWriter(OutputStreamWriter(FileOutputStream(f, true), Charsets.UTF_8))
            val tgl = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            baris("# Pencatat Memori, sesi $no, $tgl, mode=" + (if (mode == 1) "cari" else "pantau"))
            if (mode == 1) {
                baris("# paket=$paket cakupan: akun=$cariAkun match=$cariMatch hero=$cariHero tower=$cariTower")
            } else {
                val ket = if (terpilih != null) " (hanya yang dipilih dari hasil cari)" else ""
                baris("# paket=$paket hz=$hz deteksiLag=$deteksiLag area: akun=$areaAkun match=$areaMatch hero=$areaHero tower=$areaTower$ket")
            }
        } catch (e: Throwable) {
            tulis = null
        }
    }

    private fun baris(s: String) {
        synchronized(kunci) {
            try {
                tulis?.write(s)
                tulis?.newLine()
            } catch (e: Throwable) {
            }
        }
    }

    private fun simpanBerkas() {
        synchronized(kunci) {
            try {
                tulis?.flush()
            } catch (e: Throwable) {
            }
        }
    }

    private fun catat(tipe: String, judul: String, lama: String?, baru: String?, ket: String?) {
        val k = Kejadian(System.currentTimeMillis(), tipe, judul, lama, baru, ket)
        synchronized(kunci) {
            daftar.add(k)
            if (daftar.size > 800) daftar.removeAt(0)
            jumlah++
            versi++
            try {
                tulis?.write(formatBaris(k))
                tulis?.newLine()
            } catch (e: Throwable) {
            }
        }
    }

    private fun hex(v: Long): String = "0x" + java.lang.Long.toHexString(v)

    private fun ringkasKondisi(): String {
        val st = if (statusSekarang in 0..8) Daftar.STATUS[statusSekarang] else "-"
        val masuk = terakhir["m_bEnterBattle"]?.toString() ?: "-"
        val nama = listOf(
            "m_bOpenQuickMatch", "bOpenQuickMatch_Part3", "m_iQuickMatchMaxRankIdInRank",
            "bQuickMatchUseNewBattleSettle", "m_isSelectQuickMatch"
        )
        val quick = nama.joinToString("/") { terakhir[it]?.toString() ?: "-" }
        return "status=$st masukBattle=$masuk quick=$quick"
    }

    private fun tidur(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            stopMinta = true
        }
    }

    private fun resetBaca() {
        prevAkun = null
        prevMatch = null
        prevHero = null
        prevTowerE.clear()
        prevTowerA.clear()
        menaraList = emptyList()
        menaraDilapor.clear()
        PencariMenara.reset()
        menaraCekMs = 0L
        menaraBacaMs = 0L
        lbmPtr = 0L
        heroPtr = 0L
        lbmCekMs = 0L
        campTahu = false
        posX = Float.NaN
        posY = Float.NaN
        statusSekarang = -1
        lagW0 = 0L
        lagBuruk = 0
        gagalBeruntun = 0
    }

    // ------------------------------------------------------------------
    // Putaran utama

    private fun loop() {
        var sh: GameShell? = null
        var sas: Sasaran? = null
        try {
            while (!stopMinta) {
                if (!ShizukuHelper.hasPermission()) {
                    statusShizuku = if (ShizukuHelper.isRunning()) "Belum diizinkan" else "Shizuku tidak aktif"
                    statusMulti = "-"
                    statusGame = "-"
                    pesan = "Aktifkan Shizuku dan izinkan aplikasi ini"
                    sh?.tutup()
                    sh = null
                    sas = null
                    tidur(1000)
                    continue
                }
                statusShizuku = "Tersambung"

                if (sh == null || !sh.hidup) {
                    sh?.tutup()
                    sas = null
                    statusMulti = "Mencoba..."
                    val baru = GameShell(paket)
                    if (!baru.buka()) {
                        baru.tutup()
                        statusMulti = "Tidak bisa dibaca"
                        statusGame = "-"
                        pesan = if (!Regex("[A-Za-z0-9_.]+").matches(paket)) {
                            "Nama paket tidak valid (hanya huruf, angka, titik, garis bawah)"
                        } else {
                            "Multi Run ($paket) tidak bisa dibuka lewat run-as. Pastikan terpasang dan debuggable."
                        }
                        sh = null
                        tidur(2000)
                        continue
                    }
                    sh = baru
                    statusMulti = "Bisa dibaca"
                    pesan = ""
                }
                val shell = sh ?: continue

                if (sas == null) {
                    statusGame = "Mencari..."
                    val s = Pencari.cari(paket, shell) { pesan = it }
                    if (s == null) {
                        statusGame = "Belum ditemukan"
                        tidur(2000)
                        continue
                    }
                    sas = s
                    statusGame = "PID " + s.pid
                    pesan = ""
                    resetBaca()
                    if (cariMulaiMs == 0L) cariMulaiMs = SystemClock.elapsedRealtime()
                    catat("OTOMATIS", "Game ditemukan", null, "PID " + s.pid, null)
                    baris("# " + s.ringkas + " mode=" + shell.namaMode)
                }
                val sasaran = sas ?: continue

                val mulaiTick = SystemClock.elapsedRealtime()
                val ok = try {
                    if (mode == 1) tickCari(shell, sasaran) else tick(shell, sasaran)
                } catch (e: Throwable) {
                    baris("# ERROR tick: $e")
                    false
                }
                val sela = SystemClock.elapsedRealtime() - mulaiTick
                rataMs = if (rataMs == 0.0) sela.toDouble() else rataMs * 0.9 + sela * 0.1
                hitungTick++
                val kini = SystemClock.elapsedRealtime()
                if (jendelaMs == 0L) jendelaMs = kini
                if (kini - jendelaMs >= 2000) {
                    hzNyata = hitungTick * 1000.0 / (kini - jendelaMs)
                    hitungTick = 0
                    jendelaMs = kini
                    simpanBerkas()
                }
                if (ok) {
                    gagalBeruntun = 0
                } else {
                    gagalBeruntun++
                    if (gagalBeruntun >= 5) {
                        sas = null
                        statusGame = "Hilang, mencari lagi"
                        gagalBeruntun = 0
                        catat("OTOMATIS", "Game hilang", null, null, "pembacaan gagal 5 kali berturut-turut")
                    }
                }
                val target = if (mode == 1) 1 else maxOf(1, hz)
                val periode = 1000L / target
                val sisa = periode - (SystemClock.elapsedRealtime() - mulaiTick)
                if (sisa > 0) tidur(sisa)
            }
        } catch (e: Throwable) {
            pesan = "Error: " + (e.message ?: e.javaClass.simpleName)
            baris("# ERROR $e")
        } finally {
            try {
                sh?.tutup()
            } catch (e: Throwable) {
            }
            if (mode == 1) selesaikanCari()
            synchronized(kunci) {
                try {
                    tulis?.flush()
                    tulis?.close()
                } catch (e: Throwable) {
                }
                tulis = null
            }
            statusGame = "-"
            statusMulti = "-"
            cariMulaiMs = 0L
            berjalan = false
        }
    }

    private fun selesaikanCari() {
        try {
            Penelusur.selesai(SystemClock.elapsedRealtime() - (if (cariMulaiMs == 0L) mulaiMs else cariMulaiMs))
            val ctx = appCtx
            if (ctx != null) {
                val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                val f = File(dir, "Hasil_cari_" + (berkas?.name?.removePrefix("Sesi_") ?: "0.txt"))
                f.writeText(Penelusur.laporan())
                berkasHasil = f
            }
        } catch (e: Throwable) {
            baris("# ERROR hasil cari: $e")
            Penelusur.selesai(0L)
        }
    }

    // ------------------------------------------------------------------
    // Mode pantau

    private fun tick(sh: GameShell, s: Sasaran): Boolean {
        var ok = false

        val ra = rAkun
        if (ra != null) {
            val b = sh.baca(s.pid, s.sdStatis + ra.awal, ra.panjang)
            if (b != null) {
                ok = true
                prevAkun = bandingkan(ra, b, prevAkun, "", null, true)
            }
        }

        val sekarang = SystemClock.elapsedRealtime()
        val rm = rMatch
        if (rm != null) {
            if (segarkanLbm(sh, s, sekarang)) ok = true
            if (lbmPtr != 0L) {
                val m = sh.baca(s.pid, lbmPtr + rm.awal, rm.panjang)
                if (m != null) {
                    ok = true
                    olahMatch(rm, m, sekarang)
                }
            }
        }

        val rh = rHero
        if (rh != null && heroPtr != 0L) {
            val h = sh.baca(s.pid, heroPtr + rh.awal, rh.panjang)
            if (h != null) {
                ok = true
                olahHero(rh, h)
            }
        }

        if ((rTowerE != null || rTowerA != null) && lbmPtr != 0L && heroPtr != 0L) {
            if (tickMenara(sh, s, sekarang)) ok = true
        }
        return ok
    }

    // Cek pointer LBM tiap 1 detik. Mengembalikan true kalau bacaan berhasil.
    private fun segarkanLbm(sh: GameShell, s: Sasaran, sekarang: Long): Boolean {
        if (lbmPtr != 0L && sekarang - lbmCekMs < 1000) return false
        lbmCekMs = sekarang
        val p = sh.bacaLong(s.pid, s.lbmGlobal) ?: return false
        if (p != lbmPtr) {
            if (lbmPtr != 0L || p != 0L) {
                catat("OTOMATIS", "LBM berganti", hex(lbmPtr), hex(p), "match baru atau match selesai")
            }
            lbmPtr = p
            prevMatch = null
            heroPtr = 0L
            prevHero = null
            prevTowerE.clear()
            prevTowerA.clear()
            menaraList = emptyList()
            menaraDilapor.clear()
            PencariMenara.reset()
            campTahu = false
            posX = Float.NaN
            posY = Float.NaN
            statusSekarang = -1
            lagW0 = 0L
            if (mode == 1) Penelusur.buangObjek()
        }
        return true
    }

    // Bandingkan nilai terbaru dengan sebelumnya, catat yang berubah.
    // Bacaan pertama dicatat sebagai "nilai awal".
    private fun bandingkan(
        r: Rencana,
        b: ByteArray,
        prev: LongArray?,
        awalan: String,
        ketAwal: String?,
        catatKeLog: Boolean
    ): LongArray {
        val d = r.bidang
        val baru = LongArray(d.size)
        for (i in d.indices) baru[i] = Daftar.nilai(b, d[i], r.awal)
        for (i in d.indices) {
            val f = d[i]
            if (f.area == "AKUN") terakhir[f.nama] = baru[i]
            if (!catatKeLog || f.nama == "m_uiFrameTime") continue
            if (prev == null) {
                catat(f.area, awalan + f.nama, null, Daftar.fmt(f, baru[i]), ketAwal ?: "nilai awal")
            } else if (prev[i] != baru[i]) {
                catat(f.area, awalan + f.nama, Daftar.fmt(f, prev[i]), Daftar.fmt(f, baru[i]), null)
            }
        }
        return baru
    }

    private fun olahMatch(rm: Rencana, m: ByteArray, sekarang: Long) {
        val pm = bandingkan(rm, m, prevMatch, "", null, catatMatch)
        prevMatch = pm
        val iState = Daftar.indeks(rm.bidang, "_m_eState")
        val iSelf = Daftar.indeks(rm.bidang, "m_RealSelfPlayer")
        val iFrame = Daftar.indeks(rm.bidang, "m_uiFrameTime")
        if (iState >= 0) statusSekarang = pm[iState].toInt()
        if (iSelf >= 0) heroPtr = pm[iSelf]

        if (deteksiLag && iFrame >= 0 && statusSekarang == 6) {
            val g = pm[iFrame] and 0xFFFFFFFFL
            if (lagW0 == 0L) {
                lagW0 = sekarang
                lagG0 = g
            } else if (sekarang - lagW0 >= 2000) {
                val dw = sekarang - lagW0
                val dg = g - lagG0
                if (dg >= 0 && dg <= dw * 10) {
                    val rasio = dg.toDouble() / dw.toDouble()
                    if (rasio < 0.7) lagBuruk++ else lagBuruk = 0
                    if (lagBuruk >= 2 && sekarang - lagTerakhir >= 5000) {
                        lagTerakhir = sekarang
                        catat("OTOMATIS", "LAG", null, null, String.format(Locale.US, "waktu game %.2fx jam asli", rasio))
                    }
                } else {
                    lagBuruk = 0
                }
                lagW0 = sekarang
                lagG0 = g
            }
        } else {
            lagW0 = 0L
            lagBuruk = 0
        }
    }

    private fun fmtPos(x: Float, y: Float): String = String.format(Locale.US, "(%.2f, %.2f)", x, y)

    private fun olahHero(rh: Rencana, h: ByteArray) {
        prevHero = bandingkan(rh, h, prevHero, "", null, true)
        if (rh.awal > Daftar.POS_X || rh.awal + rh.panjang < Daftar.POS_Y + 4) return
        val x = Daftar.pecahan(h, Daftar.POS_X - rh.awal)
        val y = Daftar.pecahan(h, Daftar.POS_Y - rh.awal)
        if (!x.isNaN() && !y.isNaN() && !x.isInfinite() && !y.isInfinite()) {
            if (!posX.isNaN() && !posY.isNaN()) {
                if (Math.abs(x - posX) + Math.abs(y - posY) > 0.8f) {
                    catat("HERO", "posisi", fmtPos(posX, posY), fmtPos(x, y), "lompatan")
                }
            }
            posX = x
            posY = y
        }
    }

    // Tower musuh: cari lewat kamus monster tiap 3 detik, baca tiap tower paling cepat tiap 0,5 detik
    private fun tickMenara(sh: GameShell, s: Sasaran, sekarang: Long): Boolean {
        var ok = false
        if (menaraList.isEmpty() || sekarang - menaraCekMs >= 3000) {
            menaraCekMs = sekarang
            if (!campTahu) {
                val c = sh.baca(s.pid, heroPtr + Daftar.OFF_CAMP.toLong(), 4)
                if (c != null) {
                    campSaya = Daftar.le32(c, 0)
                    campTahu = true
                }
            }
            if (campTahu) {
                val l = PencariMenara.segarkan(sh, s.pid, lbmPtr, campSaya)
                if (l != null) {
                    ok = true
                    menaraList = l
                    for (m in l) {
                        if (menaraDilapor.add(m.alamat)) {
                            catat("TOWER", m.label + " ditemukan", null, fmtPos(m.x, m.y), null)
                        }
                    }
                }
            }
        }
        val selang = maxOf(500L, 1000L / maxOf(1, hz))
        if (sekarang - menaraBacaMs < selang) return ok
        menaraBacaMs = sekarang

        val re = rTowerE
        val ra = rTowerA
        for (m in menaraList) {
            if (!m.hidup) continue
            if (re != null) {
                val e = sh.baca(s.pid, m.alamat + re.awal, re.panjang)
                if (e != null) {
                    ok = true
                    prevTowerE[m.alamat] = bandingkan(re, e, prevTowerE[m.alamat], m.label + " ", null, true)
                    val iDel = Daftar.indeks(re.bidang, "m_bDelet")
                    val pe = prevTowerE[m.alamat]
                    if (iDel >= 0 && pe != null && pe[iDel] == 1L) m.hidup = false
                }
            }
            if (ra != null) {
                if (m.attr == 0L || sekarang - m.cekAttrMs > 10000) {
                    m.attr = PencariMenara.alamatAttr(sh, s.pid, m.alamat)
                    m.cekAttrMs = sekarang
                }
                if (m.attr != 0L) {
                    val a = sh.baca(s.pid, m.attr + ra.awal, ra.panjang)
                    if (a != null) {
                        ok = true
                        prevTowerA[m.alamat] = bandingkan(ra, a, prevTowerA[m.alamat], m.label + " ", null, true)
                    }
                }
            }
        }
        return ok
    }

    // ------------------------------------------------------------------
    // Mode cari: baca objek penuh tiap detik, kumpulkan statistik

    private fun tickCari(sh: GameShell, s: Sasaran): Boolean {
        val sekarang = SystemClock.elapsedRealtime()
        val t = sekarang - (if (cariMulaiMs == 0L) mulaiMs else cariMulaiMs)
        var ok = false

        if (cariAkun) {
            val b = sh.baca(s.pid, s.sdStatis, Daftar.CARI_AKUN)
            if (b != null) {
                ok = true
                Penelusur.serap("AKUN", "", 0L, null, b, t)
            }
        }

        if (cariMatch || cariHero || cariTower) {
            if (segarkanLbm(sh, s, sekarang)) ok = true
            if (lbmPtr != 0L) {
                val m = sh.baca(s.pid, lbmPtr, Daftar.CARI_MATCH)
                if (m != null) {
                    ok = true
                    if (cariMatch) Penelusur.serap("PERTANDINGAN", "", lbmPtr, null, m, t)
                    heroPtr = Daftar.le(m, 416, 8)
                }
            }
            if (heroPtr != 0L && (cariHero || cariTower)) {
                val h = sh.baca(s.pid, heroPtr, Daftar.CARI_HERO)
                if (h != null) {
                    ok = true
                    if (cariHero) Penelusur.serap("HERO", "", heroPtr, null, h, t)
                    campSaya = Daftar.le32(h, Daftar.OFF_CAMP)
                    campTahu = true
                }
            }
            if (cariTower && campTahu && lbmPtr != 0L) {
                if (menaraList.isEmpty() || sekarang - menaraCekMs >= 3000) {
                    menaraCekMs = sekarang
                    val l = PencariMenara.segarkan(sh, s.pid, lbmPtr, campSaya)
                    if (l != null) {
                        ok = true
                        menaraList = l
                        for (m in l) {
                            if (menaraDilapor.add(m.alamat)) {
                                catat("TOWER", m.label + " ditemukan", null, fmtPos(m.x, m.y), null)
                            }
                        }
                    }
                }
                for (m in menaraList) {
                    if (!m.hidup) continue
                    val e = sh.baca(s.pid, m.alamat, Daftar.CARI_TOWER_E)
                    if (e != null) {
                        ok = true
                        Penelusur.serap("TOWER", "E", m.alamat, m.label, e, t)
                        if (e[Daftar.OFF_DELET].toInt() == 1) m.hidup = false
                    }
                    if (m.attr == 0L || sekarang - m.cekAttrMs > 10000) {
                        m.attr = PencariMenara.alamatAttr(sh, s.pid, m.alamat)
                        m.cekAttrMs = sekarang
                    }
                    if (m.attr != 0L) {
                        val a = sh.baca(s.pid, m.attr, Daftar.CARI_TOWER_A)
                        if (a != null) {
                            ok = true
                            Penelusur.serap("TOWER", "A", m.alamat, m.label, a, t)
                        }
                    }
                }
            }
        }
        if (ok) {
            Penelusur.sampel++
            cariSampel = Penelusur.sampel
            cariBerubah = Penelusur.berubah
        }
        return ok
    }
}
