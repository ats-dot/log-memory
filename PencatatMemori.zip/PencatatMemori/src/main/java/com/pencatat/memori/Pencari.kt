package com.pencatat.memori

import android.content.Context
import java.io.File

class Sasaran(
    val pid: Int,
    val libBase: Long,
    val sdStatis: Long,
    val lbmGlobal: Long,
    val ringkas: String,
    // Alamat penampung pointer LogicBattleScene (instance = isi alamat ini). 0 = kelas tidak ditemukan.
    val sceneGlobal: Long = 0L
)

// Mencari kelas Il2cpp di memori game secara otomatis.
//
// Pakai native ARM64 scanner binary (memscan) yang dijalankan via Shizuku.
// Scanner langsung baca /proc/pid/mem tanpa overhead shell dd+base64.
// Semua langkah reverse search (string → pointer → bss) dilakukan dalam
// satu proses native — jauh lebih cepat dari pendekatan shell.
//
// Fallback ke shell-based scan kalau binary gagal.
object Pencari {

    // Offset slot TypeInfo (alamat slot - basis libcsharp.so). Yang pertama = versi game sekarang (sama di semua log scan native);
    // yang lama tetap dicoba. Setiap hint diverifikasi lewat nama kelas, jadi hint salah tidak berbahaya.
    private val HINT_SD = longArrayOf(0x4FBE650L, 0x6497880L)
    private val HINT_LBM = longArrayOf(0x5501DF8L, 0x6497780L)
    private val HINT_SCENE = longArrayOf(0x57128E0L, 0x64920D8L)

    // Hint yang dipelajari dari scan terakhir (sesudah game update, offset baru ikut ditemukan scan lalu tersimpan) dicoba lebih dulu
    private fun hintUntuk(nama: String, dasar: LongArray): LongArray {
        val l = Prefs.hintBelajar(nama)
        return if (l != 0L) (listOf(l) + dasar.toList()).distinct().toLongArray() else dasar
    }

    // Dimatikan sesudah hint kehabisan waktu berulang kali (game versi lain): kembali ke scan penuh seperti dulu
    @Volatile private var hintAktif = true
    @Volatile private var hintHabisWaktu = 0

    private var scannerSiap = false
    private var scannerPath = ""  // path di sandbox game
    val pathScanner: String get() = scannerPath

    fun uidPaket(paket: String): Int? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return null
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "pm list packages -U $paket"))
        } catch (e: Throwable) {
            return null
        }
        val m = Regex("package:" + Regex.escape(paket) + "\\s+uid:(\\d+)").find(r.second)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }

    fun pidDenganUid(uid: Int): List<Int> {
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "ls -dn /proc/[0-9]*"))
        } catch (e: Throwable) {
            return emptyList()
        }
        val hasil = ArrayList<Int>()
        for (baris in r.second.lines()) {
            val p = baris.trim().split(Regex("\\s+"))
            if (p.size >= 8 && p[2] == uid.toString()) {
                val pid = p.last().removePrefix("/proc/").toIntOrNull()
                if (pid != null) hasil.add(pid)
            }
        }
        return hasil
    }

    private fun hex(s: String): Long? = try {
        java.lang.Long.parseLong(s, 16)
    } catch (e: Throwable) {
        null
    }

    private fun hexStr(v: Long) = java.lang.Long.toHexString(v)

    // ---- Info region libcsharp.so ----
    private data class Region(val mulai: Long, val akhir: Long)

    private class InfoLib(
        val base: Long,
        val rwRegions: List<Region>
    )

    private fun parseLib(sh: GameShell, pid: Int): InfoLib? {
        val teks = sh.jalankan("grep libcsharp.so /proc/$pid/maps") ?: return null
        var base = Long.MAX_VALUE
        var maxAddr = 0L
        val rw = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 6) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val izin = bag[1]
            val fileOff = hex(bag[2]) ?: 0L

            if (b > maxAddr) maxAddr = b
            if (fileOff == 0L && a < base) base = a
            if (izin.startsWith("rw")) rw.add(Region(a, b))
        }
        if (base == Long.MAX_VALUE) return null
        return InfoLib(base, rw)
    }

    // ---- Hint (offset lama) ----
    // Dipakai fitur Stop Download Res (kelas LoadResModuleMgr)
    fun kelasHint(sh: GameShell, pid: Int, base: Long, off: Long, nama: String): Long? =
        kelasDariHint(sh, pid, base, longArrayOf(off), nama)

    private fun kelasDariHint(sh: GameShell, pid: Int, base: Long, hints: LongArray, nama: String): Long? {
        for (off in hints) {
            val a = sh.bacaLong(pid, base + off) ?: continue
            if (a == 0L) continue
            val np = sh.bacaLong(pid, a + 0x10L) ?: continue
            if (np == 0L) continue
            val s = sh.bacaTeks(pid, np, 48) ?: continue
            if (s == nama) return a
        }
        return null
    }

    // ════════════════════════════════════════════════════════════════
    //  REVERSE SEARCH — cari string dulu, lalu trace pointer mundur
    // ════════════════════════════════════════════════════════════════

    // Konversi Long ke 8-byte little-endian array
    private fun longToLE(v: Long): ByteArray {
        val b = ByteArray(8)
        for (i in 0..7) b[i] = ((v ushr (i * 8)) and 0xFF).toByte()
        return b
    }

    // Cari byte pattern di region-region, return alamat pertama yang cocok.
    // Scan pada interval 'align' byte (1 untuk string, 8 untuk pointer).
    private fun cariPattern(
        sh: GameShell, pid: Int,
        regions: List<Region>, pattern: ByteArray,
        align: Int = 1, info: ((Int) -> Unit)? = null
    ): Long? {
        val chunkSize = 2097152  // 2MB
        var readCount = 0

        for (reg in regions) {
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                readCount++
                if (readCount % 100 == 0) info?.invoke(readCount)
                if (data == null) break

                val limit = data.size - pattern.size
                var i = 0
                while (i <= limit) {
                    var cocok = true
                    for (j in pattern.indices) {
                        if (data[i + j] != pattern[j]) { cocok = false; break }
                    }
                    if (cocok) {
                        info?.invoke(readCount)
                        return pos + i.toLong()
                    }
                    i += align
                }

                // Overlap supaya pattern di batas chunk tidak terlewat
                if (align == 1) {
                    pos += (chunkSize - pattern.size + 1).toLong()
                } else {
                    pos += chunkSize.toLong()
                }
            }
        }

        info?.invoke(readCount)
        return null
    }

    // Parse /proc/pid/maps → kumpulkan region berdasarkan tipe
    private data class PetaRegion(
        val metadata: List<Region>,   // region dari file *metadata* (prio tertinggi)
        val rwAnon: List<Region>,     // rw-p anonymous (decrypted metadata biasanya di sini)
        val writable: List<Region>,   // semua rw-p (termasuk .so bss)
        val semua: List<Region>       // semua readable
    )

    private fun parseMaps(sh: GameShell, pid: Int): PetaRegion? {
        val teks = sh.jalankan("cat /proc/$pid/maps", batasMs = 8000) ?: return null

        val meta = ArrayList<Region>()
        val rwAnon = ArrayList<Region>()
        val rw = ArrayList<Region>()
        val all = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 2) continue
            val izin = bag[1]
            if (!izin.startsWith("r")) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val reg = Region(a, b)

            all.add(reg)
            val namaFile = if (bag.size >= 6) bag.last() else ""
            val isAnon = namaFile.isEmpty() || namaFile.startsWith("[")
            if (namaFile.contains("metadata", ignoreCase = true)) {
                meta.add(reg)
            }
            if (izin.startsWith("rw")) {
                rw.add(reg)
                if (isAnon) rwAnon.add(reg)
            }
        }

        return PetaRegion(meta, rwAnon, rw, all)
    }

    // Cari SEMUA kemunculan byte pattern (maks maxCount), return list of addresses.
    private fun cariSemuaPattern(
        sh: GameShell, pid: Int,
        regions: List<Region>, pattern: ByteArray,
        align: Int = 1, maxCount: Int = 10,
        info: ((Int) -> Unit)? = null
    ): List<Long> {
        val chunkSize = 2097152  // 2MB
        var readCount = 0
        val hasil = ArrayList<Long>()

        for (reg in regions) {
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                readCount++
                if (readCount % 50 == 0) info?.invoke(readCount)
                if (data == null) break

                val limit = data.size - pattern.size
                var i = 0
                while (i <= limit) {
                    var cocok = true
                    for (j in pattern.indices) {
                        if (data[i + j] != pattern[j]) { cocok = false; break }
                    }
                    if (cocok) {
                        hasil.add(pos + i.toLong())
                        if (hasil.size >= maxCount) {
                            info?.invoke(readCount)
                            return hasil
                        }
                    }
                    i += align
                }

                if (align == 1) {
                    pos += (chunkSize - pattern.size + 1).toLong()
                } else {
                    pos += chunkSize.toLong()
                }
            }
        }

        info?.invoke(readCount)
        return hasil
    }

    // ── Langkah 1: Cari SEMUA lokasi string "NamaKelas\0" di memori ──
    private fun cariSemuaString(
        sh: GameShell, pid: Int, nama: String,
        peta: PetaRegion, info: (String) -> Unit
    ): List<Long> {
        val pattern = (nama + "\u0000").toByteArray(Charsets.ISO_8859_1)
        info("Cari string '$nama'...")

        // Prioritas: metadata file → rw anonymous (decrypted metadata) → semua rw → all
        // Skip readonly — class name string ga pernah di r--p / r-xp
        val grupUrutan = listOf(
            "meta" to peta.metadata,
            "rw-anon" to peta.rwAnon,
            "rw-all" to peta.writable,
            "all" to peta.semua
        )
        val sudahGlobal = HashSet<Long>()
        val hasil = ArrayList<Long>()

        for ((label, regions) in grupUrutan) {
            val baru = ArrayList<Region>()
            for (r in regions) {
                if (sudahGlobal.add(r.mulai)) baru.add(r)
            }
            if (baru.isEmpty()) continue

            info("Cari string ($label, ${baru.size} region)...")
            val ditemukan = cariSemuaPattern(sh, pid, baru, pattern, align = 1,
                maxCount = 10 - hasil.size) { n ->
                if (n % 50 == 0) info("Cari string ($label): $n reads...")
            }
            hasil.addAll(ditemukan)
            if (hasil.isNotEmpty()) break  // ketemu! ga perlu cari di grup berikutnya
        }

        info("String '$nama': ${hasil.size} lokasi ditemukan")
        return hasil
    }

    // ── Langkah 2: Cari metadata yang punya name ptr = strAddr ──
    //  Il2CppClass struct punya name pointer di offset +0x10.
    //  Jadi cari 8-byte LE dari strAddr di region rw, pada posisi 8-byte aligned.
    //  Kalau ketemu di posisi P, maka metadataAddr = P - 0x10.
    //  Validasi: baca +0xA8 (static data ptr) harus non-zero.
    private fun cariMetadata(
        sh: GameShell, pid: Int, strAddr: Long,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        val pattern = longToLE(strAddr)

        // Cari hanya di region writable (rw-p) — metadata struct selalu di sini
        val sudah = HashSet<Long>()
        val unique = peta.writable.filter { sudah.add(it.mulai) }
        val searchRegions = ArrayList(unique)

        while (true) {
            val posisi = cariPattern(sh, pid, searchRegions, pattern, align = 8) { n ->
                if (n % 50 == 0) info("Cari metadata (rw): $n reads...")
            }

            if (posisi == null) break

            val metaAddr = posisi - 0x10L
            // Validasi: static data pointer di +0xA8 harus non-zero
            val sdPtr = sh.bacaLong(pid, metaAddr + 0xA8L)
            if (sdPtr != null && sdPtr != 0L) {
                return metaAddr
            }

            // False positive — lanjut cari setelah posisi ini
            val sisaStart = posisi + 8
            searchRegions.clear()
            for (r in unique) {
                if (r.akhir <= sisaStart) continue
                if (r.mulai < sisaStart) {
                    searchRegions.add(Region(sisaStart, r.akhir))
                } else {
                    searchRegions.add(r)
                }
            }
            if (searchRegions.isEmpty()) break
        }

        return null
    }

    // ── Langkah 3: Cari entry di .bss yang menunjuk ke metaAddr ──
    private fun cariBssEntry(
        sh: GameShell, pid: Int, lib: InfoLib, metaAddr: Long,
        info: (String) -> Unit
    ): Long? {
        val pattern = longToLE(metaAddr)

        val posisi = cariPattern(sh, pid, lib.rwRegions, pattern, align = 8)
        if (posisi != null) {
            val offset = posisi - lib.base
            info("BSS entry @ offset 0x${hexStr(offset)}")
            return posisi
        }
        return null
    }

    // ── Reverse search: gabungkan 3 langkah, coba semua string match ──
    private fun scanReverse(
        sh: GameShell, pid: Int, lib: InfoLib, nama: String,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        // Langkah 1: cari SEMUA lokasi string (maks 10)
        val daftarStr = cariSemuaString(sh, pid, nama, peta, info)
        if (daftarStr.isEmpty()) return null

        // Langkah 2: coba tiap string address → cari metadata
        for ((idx, strAddr) in daftarStr.withIndex()) {
            info("Coba string #${idx+1}/${daftarStr.size} @ 0x${hexStr(strAddr)}...")
            val metaAddr = cariMetadata(sh, pid, strAddr, peta, info)
            if (metaAddr != null) {
                info("Metadata '$nama' @ 0x${hexStr(metaAddr)}")
                // Langkah 3: cari .bss entry (opsional, untuk logging offset)
                cariBssEntry(sh, pid, lib, metaAddr, info)
                return metaAddr
            }
            info("String #${idx+1} tidak punya metadata valid")
        }

        info("Metadata '$nama' tidak ditemukan dari ${daftarStr.size} string")
        return null
    }

    // ═══════════════════════════════════════════════════
    //  NATIVE SCANNER — jalankan memscan binary via Shizuku
    // ═══════════════════════════════════════════════════

    // Deploy binary memscan dari assets ke sandbox game
    fun siapkanScanner(ctx: Context, paket: String, info: (String) -> Unit): Boolean {
        if (scannerSiap) return true
        try {
            // 1. Extract dari assets ke files dir app kita
            val lokal = File(ctx.filesDir, "memscan")
            ctx.assets.open("memscan").use { inp ->
                lokal.outputStream().use { out ->
                    inp.copyTo(out)
                }
            }
            lokal.setExecutable(true)

            // 2. Push ke sandbox game via Shizuku
            //    Pipe binary langsung via stdin ke cat > file
            val tujuan = "/data/data/$paket/memscan"
            scannerPath = tujuan

            info("Deploy scanner...")
            val bytes = lokal.readBytes()

            val p = ShizukuHelper.start(arrayOf(
                "sh", "-c", "run-as $paket sh -c 'cat > $tujuan && chmod 755 $tujuan'"
            ))
            p.outputStream.write(bytes)
            p.outputStream.close()
            val code = p.waitFor()

            if (code != 0) {
                val err = try { p.errorStream.bufferedReader().readText() } catch (_: Throwable) { "" }
                info("Deploy scanner gagal: $err")
                return false
            }

            scannerSiap = true
            info("Scanner siap")
            return true
        } catch (e: Throwable) {
            info("Deploy scanner error: ${e.message}")
            return false
        }
    }

    // Jalankan native scanner untuk full reverse search
    // Output: "metaAddr staticDataAddr" (hex)
    // Return: Pair(metaAddr, staticDataAddr) atau null
    private fun scanNative(paket: String, pid: Int, nama: String, info: (String) -> Unit): Pair<Long, Long>? {
        if (!scannerSiap) return null

        try {
            info("Native scan '$nama'...")
            val cmd = "$scannerPath $pid full $nama"
            val (code, stdout, stderr) = ShizukuHelper.run(arrayOf("sh", "-c", "run-as $paket sh -c \"$cmd\""))

            // Log stderr (progress info)
            var offsetBaru = 0L
            for (line in stderr.lines()) {
                if (line.isNotBlank()) info("[scan] $line")
                val m = Regex("STEP3 bss @ 0x[0-9a-fA-F]+ \\(offset 0x([0-9a-fA-F]+)\\)").find(line)
                if (m != null) offsetBaru = hex(m.groupValues[1]) ?: 0L
            }

            if (code != 0 || stdout.isBlank()) {
                info("Native scan gagal (code=$code)")
                return null
            }

            // Parse output: "metaAddr staticDataAddr"
            val parts = stdout.trim().split(Regex("\\s+"))
            if (parts.size >= 2) {
                val meta = hex(parts[0])
                val sd = hex(parts[1])
                if (meta != null && sd != null) {
                    info("Native: metadata=0x${hexStr(meta)} sd=0x${hexStr(sd)}")
                    if (offsetBaru != 0L && offsetBaru != Prefs.hintBelajar(nama)) {
                        Prefs.simpanHintBelajar(nama, offsetBaru)
                        info("Offset $nama dipelajari: 0x${hexStr(offsetBaru)} (dipakai sebagai hint berikutnya)")
                    }
                    if (offsetBaru != 0L) { hintAktif = true; hintHabisWaktu = 0 }
                    return Pair(meta, sd)
                }
            }

            info("Native scan output tidak valid: $stdout")
            return null
        } catch (e: Throwable) {
            info("Native scan error: ${e.message}")
            return null
        }
    }

    // ── cariKelas: hint → native scan → shell reverse search ──
    private fun cariKelas(
        sh: GameShell, pid: Int, lib: InfoLib,
        hints: LongArray, nama: String, paket: String,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        val hints = hintUntuk(nama, hints)
        // 1. Coba hint (cepat, 3 read per offset)
        var dariHint = kelasDariHint(sh, pid, lib.base, hints, nama)
        // Slot kelas baru terisi setelah game selesai memuat. Menunggu hint (1 baca per 400 ms) jauh lebih murah daripada scan
        // penuh memori: scan saat game masih memuat butuh ±20 dtk, bersaing CPU dengan game, lalu gagal.
        if (dariHint == null && hintAktif) {
            val batas = System.currentTimeMillis() + (if (nama == "SystemData") 60_000L else 12_000L)
            var habis = true
            while (dariHint == null) {
                if (System.currentTimeMillis() > batas) break
                var terbaca = false
                for (off in hints) if (sh.bacaLong(pid, lib.base + off) != null) { terbaca = true; break }
                if (!terbaca) { habis = false; break }   // proses game sudah hilang
                try { Thread.sleep(400) } catch (_: InterruptedException) { habis = false; break }
                dariHint = kelasDariHint(sh, pid, lib.base, hints, nama)
            }
            if (dariHint == null && habis) {
                hintHabisWaktu++
                info("Hint $nama belum cocok sampai batas waktu ($hintHabisWaktu)")
                if (hintHabisWaktu >= 2) { hintAktif = false; info("Hint dimatikan: kemungkinan versi game berbeda, memakai scan penuh") }
            }
        }
        if (dariHint != null) {
            hintHabisWaktu = 0
            info("$nama ditemukan (hint)")
            return dariHint
        }

        info("Offset $nama berubah, scanning...")

        // 2. Native scanner (cepat, 1 proses). Kalau gagal (biasanya data game belum selesai dimuat), coba sekali lagi sebentar lagi
        var native = scanNative(paket, pid, nama, info)
        if (native == null && scannerSiap) {
            try { Thread.sleep(1500) } catch (_: InterruptedException) {}
            native = scanNative(paket, pid, nama, info)
        }
        if (native != null) {
            nativeGagalBeruntun = 0
            info("$nama ditemukan (native)")
            return native.first
        }

        // 3. Scan lewat shell butuh sampai beberapa menit dan hampir tidak pernah berhasil kalau native gagal karena game
        // belum siap. Kalau scanner native siap, kembali saja (pemanggil mengulang), shell hanya dipakai sesudah gagal berulang
        if (scannerSiap) {
            nativeGagalBeruntun++
            if (nativeGagalBeruntun < 8) {
                info("Native scan belum menemukan '$nama' (percobaan $nativeGagalBeruntun), diulang sebentar lagi tanpa scan shell")
                return null
            }
            nativeGagalBeruntun = 0
        }
        info("Fallback ke shell scan...")
        return scanReverse(sh, pid, lib, nama, peta, info)
    }

    @Volatile private var nativeGagalBeruntun = 0

    fun cari(paket: String, sh: GameShell, info: (String) -> Unit): Sasaran? {
        val uid = uidPaket(paket)
        if (uid == null) {
            info("Paket $paket tidak ditemukan")
            return null
        }
        val kandidat = pidDenganUid(uid)
        if (kandidat.isEmpty()) {
            info("Tidak ada proses milik uid $uid (game belum dibuka?)")
            return null
        }

        // Cari proses dengan libcsharp.so terbesar
        var terbaik = -1
        var ukuranTerbaik = 0L
        var libTerbaik: InfoLib? = null
        for (pid in kandidat) {
            val lib = parseLib(sh, pid) ?: continue
            var ukuran = 0L
            for (r in lib.rwRegions) ukuran += r.akhir - r.mulai
            if (ukuran > ukuranTerbaik) {
                terbaik = pid
                ukuranTerbaik = ukuran
                libTerbaik = lib
            }
        }
        val lib = libTerbaik
        if (terbaik < 0 || lib == null) {
            info("Proses game (libcsharp.so) belum ditemukan")
            return null
        }

        // Parse maps sekali, pakai untuk semua pencarian
        val peta = parseMaps(sh, terbaik)
        if (peta == null) {
            info("Gagal baca /proc/$terbaik/maps")
            return null
        }

        info("Mencari kelas SystemData...")
        val kSd = cariKelas(sh, terbaik, lib, HINT_SD, "SystemData", paket, peta, info)
        if (kSd == null) {
            info("Kelas SystemData tidak ditemukan (coba restart game)")
            return null
        }

        info("Mencari kelas LogicBattleManager...")
        val kLbm = cariKelas(sh, terbaik, lib, HINT_LBM, "LogicBattleManager", paket, peta, info)
        if (kLbm == null) {
            info("Kelas LogicBattleManager tidak ditemukan (coba restart game)")
            return null
        }

        // LogicBattleScene dipakai Stop Minion, First Blood dan Epic Comeback. Gagal menemukan bukan masalah besar.
        info("Mencari kelas LogicBattleScene...")
        var sceneGlobal = 0L
        val kScene = kelasDariHint(sh, terbaik, lib.base, hintUntuk("LogicBattleScene", HINT_SCENE), "LogicBattleScene")
            ?: scanNative(paket, terbaik, "LogicBattleScene", info)?.first
        if (kScene != null) {
            val st = sh.bacaLong(terbaik, kScene + 0xA8L)
            if (st != null && st != 0L) sceneGlobal = st
        }
        if (sceneGlobal == 0L) info("LogicBattleScene tidak ditemukan (Stop Minion / First Blood tidak jalan)")

        val sd = sh.bacaLong(terbaik, kSd + 0xA8L)
        val sl = sh.bacaLong(terbaik, kLbm + 0xA8L)
        if (sd == null || sl == null || sd == 0L || sl == 0L) {
            info("Data statis game belum siap")
            return null
        }
        // OFF_LBM_INSTANCE: offset field statics LogicBattleManager yang berisi pointer ke instance match aktif.
        // Dulu 0x28, tapi sesudah update game (27 Nov 2026) offset itu selalu 0 walau sudah di dalam match.
        // Ditemukan lewat dump before (lobby, = 0) vs after (di dalam match, = pointer valid 0x6f....) di +0x650.
        val OFF_LBM_INSTANCE = 0x650L
        val ringkas = "pid=$terbaik libcsharp=0x" + hexStr(lib.base) +
            " SystemData=0x" + hexStr(sd) +
            " LBM_global=0x" + hexStr(sl + OFF_LBM_INSTANCE)
        return Sasaran(terbaik, lib.base, sd, sl + OFF_LBM_INSTANCE, ringkas, sceneGlobal)
    }
}
