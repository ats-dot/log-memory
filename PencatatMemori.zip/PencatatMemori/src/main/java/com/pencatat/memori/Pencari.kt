package com.pencatat.memori

class Sasaran(
    val pid: Int,
    val libBase: Long,
    val sdStatis: Long,
    val lbmGlobal: Long,
    val ringkas: String
)

// Mencari proses game di dalam Multi Run lalu menghitung alamat objek yang dipantau,
// dengan rantai pointer yang sama seperti script GG.
object Pencari {

    // Alamat tetap di libcsharp.so: versi game baru dulu, lalu versi lama
    private val KELAS_SD = longArrayOf(0x6497880L)
    private val KELAS_LBM = longArrayOf(0x6497780L)

    fun uidPaket(paket: String): Int? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return null
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "pm list packages -U $paket"))
        } catch (e: Throwable) {
            return null
        }
        val m = Regex("package:" + Regex.escape(paket) + "\\s+uid:(\\d+)").find(r.second)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }

    // Semua proses milik uid tertentu. Contoh baris:
    // dr-xr-xr-x 9 10434 10434 0 2026-11-11 14:16 /proc/20720
    fun pidDenganUid(uid: Int): List<Int> {
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "ls -dn /proc/[0-9]*"))
        } catch (e: Throwable) {
            return emptyList()
        }
        val hasil = ArrayList<Int>()
        for (baris in r.second.lines()) {
            val p = baris.trim().split(Regex("\\s+"))
            if (p.size >= 8 && p[2] == uid.toString()) {
                val pid = p.last().removePrefix("/proc/").toIntOrNull()
                if (pid != null) hasil.add(pid)
            }
        }
        return hasil
    }

    private fun hex(s: String): Long? = try {
        java.lang.Long.parseLong(s, 16)
    } catch (e: Throwable) {
        null
    }

    private fun kelas(sh: GameShell, pid: Int, base: Long, offsets: LongArray, nama: String): Long? {
        for (off in offsets) {
            val a = sh.bacaLong(pid, base + off) ?: continue
            if (a == 0L) continue
            val np = sh.bacaLong(pid, a + 0x10L) ?: continue
            if (np == 0L) continue
            val s = sh.bacaTeks(pid, np, 48) ?: continue
            if (s == nama) return a
        }
        return null
    }

    fun cari(paket: String, sh: GameShell, info: (String) -> Unit): Sasaran? {
        val uid = uidPaket(paket)
        if (uid == null) {
            info("Paket $paket tidak ditemukan")
            return null
        }
        val kandidat = pidDenganUid(uid)
        if (kandidat.isEmpty()) {
            info("Tidak ada proses milik uid $uid (game belum dibuka?)")
            return null
        }

        var terbaik = -1
        var ukuranTerbaik = 0L
        var baseTerbaik = 0L
        for (pid in kandidat) {
            val teks = sh.jalankan("grep libcsharp.so /proc/$pid/maps") ?: continue
            var total = 0L
            var base = Long.MAX_VALUE
            for (baris in teks.lines()) {
                val bag = baris.trim().split(Regex("\\s+"))
                if (bag.size < 6) continue
                val rentang = bag[0].split("-")
                if (rentang.size != 2) continue
                val a = hex(rentang[0]) ?: continue
                val b = hex(rentang[1]) ?: continue
                total += (b - a)
                val offset = hex(bag[2]) ?: 0L
                if (offset == 0L && a < base) base = a
            }
            if (total > ukuranTerbaik && base != Long.MAX_VALUE) {
                terbaik = pid
                ukuranTerbaik = total
                baseTerbaik = base
            }
        }
        if (terbaik < 0) {
            info("Proses game (libcsharp.so) belum ditemukan")
            return null
        }

        val kSd = kelas(sh, terbaik, baseTerbaik, KELAS_SD, "SystemData")
        if (kSd == null) {
            info("Kelas SystemData tidak cocok (versi game berubah?)")
            return null
        }
        val kLbm = kelas(sh, terbaik, baseTerbaik, KELAS_LBM, "LogicBattleManager")
        if (kLbm == null) {
            info("Kelas LogicBattleManager tidak cocok (versi game berubah?)")
            return null
        }
        val sd = sh.bacaLong(terbaik, kSd + 0xA8L)
        val sl = sh.bacaLong(terbaik, kLbm + 0xA8L)
        if (sd == null || sl == null || sd == 0L || sl == 0L) {
            info("Data statis game belum siap")
            return null
        }
        val ringkas = "pid=$terbaik libcsharp=0x" + java.lang.Long.toHexString(baseTerbaik) +
            " SystemData=0x" + java.lang.Long.toHexString(sd) +
            " LBM_global=0x" + java.lang.Long.toHexString(sl + 0x28L)
        return Sasaran(terbaik, baseTerbaik, sd, sl + 0x28L, ringkas)
    }
}
