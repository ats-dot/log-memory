package com.pencatat.memori

class Sasaran(
    val pid: Int,
    val libBase: Long,
    val sdStatis: Long,
    val lbmGlobal: Long,
    val ringkas: String
)

// Mencari proses game di dalam Multi Run lalu menghitung alamat objek yang dipantau,
// dengan rantai pointer yang sama seperti script GG.
//
// Versi baru: scan otomatis region .bss libcsharp.so, tidak pakai offset hardcode.
// Kalau game update, alamat kelas bergeser tapi nama tetap sama ("SystemData" dll),
// jadi app tetap jalan tanpa perlu update offset manual.
object Pencari {

    // Offset lama disimpan sebagai hint, dicoba duluan supaya cepat kalau belum update.
    // Tambahkan offset baru di sini setiap kali ketemu supaya versi berikutnya makin cepat.
    private val HINT_SD = longArrayOf(0x6497880L)
    private val HINT_LBM = longArrayOf(0x6497780L)

    fun uidPaket(paket: String): Int? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return null
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "pm list packages -U $paket"))
        } catch (e: Throwable) {
            return null
        }
        val m = Regex("package:" + Regex.escape(paket) + "\\s+uid:(\\d+)").find(r.second)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }

    fun pidDenganUid(uid: Int): List<Int> {
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "ls -dn /proc/[0-9]*"))
        } catch (e: Throwable) {
            return emptyList()
        }
        val hasil = ArrayList<Int>()
        for (baris in r.second.lines()) {
            val p = baris.trim().split(Regex("\\s+"))
            if (p.size >= 8 && p[2] == uid.toString()) {
                val pid = p.last().removePrefix("/proc/").toIntOrNull()
                if (pid != null) hasil.add(pid)
            }
        }
        return hasil
    }

    private fun hex(s: String): Long? = try {
        java.lang.Long.parseLong(s, 16)
    } catch (e: Throwable) {
        null
    }

    // ---- Info region libcsharp.so ----
    private data class Region(val mulai: Long, val akhir: Long, val izin: String, val fileOff: Long)

    private class InfoLib(
        val base: Long,            // alamat terendah region r-xp (file offset 0)
        val minAddr: Long,         // alamat terendah semua region
        val maxAddr: Long,         // alamat tertinggi semua region
        val rwRegions: List<Region> // hanya region rw-p (berisi .bss / data global)
    )

    // Parse /proc/pid/maps untuk libcsharp.so.
    // Mengembalikan base, range alamat keseluruhan, dan daftar region rw-p.
    private fun parseLib(sh: GameShell, pid: Int): InfoLib? {
        val teks = sh.jalankan("grep libcsharp.so /proc/$pid/maps") ?: return null
        var base = Long.MAX_VALUE
        var minAddr = Long.MAX_VALUE
        var maxAddr = 0L
        val rw = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 6) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val izin = bag[1]
            val fileOff = hex(bag[2]) ?: 0L

            if (a < minAddr) minAddr = a
            if (b > maxAddr) maxAddr = b
            if (fileOff == 0L && a < base) base = a
            if (izin.startsWith("rw")) rw.add(Region(a, b, izin, fileOff))
        }
        if (base == Long.MAX_VALUE) return null
        return InfoLib(base, minAddr, maxAddr, rw)
    }

    // Coba dari hint (offset lama). Cepat: 3 read per offset.
    private fun kelasDariHint(sh: GameShell, pid: Int, base: Long, hints: LongArray, nama: String): Long? {
        for (off in hints) {
            val a = sh.bacaLong(pid, base + off) ?: continue
            if (a == 0L) continue
            val np = sh.bacaLong(pid, a + 0x10L) ?: continue
            if (np == 0L) continue
            val s = sh.bacaTeks(pid, np, 48) ?: continue
            if (s == nama) return a
        }
        return null
    }

    // ---- Scan otomatis region .bss ----
    //
    // Strategi:
    // 1. Baca .bss dalam chunk 64KB
    // 2. Di tiap chunk, ambil semua qword yang != 0
    // 3. Filter: hanya yang nilainya di range alamat libcsharp.so
    //    (class metadata Il2cpp biasanya ada di range .so sendiri)
    // 4. Untuk kandidat yang lolos, cek apakah pointer+0x10 menunjuk ke nama kelas
    //
    // Filter di langkah 3 sangat mengurangi kandidat — kebanyakan nilai non-zero di .bss
    // adalah pointer heap (jauh di luar range .so) atau integer biasa.

    private fun scanBss(
        sh: GameShell, pid: Int, lib: InfoLib, nama: String,
        info: (String) -> Unit
    ): Long? {
        val panjangNama = nama.length
        val regions = lib.rwRegions
        if (regions.isEmpty()) return null

        // Range alamat libcsharp.so untuk filter pointer
        val libMin = lib.minAddr
        val libMax = lib.maxAddr

        var totalChecked = 0

        for (reg in regions) {
            val ukuranKB = (reg.akhir - reg.mulai) / 1024
            info("Scan ${ukuranKB}KB rw region...")

            val chunkSize = 65536
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                if (data == null) {
                    pos += chunkSize
                    continue
                }

                // Scan tiap 8-byte aligned position
                var i = 0
                while (i + 7 < data.size) {
                    val ptr = Daftar.le(data, i, 8)
                    i += 8

                    // Filter 1: skip nol dan nilai kecil
                    if (ptr == 0L || ptr < 0x100000L) continue

                    // Filter 2: hanya cek pointer yang menunjuk ke range libcsharp.so
                    // (class metadata Il2cpp disimpan di dalam range .so)
                    if (ptr < libMin || ptr >= libMax) continue

                    // Filter 3: harus 8-byte aligned (struct metadata aligned)
                    if (ptr and 7L != 0L) continue

                    // Kandidat valid! Cek nama kelas di ptr+0x10
                    totalChecked++
                    val np = sh.bacaLong(pid, ptr + 0x10L) ?: continue
                    if (np == 0L || np < 0x100000L) continue
                    val s = sh.bacaTeks(pid, np, panjangNama + 1) ?: continue
                    if (s == nama) {
                        // Hitung offset dari base untuk jadi hint di versi berikutnya
                        val off = (pos + (i - 8).toLong()) - lib.base
                        info("$nama ditemukan! offset=0x${java.lang.Long.toHexString(off)} (checked $totalChecked ptrs)")
                        return ptr
                    }
                }
                pos += chunkSize
            }
        }
        info("$nama tidak ditemukan setelah cek $totalChecked pointer")
        return null
    }

    // Cari kelas: hint dulu, kalau gagal scan .bss otomatis
    private fun cariKelas(
        sh: GameShell, pid: Int, lib: InfoLib,
        hints: LongArray, nama: String, info: (String) -> Unit
    ): Long? {
        // 1. Coba hint (cepat, 3 read per offset)
        val dariHint = kelasDariHint(sh, pid, lib.base, hints, nama)
        if (dariHint != null) {
            info("$nama ditemukan (hint)")
            return dariHint
        }

        // 2. Scan .bss region otomatis
        info("Offset $nama berubah, scanning otomatis...")
        return scanBss(sh, pid, lib, nama, info)
    }

    fun cari(paket: String, sh: GameShell, info: (String) -> Unit): Sasaran? {
        val uid = uidPaket(paket)
        if (uid == null) {
            info("Paket $paket tidak ditemukan")
            return null
        }
        val kandidat = pidDenganUid(uid)
        if (kandidat.isEmpty()) {
            info("Tidak ada proses milik uid $uid (game belum dibuka?)")
            return null
        }

        // Cari proses dengan libcsharp.so terbesar
        var terbaik = -1
        var ukuranTerbaik = 0L
        var libTerbaik: InfoLib? = null
        for (pid in kandidat) {
            val lib = parseLib(sh, pid) ?: continue
            val ukuran = lib.maxAddr - lib.minAddr
            if (ukuran > ukuranTerbaik) {
                terbaik = pid
                ukuranTerbaik = ukuran
                libTerbaik = lib
            }
        }
        val lib = libTerbaik
        if (terbaik < 0 || lib == null) {
            info("Proses game (libcsharp.so) belum ditemukan")
            return null
        }

        info("Mencari kelas SystemData...")
        val kSd = cariKelas(sh, terbaik, lib, HINT_SD, "SystemData", info)
        if (kSd == null) {
            info("Kelas SystemData tidak ditemukan (coba restart game)")
            return null
        }

        info("Mencari kelas LogicBattleManager...")
        val kLbm = cariKelas(sh, terbaik, lib, HINT_LBM, "LogicBattleManager", info)
        if (kLbm == null) {
            info("Kelas LogicBattleManager tidak ditemukan (coba restart game)")
            return null
        }

        val sd = sh.bacaLong(terbaik, kSd + 0xA8L)
        val sl = sh.bacaLong(terbaik, kLbm + 0xA8L)
        if (sd == null || sl == null || sd == 0L || sl == 0L) {
            info("Data statis game belum siap")
            return null
        }
        val ringkas = "pid=$terbaik libcsharp=0x" + java.lang.Long.toHexString(lib.base) +
            " SystemData=0x" + java.lang.Long.toHexString(sd) +
            " LBM_global=0x" + java.lang.Long.toHexString(sl + 0x28L)
        return Sasaran(terbaik, lib.base, sd, sl + 0x28L, ringkas)
    }
}
