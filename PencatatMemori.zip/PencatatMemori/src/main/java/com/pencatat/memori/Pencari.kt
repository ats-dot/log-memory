package com.pencatat.memori

class Sasaran(
    val pid: Int,
    val libBase: Long,
    val sdStatis: Long,
    val lbmGlobal: Long,
    val ringkas: String
)

// Mencari kelas Il2cpp di memori game secara otomatis.
//
// Strategi pencarian (reverse search):
//   1. Cari string "SystemData\0" di memori proses (~100 read)
//   2. Cari pointer ke string itu di region rw (metadata struct, +0x10) (~400 read)
//   3. Cari pointer ke metadata itu di .bss libcsharp.so (~20 read)
//
// Jauh lebih cepat dari forward scan karena tidak perlu cek 144K+ kandidat satu per satu.
object Pencari {

    private val HINT_SD = longArrayOf(0x6497880L)
    private val HINT_LBM = longArrayOf(0x6497780L)

    fun uidPaket(paket: String): Int? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return null
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "pm list packages -U $paket"))
        } catch (e: Throwable) {
            return null
        }
        val m = Regex("package:" + Regex.escape(paket) + "\\s+uid:(\\d+)").find(r.second)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }

    fun pidDenganUid(uid: Int): List<Int> {
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "ls -dn /proc/[0-9]*"))
        } catch (e: Throwable) {
            return emptyList()
        }
        val hasil = ArrayList<Int>()
        for (baris in r.second.lines()) {
            val p = baris.trim().split(Regex("\\s+"))
            if (p.size >= 8 && p[2] == uid.toString()) {
                val pid = p.last().removePrefix("/proc/").toIntOrNull()
                if (pid != null) hasil.add(pid)
            }
        }
        return hasil
    }

    private fun hex(s: String): Long? = try {
        java.lang.Long.parseLong(s, 16)
    } catch (e: Throwable) {
        null
    }

    private fun hexStr(v: Long) = java.lang.Long.toHexString(v)

    // ---- Info region libcsharp.so ----
    private data class Region(val mulai: Long, val akhir: Long)

    private class InfoLib(
        val base: Long,
        val rwRegions: List<Region>
    )

    private fun parseLib(sh: GameShell, pid: Int): InfoLib? {
        val teks = sh.jalankan("grep libcsharp.so /proc/$pid/maps") ?: return null
        var base = Long.MAX_VALUE
        var maxAddr = 0L
        val rw = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 6) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val izin = bag[1]
            val fileOff = hex(bag[2]) ?: 0L

            if (b > maxAddr) maxAddr = b
            if (fileOff == 0L && a < base) base = a
            if (izin.startsWith("rw")) rw.add(Region(a, b))
        }
        if (base == Long.MAX_VALUE) return null
        return InfoLib(base, rw)
    }

    // ---- Hint (offset lama) ----
    private fun kelasDariHint(sh: GameShell, pid: Int, base: Long, hints: LongArray, nama: String): Long? {
        for (off in hints) {
            val a = sh.bacaLong(pid, base + off) ?: continue
            if (a == 0L) continue
            val np = sh.bacaLong(pid, a + 0x10L) ?: continue
            if (np == 0L) continue
            val s = sh.bacaTeks(pid, np, 48) ?: continue
            if (s == nama) return a
        }
        return null
    }

    // ════════════════════════════════════════════════════════════════
    //  REVERSE SEARCH — cari string dulu, lalu trace pointer mundur
    // ════════════════════════════════════════════════════════════════

    // Konversi Long ke 8-byte little-endian array
    private fun longToLE(v: Long): ByteArray {
        val b = ByteArray(8)
        for (i in 0..7) b[i] = ((v ushr (i * 8)) and 0xFF).toByte()
        return b
    }

    // Cari byte pattern di region-region, return alamat pertama yang cocok.
    // Scan pada interval 'align' byte (1 untuk string, 8 untuk pointer).
    private fun cariPattern(
        sh: GameShell, pid: Int,
        regions: List<Region>, pattern: ByteArray,
        align: Int = 1, info: ((Int) -> Unit)? = null
    ): Long? {
        val chunkSize = 2097152  // 2MB
        var readCount = 0

        for (reg in regions) {
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                readCount++
                if (readCount % 100 == 0) info?.invoke(readCount)
                if (data == null) break

                val limit = data.size - pattern.size
                var i = 0
                while (i <= limit) {
                    var cocok = true
                    for (j in pattern.indices) {
                        if (data[i + j] != pattern[j]) { cocok = false; break }
                    }
                    if (cocok) {
                        info?.invoke(readCount)
                        return pos + i.toLong()
                    }
                    i += align
                }

                // Overlap supaya pattern di batas chunk tidak terlewat
                if (align == 1) {
                    pos += (chunkSize - pattern.size + 1).toLong()
                } else {
                    pos += chunkSize.toLong()
                }
            }
        }

        info?.invoke(readCount)
        return null
    }

    // Parse /proc/pid/maps → kumpulkan region berdasarkan tipe
    private data class PetaRegion(
        val metadata: List<Region>,   // region dari file *metadata* (prio tertinggi)
        val readonly: List<Region>,   // r--p (string pool biasanya di sini)
        val writable: List<Region>,   // rw-p (metadata struct biasanya di sini)
        val semua: List<Region>       // semua readable
    )

    private fun parseMaps(sh: GameShell, pid: Int): PetaRegion? {
        val teks = sh.jalankan("cat /proc/$pid/maps", batasMs = 8000) ?: return null

        val meta = ArrayList<Region>()
        val ro = ArrayList<Region>()
        val rw = ArrayList<Region>()
        val all = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 2) continue
            val izin = bag[1]
            if (!izin.startsWith("r")) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val reg = Region(a, b)

            all.add(reg)
            val namaFile = if (bag.size >= 6) bag.last() else ""
            if (namaFile.contains("metadata", ignoreCase = true)) {
                meta.add(reg)
            }
            if (izin.startsWith("r--") || izin.startsWith("r-x")) {
                ro.add(reg)
            }
            if (izin.startsWith("rw")) {
                rw.add(reg)
            }
        }

        return PetaRegion(meta, ro, rw, all)
    }

    // Cari SEMUA kemunculan byte pattern (maks maxCount), return list of addresses.
    private fun cariSemuaPattern(
        sh: GameShell, pid: Int,
        regions: List<Region>, pattern: ByteArray,
        align: Int = 1, maxCount: Int = 10,
        info: ((Int) -> Unit)? = null
    ): List<Long> {
        val chunkSize = 2097152  // 2MB
        var readCount = 0
        val hasil = ArrayList<Long>()

        for (reg in regions) {
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                readCount++
                if (readCount % 50 == 0) info?.invoke(readCount)
                if (data == null) break

                val limit = data.size - pattern.size
                var i = 0
                while (i <= limit) {
                    var cocok = true
                    for (j in pattern.indices) {
                        if (data[i + j] != pattern[j]) { cocok = false; break }
                    }
                    if (cocok) {
                        hasil.add(pos + i.toLong())
                        if (hasil.size >= maxCount) {
                            info?.invoke(readCount)
                            return hasil
                        }
                    }
                    i += align
                }

                if (align == 1) {
                    pos += (chunkSize - pattern.size + 1).toLong()
                } else {
                    pos += chunkSize.toLong()
                }
            }
        }

        info?.invoke(readCount)
        return hasil
    }

    // ── Langkah 1: Cari SEMUA lokasi string "NamaKelas\0" di memori ──
    private fun cariSemuaString(
        sh: GameShell, pid: Int, nama: String,
        peta: PetaRegion, info: (String) -> Unit
    ): List<Long> {
        val pattern = (nama + "\u0000").toByteArray(Charsets.ISO_8859_1)
        info("Cari string '$nama'...")

        // Prioritas: metadata file → readonly → writable → semua
        val urutan = ArrayList<Region>()
        val sudah = HashSet<Long>()
        for (list in listOf(peta.metadata, peta.readonly, peta.writable, peta.semua)) {
            for (r in list) {
                if (sudah.add(r.mulai)) urutan.add(r)
            }
        }

        val hasil = cariSemuaPattern(sh, pid, urutan, pattern, align = 1, maxCount = 10) { n ->
            if (n % 50 == 0) info("Cari string: $n reads...")
        }

        info("String '$nama': ${hasil.size} lokasi ditemukan")
        return hasil
    }

    // ── Langkah 2: Cari metadata yang punya name ptr = strAddr ──
    //  Il2CppClass struct punya name pointer di offset +0x10.
    //  Jadi cari 8-byte LE dari strAddr di region rw, pada posisi 8-byte aligned.
    //  Kalau ketemu di posisi P, maka metadataAddr = P - 0x10.
    //  Validasi: baca +0xA8 (static data ptr) harus non-zero.
    private fun cariMetadata(
        sh: GameShell, pid: Int, strAddr: Long,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        val pattern = longToLE(strAddr)

        // Cari hanya di region writable (rw-p) — metadata struct selalu di sini
        val sudah = HashSet<Long>()
        val unique = peta.writable.filter { sudah.add(it.mulai) }
        val searchRegions = ArrayList(unique)

        while (true) {
            val posisi = cariPattern(sh, pid, searchRegions, pattern, align = 8) { n ->
                if (n % 50 == 0) info("Cari metadata (rw): $n reads...")
            }

            if (posisi == null) break

            val metaAddr = posisi - 0x10L
            // Validasi: static data pointer di +0xA8 harus non-zero
            val sdPtr = sh.bacaLong(pid, metaAddr + 0xA8L)
            if (sdPtr != null && sdPtr != 0L) {
                return metaAddr
            }

            // False positive — lanjut cari setelah posisi ini
            val sisaStart = posisi + 8
            searchRegions.clear()
            for (r in unique) {
                if (r.akhir <= sisaStart) continue
                if (r.mulai < sisaStart) {
                    searchRegions.add(Region(sisaStart, r.akhir))
                } else {
                    searchRegions.add(r)
                }
            }
            if (searchRegions.isEmpty()) break
        }

        return null
    }

    // ── Langkah 3: Cari entry di .bss yang menunjuk ke metaAddr ──
    private fun cariBssEntry(
        sh: GameShell, pid: Int, lib: InfoLib, metaAddr: Long,
        info: (String) -> Unit
    ): Long? {
        val pattern = longToLE(metaAddr)

        val posisi = cariPattern(sh, pid, lib.rwRegions, pattern, align = 8)
        if (posisi != null) {
            val offset = posisi - lib.base
            info("BSS entry @ offset 0x${hexStr(offset)}")
            return posisi
        }
        return null
    }

    // ── Reverse search: gabungkan 3 langkah, coba semua string match ──
    private fun scanReverse(
        sh: GameShell, pid: Int, lib: InfoLib, nama: String,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        // Langkah 1: cari SEMUA lokasi string (maks 10)
        val daftarStr = cariSemuaString(sh, pid, nama, peta, info)
        if (daftarStr.isEmpty()) return null

        // Langkah 2: coba tiap string address → cari metadata
        for ((idx, strAddr) in daftarStr.withIndex()) {
            info("Coba string #${idx+1}/${daftarStr.size} @ 0x${hexStr(strAddr)}...")
            val metaAddr = cariMetadata(sh, pid, strAddr, peta, info)
            if (metaAddr != null) {
                info("Metadata '$nama' @ 0x${hexStr(metaAddr)}")
                // Langkah 3: cari .bss entry (opsional, untuk logging offset)
                cariBssEntry(sh, pid, lib, metaAddr, info)
                return metaAddr
            }
            info("String #${idx+1} tidak punya metadata valid")
        }

        info("Metadata '$nama' tidak ditemukan dari ${daftarStr.size} string")
        return null
    }

    // ── cariKelas: hint → reverse search ──
    private fun cariKelas(
        sh: GameShell, pid: Int, lib: InfoLib,
        hints: LongArray, nama: String,
        peta: PetaRegion, info: (String) -> Unit
    ): Long? {
        // 1. Coba hint (cepat, 3 read per offset)
        val dariHint = kelasDariHint(sh, pid, lib.base, hints, nama)
        if (dariHint != null) {
            info("$nama ditemukan (hint)")
            return dariHint
        }

        info("Offset $nama berubah, scanning...")

        // 2. Reverse search
        return scanReverse(sh, pid, lib, nama, peta, info)
    }

    fun cari(paket: String, sh: GameShell, info: (String) -> Unit): Sasaran? {
        val uid = uidPaket(paket)
        if (uid == null) {
            info("Paket $paket tidak ditemukan")
            return null
        }
        val kandidat = pidDenganUid(uid)
        if (kandidat.isEmpty()) {
            info("Tidak ada proses milik uid $uid (game belum dibuka?)")
            return null
        }

        // Cari proses dengan libcsharp.so terbesar
        var terbaik = -1
        var ukuranTerbaik = 0L
        var libTerbaik: InfoLib? = null
        for (pid in kandidat) {
            val lib = parseLib(sh, pid) ?: continue
            var ukuran = 0L
            for (r in lib.rwRegions) ukuran += r.akhir - r.mulai
            if (ukuran > ukuranTerbaik) {
                terbaik = pid
                ukuranTerbaik = ukuran
                libTerbaik = lib
            }
        }
        val lib = libTerbaik
        if (terbaik < 0 || lib == null) {
            info("Proses game (libcsharp.so) belum ditemukan")
            return null
        }

        // Parse maps sekali, pakai untuk semua pencarian
        val peta = parseMaps(sh, terbaik)
        if (peta == null) {
            info("Gagal baca /proc/$terbaik/maps")
            return null
        }

        info("Mencari kelas SystemData...")
        val kSd = cariKelas(sh, terbaik, lib, HINT_SD, "SystemData", peta, info)
        if (kSd == null) {
            info("Kelas SystemData tidak ditemukan (coba restart game)")
            return null
        }

        info("Mencari kelas LogicBattleManager...")
        val kLbm = cariKelas(sh, terbaik, lib, HINT_LBM, "LogicBattleManager", peta, info)
        if (kLbm == null) {
            info("Kelas LogicBattleManager tidak ditemukan (coba restart game)")
            return null
        }

        val sd = sh.bacaLong(terbaik, kSd + 0xA8L)
        val sl = sh.bacaLong(terbaik, kLbm + 0xA8L)
        if (sd == null || sl == null || sd == 0L || sl == 0L) {
            info("Data statis game belum siap")
            return null
        }
        val ringkas = "pid=$terbaik libcsharp=0x" + hexStr(lib.base) +
            " SystemData=0x" + hexStr(sd) +
            " LBM_global=0x" + hexStr(sl + 0x28L)
        return Sasaran(terbaik, lib.base, sd, sl + 0x28L, ringkas)
    }
}
