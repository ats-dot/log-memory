package com.pencatat.memori

class Sasaran(
    val pid: Int,
    val libBase: Long,
    val sdStatis: Long,
    val lbmGlobal: Long,
    val ringkas: String
)

// Mencari proses game di dalam Multi Run lalu menghitung alamat objek yang dipantau,
// dengan rantai pointer yang sama seperti script GG.
//
// Versi baru: scan otomatis region .bss libcsharp.so, tidak pakai offset hardcode.
// Kalau game update, alamat kelas bergeser tapi nama tetap sama ("SystemData" dll),
// jadi app tetap jalan tanpa perlu update offset manual.
//
// Scan pakai 3-fase bulk read supaya cepat (~5-15 detik):
//   Fase 1: Baca seluruh region rw-p, kumpulkan semua kandidat pointer
//   Fase 2: Baca metadata bulk (sorted, 256KB per read), ambil name pointer
//   Fase 3: Baca nama bulk, cocokkan dengan target
//
// Kalau scan ketat (filter range libcsharp.so) gagal, ulangi dengan filter longgar
// (semua region mapped) — untuk kasus Il2CppClass dialokasi di heap.
object Pencari {

    // Offset lama disimpan sebagai hint, dicoba duluan supaya cepat kalau belum update.
    // Tambahkan offset baru di sini setiap kali ketemu supaya versi berikutnya makin cepat.
    private val HINT_SD = longArrayOf(0x6497880L)
    private val HINT_LBM = longArrayOf(0x6497780L)

    fun uidPaket(paket: String): Int? {
        if (!Regex("[A-Za-z0-9_.]+").matches(paket)) return null
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "pm list packages -U $paket"))
        } catch (e: Throwable) {
            return null
        }
        val m = Regex("package:" + Regex.escape(paket) + "\\s+uid:(\\d+)").find(r.second)
        return m?.groupValues?.get(1)?.toIntOrNull()
    }

    fun pidDenganUid(uid: Int): List<Int> {
        val r = try {
            ShizukuHelper.run(arrayOf("sh", "-c", "ls -dn /proc/[0-9]*"))
        } catch (e: Throwable) {
            return emptyList()
        }
        val hasil = ArrayList<Int>()
        for (baris in r.second.lines()) {
            val p = baris.trim().split(Regex("\\s+"))
            if (p.size >= 8 && p[2] == uid.toString()) {
                val pid = p.last().removePrefix("/proc/").toIntOrNull()
                if (pid != null) hasil.add(pid)
            }
        }
        return hasil
    }

    private fun hex(s: String): Long? = try {
        java.lang.Long.parseLong(s, 16)
    } catch (e: Throwable) {
        null
    }

    // ---- Info region libcsharp.so ----
    private data class Region(val mulai: Long, val akhir: Long, val izin: String, val fileOff: Long)

    private class InfoLib(
        val base: Long,            // alamat terendah region r-xp (file offset 0)
        val minAddr: Long,         // alamat terendah semua region
        val maxAddr: Long,         // alamat tertinggi semua region
        val rwRegions: List<Region> // hanya region rw-p (berisi .bss / data global)
    )

    // Parse /proc/pid/maps untuk libcsharp.so.
    private fun parseLib(sh: GameShell, pid: Int): InfoLib? {
        val teks = sh.jalankan("grep libcsharp.so /proc/$pid/maps") ?: return null
        var base = Long.MAX_VALUE
        var minAddr = Long.MAX_VALUE
        var maxAddr = 0L
        val rw = ArrayList<Region>()

        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 6) continue
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            val izin = bag[1]
            val fileOff = hex(bag[2]) ?: 0L

            if (a < minAddr) minAddr = a
            if (b > maxAddr) maxAddr = b
            if (fileOff == 0L && a < base) base = a
            if (izin.startsWith("rw")) rw.add(Region(a, b, izin, fileOff))
        }
        if (base == Long.MAX_VALUE) return null
        return InfoLib(base, minAddr, maxAddr, rw)
    }

    // ---- Semua region mapped yang readable (untuk filter pointer longgar) ----

    // Daftar region readable, diurutkan. Untuk cek cepat apakah sebuah alamat valid.
    private class MappedRegions(private val starts: LongArray, private val ends: LongArray) {
        // Binary search: apakah addr ada di salah satu region?
        fun contains(addr: Long): Boolean {
            // Cari region terakhir yang mulai <= addr
            var lo = 0
            var hi = starts.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1
                if (starts[mid] <= addr) lo = mid + 1
                else hi = mid - 1
            }
            // hi = index region terakhir yang mulai <= addr
            return hi >= 0 && addr < ends[hi]
        }
    }

    // Parse semua region readable dari /proc/pid/maps
    private fun parseMapped(sh: GameShell, pid: Int): MappedRegions? {
        val teks = sh.jalankan("cat /proc/$pid/maps", batasMs = 8000) ?: return null
        val starts = ArrayList<Long>()
        val ends = ArrayList<Long>()
        for (baris in teks.lines()) {
            val bag = baris.trim().split(Regex("\\s+"))
            if (bag.size < 2) continue
            val izin = bag[1]
            if (!izin.startsWith("r")) continue  // hanya yang readable
            val rentang = bag[0].split("-")
            if (rentang.size != 2) continue
            val a = hex(rentang[0]) ?: continue
            val b = hex(rentang[1]) ?: continue
            // Merge dengan region sebelumnya kalau contiguous
            if (starts.isNotEmpty() && a == ends.last()) {
                ends[ends.size - 1] = b
            } else {
                starts.add(a)
                ends.add(b)
            }
        }
        if (starts.isEmpty()) return null
        return MappedRegions(starts.toLongArray(), ends.toLongArray())
    }

    // ---- Hint (offset lama) ----

    // Coba dari hint (offset lama). Cepat: 3 read per offset.
    private fun kelasDariHint(sh: GameShell, pid: Int, base: Long, hints: LongArray, nama: String): Long? {
        for (off in hints) {
            val a = sh.bacaLong(pid, base + off) ?: continue
            if (a == 0L) continue
            val np = sh.bacaLong(pid, a + 0x10L) ?: continue
            if (np == 0L) continue
            val s = sh.bacaTeks(pid, np, 48) ?: continue
            if (s == nama) return a
        }
        return null
    }

    // ════════════════════════════════════════════════════════════════
    //  Scan otomatis region .bss — 3 fase bulk read
    // ════════════════════════════════════════════════════════════════
    //
    //  Fase 1: Baca rw region → kumpulkan kandidat pointer
    //  Fase 2: Urutkan kandidat → baca metadata bulk → ambil name pointer
    //  Fase 3: Urutkan name pointer → baca string bulk → cocokkan nama kelas
    //
    //  Mode filter:
    //   - KETAT: kandidat harus menunjuk ke range libcsharp.so (cepat, sedikit kandidat)
    //   - LONGGAR: kandidat boleh menunjuk ke region mapped manapun (lebih lambat,
    //     tapi menangkap kasus Il2CppClass dialokasi di heap/anonim)

    private enum class ModeFilter { KETAT, LONGGAR }

    private fun scanBss(
        sh: GameShell, pid: Int, lib: InfoLib, nama: String,
        mode: ModeFilter, mapped: MappedRegions?,
        info: (String) -> Unit
    ): Long? {
        val panjangNama = nama.length
        val target = nama.toByteArray(Charsets.ISO_8859_1)
        val libMin = lib.minAddr
        val libMax = lib.maxAddr
        val regions = lib.rwRegions
        if (regions.isEmpty()) return null

        val modeNama = if (mode == ModeFilter.KETAT) "ketat" else "longgar"

        // ── Fase 1: Kumpulkan kandidat pointer dari region rw-p ──

        val ptrVal = ArrayList<Long>(4096)
        val ptrBss = ArrayList<Long>(4096)

        var totalByte = 0L
        for (reg in regions) totalByte += reg.akhir - reg.mulai
        info("[$modeNama] Fase 1: baca ${totalByte / 1024}KB...")

        for (reg in regions) {
            val chunkSize = 524288  // 512KB per read
            var pos = reg.mulai
            while (pos < reg.akhir) {
                val sisa = (reg.akhir - pos).toInt().coerceAtMost(chunkSize)
                val data = sh.baca(pid, pos, sisa)
                if (data != null) {
                    var i = 0
                    while (i + 7 < data.size) {
                        val v = Daftar.le(data, i, 8)
                        i += 8

                        // Filter dasar: non-zero, >= 1MB, 8-byte aligned
                        if (v == 0L || v < 0x100000L || v and 7L != 0L) continue

                        // Filter range tergantung mode
                        val valid = when (mode) {
                            ModeFilter.KETAT -> v in libMin until libMax
                            ModeFilter.LONGGAR -> mapped?.contains(v) ?: false
                        }
                        if (!valid) continue

                        ptrVal.add(v)
                        ptrBss.add(pos + (i - 8).toLong())
                    }
                }
                pos += chunkSize
            }
        }

        if (ptrVal.isEmpty()) {
            info("[$modeNama] Tidak ada kandidat")
            return null
        }
        info("[$modeNama] Fase 1: ${ptrVal.size} kandidat")

        // ── Fase 2: Baca metadata bulk, ambil name pointer ──
        //
        //  Urutkan kandidat berdasarkan ptrVal → baca berurutan dengan
        //  buffer 256KB yang dipakai ulang. Jauh lebih cepat dari bacaLong individual.

        val sorted2 = (0 until ptrVal.size).sortedBy { ptrVal[it] }.toIntArray()

        val namePtr = ArrayList<Long>(1024)
        val nameOwner = ArrayList<Int>(1024)

        var bufStart = -1L
        var buf: ByteArray? = null
        val META_CHUNK = 262144  // 256KB

        info("[$modeNama] Fase 2: baca metadata...")
        var readCount2 = 0

        for (si in sorted2) {
            val need = ptrVal[si] + 0x10L

            if (buf == null || need < bufStart || need + 8 > bufStart + buf!!.size) {
                bufStart = (need / 4096L) * 4096L
                buf = sh.baca(pid, bufStart, META_CHUNK)
                readCount2++
                if (buf == null) {
                    buf = sh.baca(pid, bufStart, 4096)
                    if (buf == null) continue
                }
            }

            val off = (need - bufStart).toInt()
            if (off < 0 || off + 8 > buf!!.size) continue
            val np = Daftar.le(buf!!, off, 8)
            if (np != 0L && np >= 0x100000L) {
                namePtr.add(np)
                nameOwner.add(si)
            }
        }

        if (namePtr.isEmpty()) {
            info("[$modeNama] Tidak ada name pointer ($readCount2 reads)")
            return null
        }
        info("[$modeNama] Fase 2: ${namePtr.size} name ptr ($readCount2 reads)")

        // ── Fase 3: Baca nama kelas bulk, cocokkan ──

        val sorted3 = (0 until namePtr.size).sortedBy { namePtr[it] }.toIntArray()

        bufStart = -1L
        buf = null
        var readCount3 = 0

        for (si in sorted3) {
            val np = namePtr[si]

            if (buf == null || np < bufStart || np + panjangNama > bufStart + buf!!.size) {
                bufStart = (np / 4096L) * 4096L
                buf = sh.baca(pid, bufStart, 4096 + panjangNama)
                readCount3++
                if (buf == null) {
                    buf = sh.baca(pid, bufStart, 4096)
                    if (buf == null) continue
                }
            }

            val off = (np - bufStart).toInt()
            if (off < 0 || off + panjangNama > buf!!.size) continue

            var cocok = true
            for (j in 0 until panjangNama) {
                if (buf!![off + j] != target[j]) { cocok = false; break }
            }
            if (cocok) {
                val origIdx = nameOwner[si]
                val bssOff = ptrBss[origIdx] - lib.base
                info("$nama ditemukan! offset=0x${java.lang.Long.toHexString(bssOff)} " +
                    "[$modeNama, ${readCount2 + readCount3} reads]")
                return ptrVal[origIdx]
            }
        }

        info("[$modeNama] $nama tidak ditemukan (${ptrVal.size} kandidat, " +
            "${readCount2 + readCount3} reads)")
        return null
    }

    // Cari kelas: hint → scan ketat → scan longgar
    private fun cariKelas(
        sh: GameShell, pid: Int, lib: InfoLib,
        hints: LongArray, nama: String,
        mapped: MappedRegions?,
        info: (String) -> Unit
    ): Long? {
        // 1. Coba hint (cepat, 3 read per offset)
        val dariHint = kelasDariHint(sh, pid, lib.base, hints, nama)
        if (dariHint != null) {
            info("$nama ditemukan (hint)")
            return dariHint
        }

        info("Offset $nama berubah, scanning...")

        // 2. Scan ketat: kandidat harus dalam range libcsharp.so
        //    Cepat karena sedikit kandidat.
        val ketat = scanBss(sh, pid, lib, nama, ModeFilter.KETAT, null, info)
        if (ketat != null) return ketat

        // 3. Scan longgar: kandidat boleh di region mapped manapun.
        //    Untuk kasus Il2CppClass dialokasi di heap (di luar range .so).
        if (mapped != null) {
            info("Scan ketat gagal, coba scan longgar...")
            val longgar = scanBss(sh, pid, lib, nama, ModeFilter.LONGGAR, mapped, info)
            if (longgar != null) return longgar
        }

        return null
    }

    fun cari(paket: String, sh: GameShell, info: (String) -> Unit): Sasaran? {
        val uid = uidPaket(paket)
        if (uid == null) {
            info("Paket $paket tidak ditemukan")
            return null
        }
        val kandidat = pidDenganUid(uid)
        if (kandidat.isEmpty()) {
            info("Tidak ada proses milik uid $uid (game belum dibuka?)")
            return null
        }

        // Cari proses dengan libcsharp.so terbesar
        var terbaik = -1
        var ukuranTerbaik = 0L
        var libTerbaik: InfoLib? = null
        for (pid in kandidat) {
            val lib = parseLib(sh, pid) ?: continue
            val ukuran = lib.maxAddr - lib.minAddr
            if (ukuran > ukuranTerbaik) {
                terbaik = pid
                ukuranTerbaik = ukuran
                libTerbaik = lib
            }
        }
        val lib = libTerbaik
        if (terbaik < 0 || lib == null) {
            info("Proses game (libcsharp.so) belum ditemukan")
            return null
        }

        // Siapkan daftar region mapped (untuk fallback scan longgar)
        val mapped = parseMapped(sh, terbaik)

        info("Mencari kelas SystemData...")
        val kSd = cariKelas(sh, terbaik, lib, HINT_SD, "SystemData", mapped, info)
        if (kSd == null) {
            info("Kelas SystemData tidak ditemukan (coba restart game)")
            return null
        }

        info("Mencari kelas LogicBattleManager...")
        val kLbm = cariKelas(sh, terbaik, lib, HINT_LBM, "LogicBattleManager", mapped, info)
        if (kLbm == null) {
            info("Kelas LogicBattleManager tidak ditemukan (coba restart game)")
            return null
        }

        val sd = sh.bacaLong(terbaik, kSd + 0xA8L)
        val sl = sh.bacaLong(terbaik, kLbm + 0xA8L)
        if (sd == null || sl == null || sd == 0L || sl == 0L) {
            info("Data statis game belum siap")
            return null
        }
        val ringkas = "pid=$terbaik libcsharp=0x" + java.lang.Long.toHexString(lib.base) +
            " SystemData=0x" + java.lang.Long.toHexString(sd) +
            " LBM_global=0x" + java.lang.Long.toHexString(sl + 0x28L)
        return Sasaran(terbaik, lib.base, sd, sl + 0x28L, ringkas)
    }
}
