package com.pencatat.memori

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class KeepAliveService : Service() {

    companion object {
        private const val CH = "auto_up_lvl"
        private const val ID = 1

        fun start(ctx: Context) {
            val i = Intent(ctx, KeepAliveService::class.java)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, KeepAliveService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Auto Up Level", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Menjaga otomasi tetap berjalan"
            nm.createNotificationChannel(ch)
        }
        val stopIntent = Intent(this, KeepAliveService::class.java).apply { action = "STOP" }
        val stopPi = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setContentTitle("Auto up lvl")
            .setContentText("Otomasi sedang berjalan…")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "Berhenti", stopPi)
            .setOngoing(true)
            .build()
        startForeground(ID, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            Engine.stop()
            stopSelf()
        }
        return START_STICKY
    }
}
