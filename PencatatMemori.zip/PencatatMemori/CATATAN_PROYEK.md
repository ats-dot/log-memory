# Catatan proyek: Pencatat Memori

Baca berkas ini dulu. Jangan membaca seluruh kode; pakai `grep -n` lalu baca hanya fungsi yang perlu diubah.

## Cara kerja dengan pemilik proyek
- Bahasa Indonesia, singkat, cocok layar HP kecil. Pemula coding, hanya pakai HP Android.
- Kode tidak bisa dikompilasi di sini. Selalu jujur bahwa kode belum dikompilasi atau diuji di HP.
- Kalau pemilik bertanya atau mengeluh: beri penyebab dan usulan dulu, JANGAN langsung menulis kode. Setelah dia setuju baru buat kodenya.
- "jangan buat kode dulu" = hanya analisis. Kalau ragu soal maksud, tanya dulu (maksimal sekitar 3 pertanyaan, lebih baik berupa pilihan).
- TAMPILAN HARUS SAMA PERSIS dengan mockup yang sudah disetujui (artifak: https://claude.ai/artifact/YFLKFs8gnLo1fcjFEV3JpS,
  gelap dan terang). Tampilan baru: tunjukkan mockup dulu. Kalau terpaksa beda dari mockup, sebutkan terus terang.
- Pengiriman: HANYA satu berkas `PencatatMemori.zip` (nama sama, berisi folder `PencatatMemori`), diunggah menimpa yang lama ke GitHub,
  build lewat GitHub Actions (unzip lalu `gradle assembleRelease`; workflow akar ada di `unzip-build.yml`). Jangan kirim berkas per path.
  Saat menjawab perubahan kode, sebutkan berkas yang berubah beserta jumlah barisnya.
- Hasil log atau layar yang tidak jelas: jangan menebak, minta contoh atau screenshot.

## Tujuan
Mencatat PERUBAHAN memori game Mobile Legends (di dalam aplikasi klon Multi Run) secara rapat dan ringan, di luar GameGuardian,
supaya perubahan script GG berikutnya berdasarkan data nyata (kapan game menimpa nilai yang ditulis script, kapan status match
berganti, kapan lag, dst). Hanya MEMBACA memori; tidak pernah menulis.

## Cara kerja
1. Shizuku (hak shell) menjalankan `run-as <paket Multi Run> sh`. `run-as` hanya jalan karena Multi Run versi pemilik DEBUGGABLE,
   dan game berjalan di uid yang sama dengan Multi Run. Shizuku langsung (tanpa run-as) DITOLAK membaca memori game.
2. `Pencari`: uid paket (`pm list packages -U`), semua proses milik uid itu (`ls -dn /proc/[0-9]*`), pilih yang memuat `libcsharp.so`
   di `/proc/<pid>/maps` (pemetaan terbesar). Dasar `libcsharp.so` = alamat awal pemetaan dengan offset 0.
3. Alamat objek = rantai pointer yang sama seperti script GG:
   - kelas = `[libBase + offsetTetap]`; nama kelas dicek di `[kelas+0x10]`.
   - `SystemData`: statis = `[kelas+0xA8]`. `LogicBattleManager`: `global = [kelas+0xA8] + 0x28`, objek = `[global]` (berganti tiap match).
   - Offset tetap (game versi 12/11, build ProMild-12_11): SystemData 0x6497880; LBM 0x6497780; LogicBattleScene 0x64920D8; LoadResModuleMgr 0x649FF88. Alamat versi 10/11 (0x77AEEB8, 0x7CD3238) dan 30/10 (0x5E6D270, 0x63938F8) tidak lagi dipakai.
   - Tower musuh (Menara.kt): `kamus=[LBM+80]`, `b=[kamus+24]`, entri pointer di `b+0x30..0x12c0` langkah 0x18; entitas tower bila byte 0x59=1 atau
     0x72=1 atau m_MonsterType(2184)=2 dan camp(484) != camp hero. Atribut: `a=[entitas+1296]+56`, `b=[a]+24`, `c=[b]` (health +200, shield +684).
4. `GameShell.baca`: `dd if=/proc/<pid>/mem bs=4096 skip=<halaman> count=<n> | base64 -w 0`. Cadangan: `base64|tr`, lalu `od -An -v -tx1`.
   Satu sesi shell tetap hidup; tiap perintah diakhiri penanda `__SELESAI_n`; lewat batas waktu = sesi ditutup dan dibuka ulang.
5. Dua mode di `Perekam` (satu utas, satu layanan latar):
   - mode 0 PANTAU: tiap putaran (2/5/10/20 kali per detik) membaca blok SystemData (9520 byte), LBM (512), hero (1904) dan tiap tower
     (entitas 1904 + atribut 704, paling cepat tiap 0,5 detik), membandingkan, mencatat HANYA yang berubah. Bacaan pertama = "nilai awal".
     Kalau `terpilih` diisi (dari hasil Mode cari), hanya alamat terpilih yang dibaca (rentang dipersempit per objek).
   - mode 1 CARI: tiap 1 detik membaca objek PENUH (akun 16 KB, LBM 4 KB, hero 4 KB, tiap tower 4 KB + atribut 1 KB) dan `Penelusur`
     mengumpulkan statistik per kata 4-byte. Saat berhenti: berubah sekali, seperti penghitung (monoton lalu diam >=3 dtk), kedip (<=4 kali
     lalu diam), selain itu gangguan (disembunyikan). Tower digabung per (E/A, offset). Hasil ditulis ke `Hasil_cari_N.txt`.
6. Otomatis: status match, pointer LBM berganti, tower ditemukan, lag (waktu game `m_uiFrameTime` <0,7x jam asli di dua jendela 2 dtk,
   hanya saat Play, lompatan waktu dari script diabaikan), lompatan posisi hero (>0,8).
7. Tanda manual: tombol notifikasi (Tower BISA dihit, Mulai lag, Tanda lain...) dan tombol layar. Tiap tanda menyimpan ringkasan kondisi.
8. Cari file (`PemindaiFile`): daftar berkas (ukuran + waktu ubah) sebelum dan sesudah match lewat `find ... -exec stat -c '%n|%s|%Y'`.
   Folder 1: `/data/data/<paket>` lewat run-as. Folder 2 (lewat Shizuku): `/storage/emulated/0/Android/data/<paket>/hzby/storage/emulated/1/Android/data/com.mobile.legends`
   (lokasi dari pemilik; kalau tidak ada, dicari folder `com.mobile.legends` di bawah `/storage/emulated/0/Android/data/<paket>`).
   Daftar awal disimpan di `filesDir/daftar_awal.txt`.

## Berkas (src/main/java/com/pencatat/memori)
- Daftar.kt: field (nama + offset dari tabel script: AKUN 22, PERTANDINGAN 11, HERO 3, TOWER_E 2, TOWER_A 3: `health` +200, `hpSaatIni` +204, `shield` +684) dan konstanta rantai pointer.
- ShizukuHelper.kt, GameShell.kt, Pencari.kt: Shizuku, sesi run-as, pencari proses dan alamat.
- Menara.kt: pencari tower musuh. Penelusur.kt: mesin Mode cari. PemindaiFile.kt: Cari file.
- Perekam.kt: mesin perekam (rencana baca, mode pantau/cari, berkas `Sesi_N.txt` di folder file eksternal aplikasi).
- LayananPerekam.kt: layanan latar (specialUse) + notifikasi + `PenerimaTanda`. MarkerActivity.kt: menu "Tanda lain...".
- MainActivity.kt: tiga tab (Beranda, Aktivitas, Cari: Memori / Hasil / File), UI dari kode, tema gelap/terang mengikuti sistem.
- Ui.kt: warna (`Pal`) dan pembantu tampilan (tombol berikon, kartu, chip, baris centang, garis).

## Beda yang disengaja dari mockup (sebutkan lagi kalau ditanya)
- Setelan (paket Multi Run, baca per detik, deteksi lag) TIDAK ada di mockup: dipindah ke dialog yang dibuka dengan MENAHAN LAMA judul
  "Pencatat Memori" di Beranda, supaya Beranda sama dengan mockup.
- Baris "Tower musuh" di Beranda dan Cari kini AKTIF (di mockup abu-abu "tahap berikutnya"). Keterangan "Hero sendiri" ditulis
  "posisi dan flag" (bukan "posisi, atribut, KDA") karena KDA tidak dibaca.
- Label "ditimpa game / ditulis script" di contoh Aktivitas tidak bisa dihasilkan aplikasi (hanya contoh); yang tampil keterangan nyata
  (mis. "nilai awal", "lompatan", teks LAG).
- Chip filter Aktivitas ada 4 seperti mockup: Pertandingan = PERTANDINGAN+HERO+TOWER; Tanda = TANDA+OTOMATIS.
- Menu "Tanda lain..." dari notifikasi tepat 6 baris seperti mockup; dari tombol dalam aplikasi ditambah 2 tanda cepat di atasnya.

## Keyboard
- MainActivity: `stateHidden|adjustPan` (jendela tidak mengecil, tab bawah tetap di bawah dan tertutup keyboard, keyboard tidak muncul lagi
  saat kembali ke aplikasi). Keyboard + fokus ditutup saat pindah tab, saat ke belakang, dan saat menyentuh di luar kolom.
  Cadangan kalau adjustPan mengganggu: adjustResize + sembunyikan tab saat keyboard muncul (WindowInsets, API 30).
- Kolom ketik hanya ada di dialog Setelan (aksi Selesai menyimpan dan menutup) dan di menu Tanda lain (`stateHidden|adjustResize`,
  gulir otomatis ke tombol Simpan, aksi Selesai).

## Format log (Sesi_N.txt)
Baris `# ...` = keterangan. Kejadian: `HH:mm:ss.SSS g=detik TIPE judul  lama -> baru  (keterangan)`. TIPE: AKUN, PERTANDINGAN, HERO, TOWER, TANDA, OTOMATIS.
`g=` = WAKTU GAME dari `m_uiFrameTime` (LBM+316, ms) dibagi 1000; `g=-` bila belum ada match. Dengan jam HP di kolom pertama bisa dihitung rasio
waktu game / jam asli (dasar deteksi lag dan untuk menguji dugaan proteksi tower berbasis waktu game). Aplikasi menampilkan `· g12.3` di baris Aktivitas
dan `g=` di berkas hasil Mode cari.
Posisi tower tepat setelah match mulai sering (0,0): dibaca ulang tiap detik (maks 90 kali per tower) lalu dicatat sekali sebagai `T# posisi (x, y)`;
bila cocok dengan tabel `towerMid` di script diberi keterangan `mid-1`..`mid-4` (luar ke dalam). Label T# urutan penemuan, bukan urutan posisi.

## Temuan terbaru (dari banyak sesi; urutan paling baru di atas)
- HP tower: `+204` = HP SAAT INI (turun ke 0 saat tower mati), `+200` kemungkinan HP maksimum (tidak ikut turun). Log pantau lama hanya menampilkan `+200`;
  sejak versi ini `hpSaatIni` (+204) juga dipantau, dan tower dengan byte 0x72 (IsMainTower)=1 diberi keterangan "main tower" di log.
- Script "Kurangi Darah Tower" (setHealthTower): menulis 1 (BUKAN 0) ke kedua kata HP (+200/+204) semua tower musuh; tower berperisai (m_uGuardId tertentu)
  juga perisai +684/+688 dan +640/+644 = 1; main tower HP=1 ditulis ulang tiap ~50 ms (daftar UpdateShieldTower). Script juga memakai `m_bDelet`=1
  untuk menghapus minion tim dan menghentikan tim (setStopCamp). Auto end (menu Pengaturan Script) menulis HP main tower = 0 selama 3 dtk: BELUM teruji di game.
- Proteksi tower ~22,5 detik sejak status Play (bukan `m_uiFrameTime`: script melompatkan waktu game ke 840 s di awal tapi proteksi tetap ~22,5 s). Di akhir proteksi
  game memberi perisai 3100 (+684) ke tower terluar dan klaster field (E172, E492, E1536, A648..A660, dst) berubah serentak (kemungkinan efek serangan pertama).
- Quick Mode (5 field) TIDAK mengubah apa pun yang terlihat: tahap selectHero dan 3 halaman hasil tetap muncul walau flag menyala (Sesi_8, Sesi_14) atau mati (Sesi_12).
  Sesi_4 (tanpa selectHero) terjadi di akun baru (match ke-2).
- Menulis `_m_eState`=End saat waitEnd TIDAK mempercepat halaman hasil (Sesi_14): status hanya melaporkan tahap; pembersihan match baru terjadi saat halaman hasil selesai.
  Halaman hasil digerakkan objek tampilan (UI) yang belum kita baca. Urutan kata akun setelah match (+3796/+9768 -> +3808 -> +3376/+1248 -> +3324) konsisten antar match.

## Temuan dari log nyata pertama (Sesi_4, mode pantau)
- Pipeline jalan di game asli (base64, alamat, tower 10 buah dengan HP 7900/4000x3/3500x3/3000x2). Script terlihat: Quick Mode dan level 244 ditulis di
  status Unknown; hero kebal dan HP tower jadi 1 di +1,1..1,9 s setelah Play; teleport ke koordinat tower mid.
- Tower pertama hancur di +31,2 s setelah Play (jam nyata); `m_bCantBeHurt` tower tidak pernah berubah (bukan penanda proteksi).
- Halaman hasil: tidak ada field yang dipantau berubah antar halaman (status `waitEnd` sepanjang halaman) -> perlu Mode cari.
- Dugaan belum terbukti: proteksi tower dihitung dalam WAKTU GAME (~20 dtk) sehingga lag memperpanjangnya di jam nyata.

## Status pengujian
- Belum dikompilasi dan belum dicoba di HP. Build pertama bisa gagal; minta log kegagalan Actions.
- Sudah diuji di luar HP (tiruan Python / shell): rumus halaman dd + base64/hex + protokol penanda (210 kasus), pencocokan semua nama dan
  offset dengan tabel Lua, rantai tower dan atribut pada memori palsu, logika perbandingan, lag, lompatan posisi, klasifikasi Mode cari,
  pemindai file (find/stat) dan perbandingannya, serta pemeriksaan statis kode (kurung, nama, resource).
- Belum diketahui sampai dicoba di HP: `base64 -w 0` di toybox HP (ada cadangan), `run-as sh` membaca stdin, `find -exec stat -c` di toybox,
  apakah `m_uiFrameTime` melambat saat lag, beban nyata (Beranda menampilkan "ms per putaran"), apakah adjustPan terasa baik.

## Build ProMild-12_11 (update game 12/11): apa yang berubah dan kenapa
Diperoleh dengan membongkar berkas bytecode `ScriptAdvancedProMild-12_11.lua` dan membandingkannya dengan 10_11 (diff semantik seluruh script, nomor baris dibuang): **hanya 20 blok beda**, semuanya sudah diterapkan.
- Dekripsi string build ini: kunci 191 (seperti 10_11) **ditambah XOR 4** di setiap byte hasilnya. Tanpa XOR 4 string tampak acak (`e``vaww` = `address`). Cek cepat build baru: hitung kata dikenal (`address`, `value`, `config`) untuk XOR 0..31.
- Alamat statis libcsharp.so: SystemData 0x6497880, LBM 0x6497780, LogicBattleScene 0x64920D8, LoadResModuleMgr 0x649FF88.
- Offset SystemData bergeser (field lain tetap): LoginID 2232->2240, _strRoleName 2384->2392, _uiCreateTime 3336->3344, m_bLockRobotGuide 3622->3630, m_sCreateRoleCountry 2792->2800, bQuickMatchUseNewBattleSettle 4921->4929, m_bEnterBattle 7624->7656, m_isSelectQuickMatch 9512->9552.
- Entitas monster: m_MonsterType 2180->2184, m_uGuardId 2344->2352. Statistik pemain: m_MaxContinueKill 4200->3672, m_OperateTimeMonitor 3952->3424, m_WeekKill 4216->3688.
- Logika: `setHealthTower` tidak lagi dikecualikan oleh `config.autoClearTower` (kondisi `autoClearTower == nil` dihapus dari loop utama).
- Rantai atribut tower (entitas+1296 -> +56 -> +24, HP +200/+204) TIDAK berubah.
- Gejala yang dijelaskan: dengan offset lama script membaca kolom yang salah. `callEntity` hanya menandai tower (byte 0x59 = 1) bila m_MonsterType == 2, jadi tidak ada tower yang dikenali (HP=1 dan Auto end tanpa sasaran) dan flag Quick Mode terbaca sampah (-72). Terbukti di tiruan: script lama + susunan baru = 0 dari 4 tower ditandai, script baru = 4 dari 4.
- Pelajaran uji di HP lewat shell: `$((...))` di `sh` HP hanya 32-bit. Alamat 0x6c.. terpotong dan hasilnya nol palsu. Pakai nomor halaman (`dd bs=4096 skip=<halaman>`) + `od -j <geser>` dengan angka yang sudah dihitung di luar HP.
- Pelajaran: keempat alamat lama menunjuk ke isi non-nol (kode ARM64) di versi baru, jadi "bukan nol" tidak membuktikan alamat valid. Selalu cek nama kelas di +0x10.

## Uji build 12_11 di HP (Sesi_16, Sesi_17)
- Aplikasi menemukan game dan membaca semua field dengan benar (level 244, flag Quick Mode 1/0/1/1/0/1, 10 tower dengan HP/perisai/posisi). HP=1 dan perisai 3100->1 bekerja, tower dikenali.
- Proteksi tower berakhir +22,7..22,9 dtk sejak Play (kelompok kejadian g=861,6 di Sesi_17: tower mid m_bDelet, perisai muncul). Selama proteksi game tidak mematikan tower, TAPI penulisan HP tetap masuk: di Sesi_17 `hpSaatIni` main tower tertahan di 0 selama Auto end menulis (3 dtk), lalu **pulih sendiri** 165 -> 9405 begitu penulisan berhenti (tower luar tidak pulih karena HP=1-nya ditulis ulang terus). Match baru selesai +31,6 dtk saat hero menghabisi main tower.
- Sesi_16: Auto end kebetulan menulis di +33,3 dtk (setelah proteksi), `waitEnd` datang 2,2 dtk kemudian. Kesimpulan: tulis HP main tower = 0 harus TERUS-MENERUS dari cheat terpasang sampai match selesai (`autoEnd.lama = 120`), supaya begitu proteksi habis main tower langsung mati (perkiraan akhir ~+25 dtk, seperti Sesi_12/14). Percobaan "mulai +20 dtk" (asumsi keliru bahwa tulisan awal diabaikan) dibatalkan karena bergantung pada os.clock yang jamnya tidak pasti. Belum diuji di HP.
- Di Sesi_16 cheat baru mulai +33 dtk (lompat waktu), di sesi lama dan Sesi_17 +1..3 dtk. Tidak terulang di Sesi_17. Dugaan (belum terbukti): efek pertama setelah update (pencarian alamat kelas lalu disimpan di cache). Kalau muncul lagi, tambahkan pencatat waktu per langkah executeScript.
- Sesi_17 tidak punya tahap selectHero (waitReady -> Play 17 dtk) dan flag m_isSelectQuickMatch tidak berkedip; Sesi_16 punya selectHero 58,7 dtk dan flag itu berkedip 1->0->1 (ditulis balik script dalam 0,2 dtk). Mungkin Quick Mode efektif bila flag sudah 1 saat game mulai mencari match. Belum terbukti, tunggu penjelasan pengguna.
- `_ucLevel` 244 -> 5 (level asli) saat waitEnd lalu kembali 244 oleh script di status Unknown. Counter Abnormality melonjak ke ~1,2 miliar saat Play di semua sesi (perilaku lama).
- Ide uji berikutnya (belum dicoba): kelompok E172 (1->0 di 6 tower) berubah serentak saat proteksi berakhir; menulisnya lebih awal mungkin mengakhiri proteksi. Berisiko, tulis hanya setelah disetujui.

## Kandidat penanda proteksi tower (hanya dibaca)
Pemantau tower kini juga membaca 13 field `kand_*` (E172, E216, E488, E492, E592, E844, E1536, E1736 pada entitas; A648, A652, A656, A660, A664 pada objek atribut). Semuanya berubah serentak saat proteksi ~22,7 dtk berakhir di Hasil_cari_5/9 (build lama; offset di bawah 1840 tidak bergeser di build 12_11, jadi seharusnya masih berlaku). Kandidat terkuat: E172 (1 -> 0 di 6 tower), E492 (mirip bitfield, 6 tower), pasangan E1536/E1736 (nilai -16777207 pindah). Belum diketahui mana sebab dan mana akibat. Langkah berikutnya: baca nilai awal per tower di satu match, lalu uji tulis satu field pada satu tower (hanya setelah disetujui, berisiko).

## Sesi_18 dan Sesi_19: yang mengakhiri match, perisai, dan field E172
- **HP main tower = 0 tidak mengakhiri match** (Sesi_18: ditahan 0 sejak +2 dtk, match tetap berjalan sampai +43,3 dtk). Yang mengakhiri: HP main tower turun NEGATIF oleh pukulan (0 -> -198, `waitEnd` datang 0,07 dtk kemudian; Sesi_17: -19 lalu `waitEnd` 0,1 dtk). Jadi Auto end (HP=0) tidak otomatis. Klaim lama "Sesi_16 selesai 2,2 dtk setelah Auto end" kemungkinan keliru (saat itu pengguna sedang memukul tower).
- **Bug Auto end (diperbaiki):** ia mengosongkan `UpdateShieldTower` pada tulisan pertamanya, padahal daftar itu menahan perisai tower luar di 1. Akibatnya game memasang perisai 3100 saat proteksi habis (+22,7 dtk) dan tower pertama tidak lagi one hit (Sesi_17/18/19; sesi tanpa Auto end 6/12/14 tidak pernah punya perisai 3100). Auto end hanya menulis `health` +200/+204 main tower, tidak bertabrakan dengan daftar itu.
- **`kand_E172` hampir pasti penanda "tower terkunci/kebal"** (1 = terkunci). Sesi_19 (tower: T1 main, T2=mid-1, T5=mid-2, T8=mid-3; T2/T3/T4 = tiga tower terluar): semua tower E172=1 di awal. +22,66..22,77 dtk: E172 tiga tower terluar 1->0 bersamaan dengan perisai 1->3100, E492 -> 0, E1536 -> 0 (nilai ID penjaga pindah ke E1736 di T2), A648/656/660 -> 114, A652 -> -1, A664 -> 3100. T2 hancur +24,98. Lalu rantai terbuka: E172 mid-2 (+25,16), mid-3 (+25,33), main tower (+25,64) menjadi 0 tepat setelah tower di depannya hancur; mereka hancur +25,84, +26,00, +26,24; `waitEnd` +26,19. Jadi ada dua kunci: proteksi global tower terluar (~22,7 dtk) dan rantai urutan (mid-1 -> mid-2/mid-3 -> main tower).
- Nilai awal pembeda tower terluar (T2/T3/T4): shield=1, E492=269516800 (lainnya 268435456), E1536 berisi ID penjaga -16777207/-8/-6 (lainnya 0). E216 (100) berubah jadi 2 pada main tower saat HP=0 ditulis (mungkin persen HP). Main tower tidak dibedakan oleh field kand_ lain.
- Ide uji (belum dikerjakan, tunggu persetujuan): tulis E172=0 (dan E492=0) pada tower musuh lebih awal, lihat apakah tower bisa dipukul sebelum +22,7 dtk. Berisiko (field belum dipahami penuh).

- **Hasil perbaikan perisai (Sesi_21, langsung hit):** E172 tower terluar 1->0 di +22,46..22,60 dtk; perisai 3100 muncul sekilas di satu tower (+22,63) lalu kembali ke 1 dalam 0,8 dtk (ditahan UpdateShieldTower); tower pertama hancur +23,29 (0,8 dtk setelah terbuka, satu hit); rantai runtuh +24,16/+24,35/+24,51; `waitEnd` +24,60 dtk. Pembanding: Sesi_17 31,6 dtk, Sesi_19 26,2 dtk (perisai 3100 menahan ~2,3 dtk), Sesi_20 69,1 dtk (tidak langsung hit; kunci rantai terbuka tepat setelah tower pertama hancur). Lantai saat ini = proteksi tower terluar ~22,5 dtk; Auto end (HP=0) tidak terbukti berpengaruh.

## Pencarian pemicu akhir match (scan LBM lebar)
- Video orang lain membuktikan: base musuh bisa hancur sendiri tanpa dipukul, dan VICTORY muncul. Artinya ada field yang kalau ditulis, memicu event kemenangan — bukan HP, m_bDelet, atau E172.
- PANJANG_MATCH diperlebar dari 512 ke 4096 byte supaya Mode cari memindai lebih banyak field di LogicBattleManager.
- Rencana: jalankan Mode cari saat match, biarkan match selesai normal (hancurkan base), dan lihat field mana di LBM yang berubah tepat saat waitEnd. Field itu kandidat pemicu match end.
- Percobaan HP=0/-1 dan m_bDelet=1 terbukti gagal (Sesi_18/24/25). Yang berhasil untuk membunuh tower: E172=0 + HP=1 + pukulan hero.

## Batas
- Kalau versi game berubah dan alamat tetap libcsharp tidak cocok: pesan "Kelas ... tidak cocok". Belum ada pencarian cadangan.
- Mode cari hanya melihat objek yang alamatnya bisa dihitung (akun, LBM, hero, tower). Perubahan di tempat lain tidak terlihat.
- Jalur ini hanya jalan selama Multi Run (versi yang dipakai) tetap debuggable.
- Mengenali halaman hasil lewat OCR belum ada.

## Pembaruan tanpa uninstall
`applicationId` tetap `com.pencatat.memori`, `debug.keystore` (password `android`, alias `androiddebugkey`) dipakai untuk semua build,
dan `versionCode = 10 + GITHUB_RUN_NUMBER` naik otomatis tiap build di GitHub Actions. Jangan hapus atau ganti keystore, jangan turunkan versionCode.
