# Catatan proyek: Pencatat Memori

Baca berkas ini dulu. Jangan membaca seluruh kode; pakai `grep -n` lalu baca hanya fungsi yang perlu diubah.

## Cara kerja dengan pemilik proyek
- Bahasa Indonesia, singkat, cocok layar HP kecil. Pemula coding, hanya pakai HP Android.
- Kode tidak bisa dikompilasi di sini. Selalu jujur bahwa kode belum dikompilasi atau diuji di HP.
- Kalau pemilik bertanya atau mengeluh: beri penyebab dan usulan dulu, JANGAN langsung menulis kode.
- "jangan buat kode dulu" = hanya analisis. Kalau ragu soal maksud, tanya dulu (maksimal sekitar 3 pertanyaan, lebih baik berupa pilihan).
- Untuk tampilan baru: tunjukkan gambar (mockup) dulu, termasuk tema gelap dan terang, baru dikerjakan.
- Pengiriman: HANYA satu berkas `PencatatMemori.zip` (nama sama, berisi folder `PencatatMemori`), diunggah menimpa yang lama ke GitHub, build lewat GitHub Actions (unzip lalu `gradle assembleRelease`). Jangan kirim berkas per path.
- Hasil log atau layar yang tidak jelas: jangan menebak, minta contoh atau screenshot.

## Tujuan
Mencatat PERUBAHAN memori game Mobile Legends (di dalam aplikasi klon Multi Run) secara rapat dan ringan, di luar GameGuardian,
supaya perubahan script GG berikutnya berdasarkan data nyata (kapan game menimpa nilai yang ditulis script, kapan status match
berganti, kapan lag, dst). Hanya MEMBACA memori; tidak pernah menulis.

## Cara kerja
1. Shizuku (hak shell) menjalankan `run-as <paket Multi Run> sh`. `run-as` hanya jalan karena Multi Run versi pemilik DEBUGGABLE,
   dan game berjalan di uid yang sama dengan Multi Run. Shizuku langsung (tanpa run-as) DITOLAK membaca memori game.
2. `Pencari`: uid paket (`pm list packages -U`), semua proses milik uid itu (`ls -dn /proc/[0-9]*`), pilih yang memuat `libcsharp.so`
   di `/proc/<pid>/maps` (yang pemetaannya terbesar). Dasar `libcsharp.so` = alamat awal pemetaan dengan offset 0.
3. Alamat objek dihitung dengan rantai pointer yang sama seperti script GG:
   - kelas = `[libBase + offsetTetap]`; nama kelas dicek di `[kelas+0x10]` (string).
   - `SystemData`: statis = `[kelas+0xA8]`. `LogicBattleManager`: `global = [kelas+0xA8] + 0x28`, objek = `[global]` (berganti tiap match).
   - Offset tetap: SystemData 0x77AEEB8 (baru) / 0x5E6D270 (lama); LBM 0x7CD3238 (baru) / 0x63938F8 (lama).
4. `GameShell.baca`: `dd if=/proc/<pid>/mem bs=4096 skip=<halaman> count=<n> | base64 -w 0`, diurai di aplikasi. Mode cadangan: `base64|tr`, lalu `od -An -v -tx1`.
   Satu sesi shell tetap hidup; tiap perintah diakhiri penanda `__SELESAI_n`. Kalau lewat batas waktu, sesi ditutup dan dibuka ulang.
5. `Perekam`: tiap putaran membaca blok SystemData (9520 byte), blok LBM (512 byte), dan blok hero (1904 byte, dari `m_RealSelfPlayer`),
   membandingkan dengan bacaan sebelumnya, dan mencatat HANYA yang berubah. Bacaan pertama dicatat sebagai "nilai awal".
   Pointer LBM dicek ulang tiap 1 detik. Game dianggap hilang setelah 5 pembacaan gagal berturut-turut lalu dicari lagi.
6. Otomatis: status match (dari `_m_eState`), pointer LBM berganti, deteksi lag (waktu game `m_uiFrameTime` lebih lambat dari jam asli,
   <0,7x di dua jendela 2 detik berturut-turut, hanya saat status Play, lompatan waktu dari script diabaikan), lompatan posisi hero (>0,8).
7. Tanda manual: tombol notifikasi (Tower BISA dihit, Mulai lag, Tanda lain...) dan layar Mulai/Tandai. Tiap tanda menyimpan ringkasan kondisi.

## Berkas (src/main/java/com/pencatat/memori)
- Daftar.kt: daftar field (nama dan offset diambil dari tabel offset script GG: offsetStatic 22, offsetBattle+handler 11, hero 3), pembaca little-endian.
- ShizukuHelper.kt: izin dan `newProcess` lewat refleksi (sama dengan Project ats).
- GameShell.kt: sesi `run-as` yang tetap hidup dan pembacaan memori.
- Pencari.kt: mencari proses game dan menghitung alamat.
- Perekam.kt: mesin perekam (utas sendiri), daftar kejadian, berkas sesi `Sesi_N.txt` di folder file eksternal aplikasi.
- LayananPerekam.kt: layanan latar (specialUse) + notifikasi + `PenerimaTanda`.
- MarkerActivity.kt: dialog "Tanda lain...".
- MainActivity.kt: dua layar (Beranda, Aktivitas), UI dibuat dari kode, mengikuti tema sistem (gelap/terang).
- Ui.kt: warna (`Pal`) dan pembantu tampilan.

## Format log (Sesi_N.txt)
Baris `# ...` = keterangan. Baris kejadian: `HH:mm:ss.SSS TIPE judul  lama -> baru  (keterangan)`.
TIPE: AKUN, PERTANDINGAN, HERO, TANDA, OTOMATIS.

## Status pengujian
- Belum dikompilasi dan belum dicoba di HP. Build pertama bisa gagal; minta log kegagalan Actions.
- Sudah diuji di luar HP (tiruan Python): rumus hitungan halaman dd, penguraian base64/hex, protokol penanda, pencocokan semua nama dan
  offset dengan tabel Lua, logika perbandingan, lag, dan lompatan posisi.
- Belum diketahui sampai dicoba di HP: apakah `base64 -w 0` tersedia di toybox HP (ada cadangan), apakah `run-as sh` membaca stdin dengan
  benar, apakah `m_uiFrameTime` ikut melambat saat game tersendat (deteksi lag masih eksperimen), beban sebenarnya per putaran
  (ditampilkan di Beranda sebagai "ms per putaran").

## Batas dan hal yang belum ada
- Tower musuh BELUM dipantau (butuh menelusuri `m_dicMonsterLogic`). Rencana tahap berikutnya.
- Kalau versi game berubah dan alamat tetap libcsharp tidak cocok, aplikasi hanya menampilkan "Kelas ... tidak cocok". Belum ada pencarian cadangan.
- Mengenali halaman hasil lewat OCR belum ada (butuh Aksesibilitas, lebih berat).
- Jalur ini hanya bekerja selama Multi Run (versi yang dipakai) tetap debuggable.

## Pengaturan bawaan
Paket `com.dong.multirun`, 5 kali baca per detik (pilihan 2/5/10/20), deteksi lag nyala, semua area (akun, pertandingan, hero) nyala.

## Kunci tanda tangan
`debug.keystore` (di folder ini, password `android`, alias `androiddebugkey`) dipakai `signingConfigs.debug` untuk build release,
supaya semua build bertanda tangan sama dan APK baru bisa dipasang MENIMPA tanpa uninstall. Jangan dihapus atau diganti.

## Aturan yang perlu dijaga
- Aplikasi ini hanya membaca. Jangan menambah penulisan memori di sini; penulisan tetap lewat script GG.
- Tampilan baru: ikuti warna di `Pal` (Ui.kt) supaya tema gelap dan terang tetap rapi.
- Log hanya untuk sesi perekaman; jangan mencatat kejadian di luar sesi.
