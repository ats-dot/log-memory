# Langkah otomasi Auto up lvl — kata-kata pengguna (ditulis ulang 2026-11-21 00:35, BELUM LENGKAP, pengguna masih lanjut)

(Foto-foto yang dirujuk tidak tersedia di sesi; pengguna tidak mau kirim ulang.)

1. Setelah apk ML di Multi Run dibuka dan sudah sampai di lobby, skrip diaktifkan. Beri pengaturan JEDA DI LOBBY seperti yang ada di claim-vg.
2. Kalau jeda habis dan TIDAK ada ikon tangan (seperti foto 2), langsung ketuk Classic. Kalau ADA ikon tangan, ketuk ikon yang ditunjuk tangan.
3. Setelah diketuk (foto 2), muncul foto 3: ketuk lagi yang ditunjuk ikon tangan.
4. Foto 4 & 5: saat loading, kalau sudah ada teks "Konfirmasi", ketuk itu.
5. Foto 6/7: ketuk yang ditunjukkan ikon tangan / teks "Pergi ke Lobby".
6. Kalau telat membaca dan belum sempat mengetuk "Pergi ke Lobby", akan ke halaman foto 8: ketuk Konfirmasi, lalu balik lagi ke foto 6/7, ketuk "Pergi ke Lobby".
7. Lalu ketuk yang ditunjukkan ikon tangan / teks "Mulai Game" (foto 9).
8. Kalau setelah Classic diketuk / di halaman Classic ada 2 popup (foto 10 & 11): gunakan back untuk menyingkirkannya, lalu ketuk Mulai Game seperti foto 9.
9. Foto 12, 13, 14: loading setelah Mulai Game diketuk.
10. Foto 15: ketuk yang dilingkari merah = ikon turret di samping basic attack (ikon kampak), sebanyak 4/5/6 kali sampai pindah ke halaman berikutnya. (Revisi 00:21: terus-menerus sampai selesai match, 200 ms/ketuk.)
11. Kalau sudah terlihat teks VICTORY: ketuk bagian tengah yang dilingkari merah (boleh).
12. Ketuk "Lanjutkan" di foto 18.
13. Ketuk "Lanjutkan" di foto 19.
... (menunggu lanjutan dari pengguna)

Catatan revisi lain dari pengguna:
- Setelah Konfirmasi (MVP) game masuk halaman "Achievement Terbuka" (Pertumbuhan Level lalu MVP), tombol Lanjutkan; BUKAN halaman Classic.
- Popup Classic (Fitur Mabar, Custom Signal, Panduan Map): back SATU kali saja.
- Select hero seharusnya langsung dilewati (Quick Mode).

(lanjutan 00:36)
14. Setelah tombol Konfirmasi terlihat, ketuk.
15. Kemudian gunakan back 4x.
16. Kalau ada popup seperti foto 3, gunakan back 1x lagi.
17. Ketuk ikon Event di kiri.
18. Ketuk ikon petir di kiri.
19. Cari "Hadiah Pembaruan"; kalau tidak ada: back ke lobby, ketuk Event & petir lagi, cari lagi Hadiah Pembaruan.
20. Ketuk "Klaim Semua" di Hadiah Pembaruan. Tanda belum diklaim seperti foto 7, sudah diklaim seperti foto 8.
21. Back ke lobby & ketuk Profil.
22. Singkirkan popup yang muncul (foto 9); kalau tidak ada popup (foto 10) langsung ketuk Akun / Pengaturan Akun.
23. Ketuk Ganti Server.
24. Pilih server selanjutnya.
25. Ketuk Ganti Server.
26. Langkah terakhir: ketuk OK kalau sudah berwarna coklat keemasan.

Instruksi umum: cara geser server, menutup popup, baca OCR, dan ketuk halaman SEMUA ikuti claim-vg. Salin semua popup yang ada di claim-vg ke apk ini. Tampilan harus gampang, simple, user friendly, tidak ribet, enak dipandang. Nama apk: "Auto up lvl".
