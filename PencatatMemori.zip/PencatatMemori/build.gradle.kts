plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}
android {
    namespace = "com.pencatat.memori"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.pencatat.memori"
        minSdk = 30
        targetSdk = 34
        // versionCode naik otomatis tiap build di GitHub Actions (nomor run), jadi APK baru
        // SELALU bisa dipasang menimpa yang lama tanpa uninstall (asal debug.keystore sama).
        val nomorRun = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1
        versionCode = 10 + nomorRun
        versionName = "2.0." + nomorRun
    }
    // Kunci tanda tangan tetap: semua build bertanda tangan sama, jadi APK baru bisa dipasang menimpa tanpa uninstall
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    implementation("androidx.core:core-ktx:1.13.1")
}
